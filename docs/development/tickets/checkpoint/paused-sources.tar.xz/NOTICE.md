# Boost.Regex source attribution

The byte regular-expression parser, compiled representation, matching,
capture-selection and formatting algorithms in `src/` are being implemented
from the official **Boost.Regex 1.89.0** behavioral source. Adaptations of those
algorithms retain the Boost Software License 1.0 in [LICENSE_1_0.txt](LICENSE_1_0.txt).

The relevant upstream files are in `boost/regex/v5/` (the upstream repository
uses `include/boost/regex/v5/`):

| Source | Upstream copyright notice |
| --- | --- |
| `basic_regex_parser.hpp`, `basic_regex_creator.hpp` | Copyright (c) 2004 John Maddock |
| `perl_matcher.hpp`, `perl_matcher_common.hpp`, `perl_matcher_non_recursive.hpp` | Copyright (c) 2002 John Maddock |
| `match_results.hpp` | Copyright (c) 1998-2009 John Maddock |
| `cpp_regex_traits.hpp` | Copyright (c) 2004 John Maddock; Copyright 2011 Garmin Ltd. or its subsidiaries |
| `regex_traits_defaults.hpp` | Copyright (c) 2004 John Maddock |
| `regex_iterator.hpp` | Copyright (c) 2003 John Maddock |
| `regex_format.hpp` | Copyright (c) 1998-2009 John Maddock; Copyright 2008 Eric Niebler |

Source locations and semantic invariants are recorded in
[the byte engine architecture note](docs/development/byte-engine-architecture.md).
The runtime is Rust; the development reference executable uses Boost C++.

ICU-derived data and the separate ICU research crate have their own notices in
`tools/icu-probe/primary/data/NOTICE.md` and
`tools/icu-probe/primary/rust/NOTICE.md`.
