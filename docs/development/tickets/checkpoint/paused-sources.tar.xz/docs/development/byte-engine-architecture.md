# Byte engine: source contract and implementation structure

The behavioral source for this work is **official Boost.Regex 1.89.0**, using
`cpp_regex_traits<char>` with the classic C locale. The verified source cache is
`target/research/icu77-cloud/deps/boost_1_89_0`. This document records the source
contracts that guide implementation. Differential cases verify these contracts;
they do not define a new regular-expression dialect.

The current Rust source is an implementation in progress. The byte mechanism
checkpoint has 20 public API regressions and 15 tests of source-derived
invariants. Those tests passed on 2026-10-17. They do not constitute independent
Boost compatibility or performance acceptance; the separate reference harness
checks the complete observable result of a frozen candidate.

## Source map

The linked files are pinned to the `boost-1.89.0` upstream tag.

| Contract | Upstream implementation | Rust location |
| --- | --- | --- |
| Grammar selection, first error, `no_except`, final mark count | [basic_regex_parser.hpp, `parse` / `fail`, lines 132–252](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/basic_regex_parser.hpp#L132) | `src/syntax.rs`, `src/lib.rs` |
| Basic/extended token meaning, scoped flags, `nosubs` | [basic_regex_parser.hpp, lines 276–700](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/basic_regex_parser.hpp#L276) | `src/options.rs`, `src/syntax.rs` |
| Quantifier legality, range rollback, repetition modes | [basic_regex_parser.hpp, lines 974–1290](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/basic_regex_parser.hpp#L974) | `src/syntax.rs` |
| Single-digit ordinary backrefs, extended refs and recursive syntax | [basic_regex_parser.hpp, `parse_backref` / `parse_perl_extension`](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/basic_regex_parser.hpp#L1953) | `src/syntax.rs` |
| Recursion target resolution and fixed-width lookbehind | [basic_regex_creator.hpp, `fixup_recursions` / `calculate_backstep`](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/basic_regex_creator.hpp#L752) | `src/compile.rs` |
| Bracket sets, collating elements, classic-C character properties | [basic_regex_creator.hpp, `basic_char_set` / `append_set`](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/basic_regex_creator.hpp#L63), [cpp_regex_traits.hpp](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/cpp_regex_traits.hpp), [regex_traits_defaults.hpp](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/regex_traits_defaults.hpp) | `src/charset.rs`, `src/syntax.rs` |
| Start maps, nullability, recursion checks and leading-repeat analysis | [basic_regex_creator.hpp, lines 888–1694](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/basic_regex_creator.hpp#L888) | `src/start.rs` |
| Effective Perl/POSIX mode, input context, partial publication | [perl_matcher_common.hpp, `construct_init` / `match_prefix`](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/perl_matcher_common.hpp#L50) | `src/execute.rs` |
| Branch order, repeat counters, capture open/close | [perl_matcher_non_recursive.hpp, lines 398–699](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/perl_matcher_non_recursive.hpp#L398) | execution frames in `src/execute.rs` |
| Recursive calls, success, control verbs, typed unwind | [perl_matcher_non_recursive.hpp, lines 1014–1885](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/perl_matcher_non_recursive.hpp#L1014) | execution/capture rollback in `src/execute.rs` |
| Capture register writes and POSIX comparison | [match_results.hpp, `set_first` / `set_second` / `maybe_assign`](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/match_results.hpp#L479) | `src/registers.rs` |
| Iterator continuation after empty matches | [regex_iterator.hpp, `next`, lines 60–75](https://github.com/boostorg/regex/blob/boost-1.89.0/include/boost/regex/v5/regex_iterator.hpp#L60) | `Matches` in `src/lib.rs` |

## Semantic invariants

### Grammar and compilation

1. Select the main grammar before interpreting its option bits. Several bits
   intentionally mean different things in basic and Perl syntax. Emacs extends
   basic syntax and selects Perl matching; extended POSIX syntax uses the
   extended parser with Perl extensions disabled.
2. Scoped modifiers affect the remainder of their lexical scope, including
   alternatives parsed later. Closing the surrounding group restores the
   enclosing flags. Literal nodes may embed the effective flags, provided this
   lexical behavior is preserved.
3. `nosubs` changes capture numbering during parsing. Suppressing result output
   after allocating all normal capture groups is not equivalent. Runtime
   `match_nosubs` separately suppresses capture register writes.
4. A production retains the original opening/current byte offsets needed by its
   source-defined error path. Quantifier range parsing is transactional: some
   malformed ranges become literal text under Perl rules; basic/extended error
   rules differ. A generic “all failures occur at the current cursor” policy is
   insufficient. Preserve the first error and distinguish an invalid regex
   object returned under `no_except` from a valid empty pattern.

### Execution and captures

5. Perl selection follows ordered depth-first backtracking. Greedy and lazy
   repeats select opposite branches after satisfying the minimum. `match_any`
   changes repeat preference, except within an independent expression.
6. A capture register contains **start, end, and matched separately**. Opening a
   group updates its start and saves its previous register; it does not clear
   its previous end/matched fields. Failure restores the saved register.
   Successful completion records the end and last closed group.
7. Capture histories are derived from capture records on the successful unwind
   path. They are not a log of every attempted capture close. Assertions,
   independent groups and recursion must preserve the source's unwind behavior
   before histories can be published.
8. A recursive frame retains its target, entry position, return continuation and
   caller result registers. Successful return restores caller results while
   retaining consumed input. Backtracking back into the call restores the
   callee state. A same-target recursive re-entry at the same input position
   fails that path, using the nearest prior frame of that target.
9. Assertions and independent groups are execution scopes. Assertions restore
   input position, while their positive/negative result and capture effects
   follow typed unwind rules. PRUNE/SKIP/COMMIT/THEN are unwind actions and cannot
   be implemented merely by deleting arbitrary alternatives at encounter time.

### Empty matches, partial results and selection

10. A zero-length repeat saturates its repeat counter, preventing an infinite
    loop even if the nominal minimum has not been reached. This is separate
    from iteration: after an empty match, `match_not_initial_null` rejects the
    initial empty result but permits a nonempty alternative at the same offset.
11. `partial` is an attempt-level observation of failure at end of input after
    progress. Only if no complete match is found does the matcher publish a
    partial result, after ordinary failure unwind. It sets group zero's extent
    to the end of input with `matched=false`. Returning a saved first failure
    snapshot leaks the wrong captures. Nested assertion failure also contributes
    to this attempt-level state.
12. POSIX selection compares groups in index order, beginning with group zero.
    For each group, leftmost start precedes longest length, with the source's
    matched/unmatched end-of-input tie rules. Longest total match followed by
    longest subgroup alone is not the algorithm.
13. The original input start (backstop), search continuation and attempt start
    are distinct. They govern anchors, lookbehind, prefix, `\G`, and
    `match_not_initial_null`. Public ranges always retain original byte units.

14. Start maps are part of the source's execution mechanism. They select viable
    alternatives/repeat continuations and determine whether a search attempts
    end of input. Their conservative rules for backreferences, assertion end
    states and recursive references must be retained. Zero-prefix recursion is
    checked while constructing those maps; a generic syntax-tree nullability
    test is not equivalent.
15. A repeat of one byte, byte set or dot has a dedicated execution path and one
    retained backtrack record. Its greedy unwind moves backwards; lazy unwind
    consumes forward until the continuation can start. These unwind paths also
    update partial state. More complex repeated expressions use counters and
    ordinary alternatives. A failed leading repeat can advance the next search
    restart, unless backreferences make that optimization inapplicable.
16. Ordinary bracket sets compile to a byte map. Sets containing two-byte
    collating elements keep ordered singles and a separate map for ranges,
    equivalence and character classes. Original element spelling determines the
    ordering before case translation. A failed two-byte element does not move
    the input cursor. Negative character-class masks are combined before their
    complement is added to the set.
17. Successful assertion unwind can leave capture history behind after the rest
    of that search attempt fails. Starting the next attempt resets capture
    registers while retaining those histories, as `match_results::set_first`
    does. This is separate from capturing only successful paths within an
    individual execution scope.
18. Incompatible matching modes and execution of an invalid `no_except` object
    are operation errors. They have no fabricated Boost `regex_error` code or
    pattern offset. `RegexError::code()` and `position()` are therefore optional;
    ordinary syntax/resource errors retain their actual code and position.

## Current implementation structure

The parser produces an arena of syntax nodes with lexical flags and capture
references. Compilation lowers it to a fixed instruction graph, then drops the
syntax arena. The compiled graph and start metadata are owned by an `Arc` and
have no mutable invocation state.

| Module | Responsibility |
| --- | --- |
| `syntax.rs` | Grammar productions, lexical modifier scope, reference numbering, first error position |
| `charset.rs` | Classic-C byte classification, collating names and bracket-set representations |
| `compile.rs` | Fixed instruction addresses, recursive targets, fixed-width lookbehind |
| `start.rs` | Ordered branch maps, conservative nullability, recursion checks and search restart strategy |
| `registers.rs` | Internal start/end/matched registers, histories, POSIX candidate comparison and public range conversion |
| `execute.rs` | Match-local typed unwind records, recursive calls, assertions, control verbs and optimized single-state repeats |
| `lib.rs` | Safe public byte API, shared compiled ownership, iterator continuation and replacement orchestration |
| `format.rs` | Replacement formatting; its initial API regressions pass, with the full formatter source review still pending |

An ordinary alternative saves a continuation and input position rather than
copying every capture, history and repeat counter. Capture and counter changes
have typed restore records. Recursive calls save caller registers and repeat
context; POSIX selection saves candidate results. Allocation accounting covers
actual vector capacities and records, including nested scopes. Search attempts
reuse invocation storage while following the source's capture-history rules.

The typed execution refactor, explicit grammar selection, transactional repeat
ranges, source-aware errors, bracket-set representation and compiled start
analysis are present in this checkpoint. Full independent comparison remains
necessary, especially across nested recursion/control scopes, all option
combinations and formatter behavior. Implemented productions do not imply that
all combinations have passed acceptance.

## Verification and release boundary

Public API tests should assert the invariants across grammar/option combinations
and nested execution scopes. The independent Boost oracle and mapped upstream
tests then check complete observable results: error category/position, all
captures and histories, partial extent, prefix/suffix, iteration and formatting.
No unsupported or resource-error result is counted as an ordinary match pass.

ADR-0003 permits independent configurable engine limits; it does not waive the
fixed performance/memory acceptance. The current budget values and bounded-record
regressions do not constitute performance acceptance. Native locale, Unicode,
all six platform targets and full library completion remain separate open work.
