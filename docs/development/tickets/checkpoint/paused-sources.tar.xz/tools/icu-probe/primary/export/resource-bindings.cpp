// Development-only direct decoding of the complete ICU77 collation resources.
// ICU provenance: ../data/NOTICE.md and ../data/LICENSE-ICU.txt.
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>
#include <unicode/uchar.h>
#include <unicode/ulocdata.h>
#include <unicode/uversion.h>
#include "collationdatareader.h"
#include "collationroot.h"
#include "collationtailoring.h"
#include "locale_data.h"
#include "locale_resources.h"

namespace fixed_fallback {
#define INCLUDED_FROM_URESBUND_CPP
#include "localefallback_data.h"
#undef INCLUDED_FROM_URESBUND_CPP
}

#if U_ICU_VERSION_MAJOR_NUM != 77 || U_ICU_VERSION_MINOR_NUM != 1
#error This exporter requires official ICU4C 77.1 headers.
#endif

namespace {
using export77::require;

std::string quote(const std::string& value) {
    std::ostringstream out;
    out << '"';
    for (unsigned char ch : value) {
        if (ch == '"' || ch == '\\') out << '\\' << ch;
        else if (ch < 0x20) out << "\\u" << std::hex << std::setw(4) << std::setfill('0') << unsigned(ch);
        else out << ch;
    }
    out << '"';
    return out.str();
}

void verify_versions() {
    UVersionInfo runtime{}, unicode{}, cldr{};
    UErrorCode status = U_ZERO_ERROR;
    u_getVersion(runtime); u_getUnicodeVersion(unicode); ulocdata_getCLDRVersion(cldr, &status);
    require(U_SUCCESS(status) && runtime[0] == 77 && runtime[1] == 1 &&
            unicode[0] == 16 && unicode[1] == 0 && cldr[0] == 47 && cldr[1] == 0,
            "Runtime versions differ from ICU77/Unicode16/CLDR47");
}

std::vector<std::string> lines(const char* path) {
    std::ifstream input(path);
    require(input.good(), "Cannot read complete resource name list");
    std::vector<std::string> result;
    std::string line;
    while (std::getline(input, line)) {
        require(!line.empty() && line.find_first_not_of("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_") == std::string::npos,
                "Resource name is outside the packaged ASCII basename domain");
        result.push_back(line);
    }
    require(input.eof() && !result.empty(), "Resource name enumeration failed");
    return result;
}

std::string stem(size_t index) {
    std::ostringstream result;
    result << "resource-" << std::setw(4) << std::setfill('0') << index;
    return result.str();
}

void write_bindings(std::ostream& out, const std::vector<std::string>& names, const std::filesystem::path& directory) {
    UErrorCode status = U_ZERO_ERROR;
    const auto* root_entry = icu::CollationRoot::getRootCacheEntry(status);
    require(U_SUCCESS(status) && root_entry != nullptr, "Cannot load fixed root tailoring");
    const auto* root = root_entry->tailoring;
    export77::write_owner((directory / "root-owner.bin").string(), *root->data);
    export77::write_settings((directory / "root-settings.bin").string(), *root->settings);
    size_t next = 0;
    out << "\"bindings\":[\n";
    for (const auto& name : names) {
        export77::RawResource bundle(name);
        const auto& data = bundle.data;
        const auto collations = res_getResource(&data, "collations");
        if (collations == RES_BOGUS || res_getPublicType(collations) == URES_ALIAS) continue;
        require(res_getPublicType(collations) == URES_TABLE, "Unexpected collations resource type");
        for (const auto& type : export77::resource_keys(data, collations)) {
            const auto value = export77::child(data, collations, type.c_str());
            if (res_getPublicType(value) != URES_TABLE) continue;
            const auto binary = export77::child(data, value, "%%CollationBin");
            if (binary == RES_BOGUS) continue;
            int32_t length = 0;
            const auto* bytes = res_getBinaryNoTrace(&data, binary, &length);
            require(bytes != nullptr && length > 0, "Invalid raw collation binary");
            icu::CollationTailoring tailoring(root->settings);
            require(!tailoring.isBogus(), "Cannot initialize binary tailoring");
            status = U_ZERO_ERROR;
            icu::CollationDataReader::read(root, bytes, length, tailoring, status);
            require(U_SUCCESS(status) && tailoring.data != nullptr, "Direct raw collation binary decoding failed");
            require(tailoring.data == root->data || tailoring.data->base == root->data,
                    "Direct binary references an unexported base owner");
            const auto id = stem(next);
            export77::write_owner((directory / (id + "-owner.bin")).string(), *tailoring.data);
            export77::write_settings((directory / (id + "-settings.bin")).string(), *tailoring.settings);
            std::ofstream raw(directory / (id + "-collation.bin"), std::ios::binary);
            raw.write(reinterpret_cast<const char*>(bytes), length); raw.flush();
            require(raw.good(), "Raw collation binary write failed");
            out << (next ? ",\n" : "") << "{\"bundle\":" << quote(name) << ",\"type\":" << quote(type)
                << ",\"stem\":" << quote(id) << ",\"binary_bytes\":" << length
                << ",\"status\":" << quote(u_errorName(status))
                << ",\"uses_root_owner\":" << (tailoring.data == root->data ? "true" : "false") << '}';
            ++next;
        }
    }
    out << "\n]";
}

void aliases_at_length(std::map<std::string, int32_t>& aliases, std::string& token, size_t position) {
    if (position == token.size()) {
        const auto code = u_getPropertyValueEnum(UCHAR_SCRIPT, token.c_str());
        if (code >= 0) aliases.emplace(token, code);
        return;
    }
    for (char ch = 'a'; ch <= 'z'; ++ch) {
        token[position] = ch;
        aliases_at_length(aliases, token, position + 1);
    }
}

void write_aliases(std::ostream& out) {
    std::map<std::string, int32_t> aliases;
    for (size_t length = 1; length <= 4; ++length) {
        std::string token(length, 'a');
        aliases_at_length(aliases, token, 0);
    }
    out << ",\n\"script_alias_domain\":\"Every lowercase ASCII alphabetic string of length 1 through 4\","
        << "\n\"script_alias_queries\":475254,\n\"script_aliases\":[\n";
    bool first = true;
    for (const auto& item : aliases) {
        out << (first ? "" : ",\n") << "{\"name\":" << quote(item.first) << ",\"code\":" << item.second << '}';
        first = false;
    }
    out << "\n]";
}

void write_default_scripts(std::ostream& out) {
    constexpr auto count = sizeof(fixed_fallback::defaultScriptTable) / sizeof(int32_t);
    static_assert(count % 2 == 0, "Default script table must contain offset pairs");
    std::map<std::string, std::string> mappings;
    for (size_t i = 0; i < count; i += 2) {
        const auto locale = fixed_fallback::defaultScriptTable[i];
        const auto script = fixed_fallback::defaultScriptTable[i + 1];
        require(locale >= 0 && size_t(locale) < sizeof(fixed_fallback::dsLocaleIDChars) &&
                script >= 0 && size_t(script) < sizeof(fixed_fallback::scriptCodeChars), "Default script offsets outside source arrays");
        const bool inserted = mappings.emplace(fixed_fallback::dsLocaleIDChars + locale,
                                               fixed_fallback::scriptCodeChars + script).second;
        require(inserted, "Duplicate locale in default script table");
    }
    out << ",\n\"default_script_fallback\":\"Latn\",\n\"default_scripts\":[\n";
    bool first = true;
    for (const auto& item : mappings) {
        out << (first ? "" : ",\n") << "{\"locale\":" << quote(item.first) << ",\"script\":" << quote(item.second) << '}';
        first = false;
    }
    out << "\n]";
}
}  // namespace

int main(int argc, char** argv) {
    if (argc != 4) { std::cerr << "usage: resource-bindings RESOURCE_NAMES DATA_DIRECTORY OUTPUT_JSON\n"; return 2; }
    try {
        verify_versions();
        std::ofstream out(argv[3]);
        require(out.good(), "Cannot create resource binding JSON");
        out << "{\n\"schema\":\"boostregexrs.icu77-raw-resource-bindings.v1\",\n";
        write_bindings(out, lines(argv[1]), argv[2]);
        write_aliases(out);
        write_default_scripts(out);
        out << "\n}\n"; out.flush(); require(out.good(), "Resource binding JSON write failed");
        return 0;
    } catch (const std::exception& error) { std::cerr << "resource-bindings: " << error.what() << '\n'; return 1; }
}
