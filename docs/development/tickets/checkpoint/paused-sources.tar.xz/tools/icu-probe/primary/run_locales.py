#!/usr/bin/env python3
"""Compare complete ICU77/Boost keys for every exported owner/settings combination.

The candidate receives source data and effective settings, not a locale-to-key
lookup. Locale ID parsing is recorded as an unexercised, separate capability.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import importlib.util
import itertools
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

from compare import compare, rows, sha256
from generate_cases import SEED, contexts, directed, historical, input_boundaries, write_cases
from reference_process import run_reference
from run import PRIMARY, REPO, command_log, run_to_file

sys.path.insert(0, str(PRIMARY / "export"))
from data_format import context_report, read_data  # noqa: E402
from locale_format import read_owner  # noqa: E402


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")


def identity(path):
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)}


def source_data_identity(data_directory, catalog):
    records = []
    for item in catalog["owner_files"]:
        path = PRIMARY / "data/root-icu77.bin" if item["id"] == 0 else data_directory / item["file"]
        actual = identity(path)
        if actual["sha256"] != item["sha256"]:
            raise ValueError("Owner data differs from the frozen catalog")
        records.append(actual)
    for item in catalog["settings_files"]:
        actual = identity(data_directory / item["path"])
        if actual["sha256"] != item["sha256"]:
            raise ValueError("Effective settings differ from the frozen catalog")
        records.append(actual)
    records.append(identity(PRIMARY / "data/root-icu77-nfd.bin"))
    return records


def configuration_id(configuration):
    return f"owner-{configuration['owner']:04d}-settings-{configuration['settings']:04d}"


def configurations(catalog):
    grouped = {}
    for row in catalog["requests"]:
        if row["status"] == "loaded":
            grouped.setdefault((row["owner"], row["settings"]), []).append(row)
    result = []
    for (owner, settings), aliases in sorted(grouped.items()):
        selected = min(aliases, key=lambda row: (row["requested"] != "root", len(row["requested"]), row["requested"]))
        result.append({"owner": owner, "settings": settings, "locale": selected["requested"],
                       "source_request": selected,
                       "equivalent_exported_requests": [row["requested"] for row in aliases]})
    return result


def mechanism_module():
    path = PRIMARY / "rust/tests/locale_cases.py"
    specification = importlib.util.spec_from_file_location("icu77_locale_cases", path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module, path


def prepare_inputs(output, generated_count):
    directory = output / "inputs"
    directory.mkdir()
    module, generator = mechanism_module()
    common = directory / "common-utf8.tsv"
    count = write_cases(common, itertools.chain(historical(), module.directed(), module.generated(generated_count, SEED)))
    inputs = {"common": {"path": common, "kind": "utf8", "count": count}}
    for kind in ("u16", "u32"):
        path = directory / f"boundaries-{kind}.tsv"
        count = write_cases(path, input_boundaries(kind), kind)
        inputs[kind] = {"path": path, "kind": kind, "count": count}
    empty = directory / "original-empty-utf8.tsv"
    write_cases(empty, [("original-empty", "")])
    origins = directory / "identical-expectation-origins.tsv"
    with origins.open("w", encoding="utf-8") as stream:
        stream.write("case_id\texpectation_source\n")
        for row in rows(common, ("case_id", "utf8_hex")):
            source = "adr0005_valid_pointer_empty" if not row["utf8_hex"] else "original_boost_call"
            stream.write(f"{row['case_id']}\t{source}\n")
    save(directory / "generation.json", {
        "schema": "boostregexrs.icu77-locales-inputs.v1", "seed": f"0x{SEED:016x}",
        "random_algorithm": "SplitMix64", "generated_count": generated_count,
        "host_unicode_database_used": False, "reference_keys_used_to_choose_inputs": False,
        "generator": identity(generator),
        "inputs": {name: {**record, "path": str(record["path"]), "sha256": sha256(record["path"])} for name, record in inputs.items()},
        "identical_expectation_origins": identity(origins),
    })
    return inputs, empty


def owner_scalars(owner, data):
    start = 0
    for end, ce32 in data["ce32_ranges"]:
        if owner == 0 or ce32 != 0xC0:
            for codepoint in range(start, end + 1):
                if not 0xD800 <= codepoint <= 0xDFFF:
                    yield f"owner_scalar/{codepoint:06x}", chr(codepoint)
        else:
            for codepoint in sorted({start, end}):
                if not 0xD800 <= codepoint <= 0xDFFF:
                    yield f"fallback_boundary/{codepoint:06x}", chr(codepoint)
        start = end + 1


def owner_inputs(output, owner, data_directory, catalog):
    path = output / "inputs" / f"owner-{owner:04d}-utf8.tsv"
    source = PRIMARY / "data/root-icu77.bin" if owner == 0 else data_directory / catalog["owner_files"][owner]["file"]
    data = read_data(source) if owner == 0 else read_owner(source)
    report = path.with_suffix(".contexts.json")
    save(report, context_report(data))
    long_cases = ((name, value) for name, value in directed() if name.startswith("long/"))
    count = write_cases(path, itertools.chain(owner_scalars(owner, data), contexts(report), long_cases))
    return {"path": path, "kind": "utf8", "count": count}


def commands(configuration, strength, kind, oracle, candidate, data_directory, catalog):
    reference = [oracle, "--locale", configuration["locale"], "--strength", strength, "--input-format", kind]
    if strength == "identical":
        reference.append("--approved-empty-exception")
    actual = [candidate, "--settings", data_directory / catalog["settings_files"][configuration["settings"]]["path"],
              "--strength", strength, "--input-format", kind,
              "--data", PRIMARY / "data/root-icu77.bin", "--nfd-data", PRIMARY / "data/root-icu77-nfd.bin"]
    if configuration["owner"]:
        actual += ["--owner", data_directory / catalog["owner_files"][configuration["owner"]]["file"]]
    return reference, actual


def check_metadata(metadata, settings, strength):
    expected = {**settings["attributes"], "strength": 0 if strength == "primary" else 15}
    if any(metadata["attributes"][key] != value for key, value in expected.items()):
        raise ValueError("Native locale attributes differ from the exported effective settings")
    if metadata["variable_top"] != settings["variable_top"] or metadata["reorder_codes"] != settings["reorder_codes"]:
        raise ValueError("Native variableTop/reorderCodes differ from exported settings")


def run_group(output, phase, configuration, strength, inputs, oracle, candidate, data_directory,
              catalog, native_environment, rust_environment):
    relative = Path(phase) / configuration_id(configuration) / strength / inputs["kind"]
    group = output / relative
    group.mkdir(parents=True)
    expected, actual = group / "expected-keys.tsv", group / "candidate-keys.tsv"
    reference_command, candidate_command = commands(configuration, strength, inputs["kind"], oracle, candidate, data_directory, catalog)
    with ThreadPoolExecutor(max_workers=2) as pool:
        reference_future = pool.submit(run_reference, reference_command + ["--metadata", group / "oracle-metadata.json"],
                                       inputs["path"], expected, native_environment, REPO)
        candidate_future = pool.submit(run_to_file, candidate_command, inputs["path"], actual, rust_environment)
        process = reference_future.result()
        candidate_future.result()
    metadata = json.loads((group / "oracle-metadata.json").read_text())
    check_metadata(metadata, catalog["settings"][configuration["settings"]], strength)
    summary = compare(inputs["path"], expected, actual, inputs["kind"], strength=strength,
                      approved_empty_exceptions=strength == "identical", locale=configuration["locale"])
    if not process["reference_error_free"]:
        summary["status"] = "differences_or_incomplete"
    summary.update(configuration=configuration, strength=strength, phase=phase,
                   input=identity(inputs["path"]), reference_process=process, oracle_metadata=metadata,
                   commands={"reference": [str(arg) for arg in reference_command],
                             "candidate": [str(arg) for arg in candidate_command]})
    save(group / "summary.json", summary)
    return {"path": str(relative), "configuration": configuration_id(configuration),
            "owner": configuration["owner"], "settings": configuration["settings"],
            "locale": configuration["locale"], "strength": strength, "input_format": inputs["kind"],
            "input": str(inputs["path"].relative_to(output)), "case_count": summary["case_count"],
            "status": summary["status"], "totals": summary["totals"]}, summary


def original_empty(output, configuration, empty, oracle, native_environment):
    directory = output / "original-empty" / configuration_id(configuration)
    directory.mkdir(parents=True)
    return run_reference([oracle, "--locale", configuration["locale"], "--strength", "identical"],
                         empty, directory / "original-boost-keys.tsv", native_environment, REPO)


def build_oracle(cache, output):
    build = cache / "build/locales"
    build.mkdir(parents=True, exist_ok=True)
    oracle = build / "oracle"
    command_log(["c++", "-std=c++17", "-O2", "-Wall", "-Wextra", "-Werror",
                 "-I", cache / "deps/boost_1_89_0", "-I", cache / "install/icu/include", PRIMARY / "oracle.cpp",
                 "-L", cache / "install/icu/lib", "-Wl,-rpath," + str(cache / "install/icu/lib"),
                 "-licui18n", "-licuuc", "-licudata", "-o", oracle], output / "oracle-build.log")
    return oracle


def run(args):
    cache, data_directory, candidate = args.cache.resolve(), args.data_directory.resolve(), args.candidate.resolve()
    output = (args.output or REPO / "docs/research/assets/icu77-locales/runs" /
              dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H%M%S.%fZ")).resolve()
    output.mkdir(parents=True, exist_ok=False)
    oracle = build_oracle(cache, output)
    catalog_path = data_directory / "catalog.json"
    catalog = json.loads(catalog_path.read_text())
    configurations_list = configurations(catalog)
    inputs, empty = prepare_inputs(output, args.generated)
    save(output / "configurations.json", configurations_list)
    native = dict(os.environ)
    native.pop("ICU_DATA", None)
    native["LD_LIBRARY_PATH"] = str(cache / "install/icu/lib")
    rust = dict(os.environ)
    rust.pop("LD_LIBRARY_PATH", None)
    rust["ICU_DATA"] = str(cache / "intentionally-absent-icu-data")
    result = {
        "schema": "boostregexrs.icu77-locales-fullkeys.v1", "status": "running",
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "groups": [], "original_empty": {},
        "coverage_profile": "mechanism_diagnostic" if args.mechanisms_only else "full_recorded_locale_data_suite",
        "configuration_count": len(configurations_list), "owner_count": len(catalog["owners"]),
        "catalog_request_count": len(catalog["requests"]),
        "locale_creation_reference_rejections": [row for row in catalog["requests"] if row["status"] != "loaded"],
        "deduplication": "Only identical source owner and complete effective settings share key runs; every configuration remains in configurations.json",
        "candidate_ingress": "Owner/settings API; locale ID parsing and default-locale acquisition are not exercised by this runner",
        "approved_exception_policy": "ADR-0005 true empty IDENTICAL only, independently counted; original native calls remain separate diagnostics",
        "identity": {"catalog": identity(catalog_path), "candidate": identity(candidate), "oracle": identity(oracle),
                     "root": identity(PRIMARY / "data/root-icu77.bin"), "nfd": identity(PRIMARY / "data/root-icu77-nfd.bin"),
                     "runtime_data_files": source_data_identity(data_directory, catalog),
                     "python": sys.version, "platform": platform.platform(),
                     "sources": [identity(PRIMARY / name) for name in ("run_locales.py", "oracle.cpp", "compare.py", "generate_cases.py", "rust/tests/locale_cases.py")]},
    }
    completed = False
    snapshot = output / "generator-snapshot"
    snapshot.mkdir()
    for source in result["identity"]["sources"]:
        path = Path(source["path"])
        shutil.copyfile(path, snapshot / path.name)
    try:
        for index, configuration in enumerate(configurations_list):
            for name in ("common", "u16", "u32"):
                for strength in ("primary", "identical"):
                    item, summary = run_group(output, name, configuration, strength, inputs[name], oracle, candidate,
                                              data_directory, catalog, native, rust)
                    result["groups"].append(item)
                    if item["status"] != "passed_for_recorded_inputs":
                        result["first_incomplete_group"] = item
                        print(json.dumps({"first_incomplete": item, "examples": summary["examples"][:3]}), flush=True)
                        return result, output
            result["original_empty"][configuration_id(configuration)] = original_empty(output, configuration, empty, oracle, native)
            if (index + 1) % 10 == 0 or index == 0:
                print(f"locale configurations complete: {index + 1}/{len(configurations_list)}", flush=True)
        if not args.mechanisms_only:
            for owner in range(len(catalog["owners"])):
                configuration = min((row for row in configurations_list if row["owner"] == owner),
                                    key=lambda row: (not row["source_request"]["default_attributes"], row["settings"]))
                owner_cases = owner_inputs(output, owner, data_directory, catalog)
                for strength in ("primary", "identical"):
                    item, summary = run_group(output, "owner-data", configuration, strength, owner_cases, oracle, candidate,
                                              data_directory, catalog, native, rust)
                    result["groups"].append(item)
                    if item["status"] != "passed_for_recorded_inputs":
                        result["first_incomplete_group"] = item
                        print(json.dumps({"first_incomplete": item, "examples": summary["examples"][:3]}), flush=True)
                        return result, output
                print(f"owner data complete: {owner + 1}/{len(catalog['owners'])}, {owner_cases['count']} inputs", flush=True)
        completed = True
        return result, output
    except Exception as error:
        result["execution_error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        result["completed_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
        result["status"] = "passed_for_recorded_inputs" if completed else "differences_or_incomplete"
        result["totals"] = {name: sum(group["totals"].get(name, 0) for group in result["groups"])
                            for name in ("passed", "mismatched", "unsupported", "reference_error", "rejected_as_expected", "approved_exception_passed")}
        result["original_empty_reference_error_count"] = sum(row["reference_error_count"] for row in result["original_empty"].values())
        result["completed_configurations"] = len(result["original_empty"])
        result["completed_owner_data_groups"] = sum(group["path"].startswith("owner-data/") for group in result["groups"])
        fixed = [result["identity"][key] for key in ("candidate", "oracle", "catalog")]
        fixed += result["identity"]["runtime_data_files"]
        result["identities_unchanged_during_run"] = all(sha256(Path(item["path"])) == item["sha256"] for item in fixed)
        if not result["identities_unchanged_during_run"]:
            result["status"] = "differences_or_incomplete"
        save(output / "summary.json", result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=REPO / "target/research/icu77-cloud")
    parser.add_argument("--data-directory", type=Path, default=PRIMARY / "data/locales")
    parser.add_argument("--candidate", type=Path, default=REPO / "target/research/icu77-cloud/build/locales-rust/release/icu77-root-primary")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--generated", type=int, default=512)
    parser.add_argument("--mechanisms-only", action="store_true", help="explicit diagnostic: skip owner scalar/context/long-input sweep")
    args = parser.parse_args()
    if args.generated < 0:
        parser.error("--generated must be nonnegative")
    result, output = run(args)
    print(json.dumps({"status": result["status"], "totals": result["totals"], "evidence": str(output)}))
    return int(result["status"] != "passed_for_recorded_inputs")


if __name__ == "__main__":
    raise SystemExit(main())
