#!/usr/bin/env python3
"""Preserve a narrow CE diagnostic for the recorded mismatches in one locale group.

The original complete-key reference is copied after hash verification. The new
native process supplies independent CE traces using the locale's actual FCD and
numeric settings. This is a new diagnostic run, never a replacement of history.
"""

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import subprocess
import sys

from compare import compare, rows, sha256
from run import PRIMARY, REPO, command_log
from run_locales import commands, identity, save

sys.path.insert(0, str(PRIMARY / "export"))
from generate import SOURCE_FILES, verify_source  # noqa: E402


def capture(command, source, output, environment):
    with source.open("rb") as stdin, output.open("wb") as stdout, output.with_suffix(".stderr.log").open("wb") as stderr:
        result = subprocess.run([str(arg) for arg in command], stdin=stdin, stdout=stdout,
                                stderr=stderr, env=environment, cwd=REPO)
    if result.returncode:
        raise RuntimeError(f"Diagnostic process exited {result.returncode}: {output}")
    return {"command": [str(arg) for arg in command], "exit_code": result.returncode,
            "input": identity(source), "stdout": identity(output), "stderr": identity(output.with_suffix(".stderr.log"))}


def subset(group, output):
    summary_path = group / "summary.json"
    summary = json.loads(summary_path.read_text())
    if summary["input_format"] != "utf8":
        raise ValueError("This diagnostic currently requires a UTF-8 full-key group")
    selected = [item["case"] for item in summary["examples"] if item["outcome"] == "mismatched"]
    if not selected:
        raise ValueError("The group has no recorded mismatch examples")
    source = Path(summary["input"]["path"])
    expected = group / "expected-keys.tsv"
    if sha256(source) != summary["sha256"]["cases"] or sha256(expected) != summary["sha256"]["reference"]:
        raise ValueError("Historical input/reference no longer matches its recorded hash")
    selected_ids = {item["case_id"] for item in selected}
    historical = {row["case_id"]: row for row in rows(source, ("case_id", "utf8_hex")) if row["case_id"] in selected_ids}
    if len(historical) != len(selected) or any(historical[row["case_id"]] != row for row in selected):
        raise ValueError("Mismatch examples differ from the historical input rows")
    with (output / "input-utf8.tsv").open("w", encoding="utf-8") as utf8, (output / "input-u16.tsv").open("w", encoding="utf-8") as u16:
        utf8.write("case_id\tutf8_hex\n")
        u16.write("case_id\tu16_hex\n")
        for row in selected:
            utf8.write(row["case_id"] + "\t" + row["utf8_hex"] + "\n")
            encoded = bytes.fromhex(row["utf8_hex"]).decode("utf-8").encode("utf-16-le")
            units = [f"{int.from_bytes(encoded[i:i+2], 'little'):04x}" for i in range(0, len(encoded), 2)]
            u16.write(row["case_id"] + "\t" + ",".join(units) + "\n")
    header = ("case_id", "raw_icu_hex", "boost_u32_hex")
    reference = {row["case_id"]: row for row in rows(expected, header) if row["case_id"] in selected_ids}
    with (output / "expected-keys.tsv").open("w", encoding="utf-8") as stream:
        stream.write("\t".join(header) + "\n")
        for row in selected:
            stream.write("\t".join(reference[row["case_id"]][key] for key in header) + "\n")
    return summary, {"summary": identity(summary_path), "input": identity(source), "reference": identity(expected),
                     "selected_case_ids": [row["case_id"] for row in selected], "selection": "Recorded mismatched examples only"}


def run(args):
    cache, group, candidate, data = args.cache.resolve(), args.group.resolve(), args.candidate.resolve(), args.data_directory.resolve()
    output = (args.output or REPO / "docs/research/assets/icu77-locales/diagnostics" /
              dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H%M%S.%fZ")).resolve()
    output.mkdir(parents=True, exist_ok=False)
    historical, origin = subset(group, output)
    catalog = json.loads((data / "catalog.json").read_text())
    native_environment = dict(os.environ)
    native_environment.pop("ICU_DATA", None)
    prefix = cache / "install/icu"
    native_environment["LD_LIBRARY_PATH"] = str(prefix / "lib")
    rust_environment = dict(os.environ)
    rust_environment.pop("LD_LIBRARY_PATH", None)
    rust_environment["ICU_DATA"] = str(cache / "intentionally-absent-icu-data")
    source, source_files = verify_source(cache, SOURCE_FILES + ("source/common/uvectr64.h", "source/i18n/unicode/tblcoll.h"))
    executable = cache / "build/locale-trace/trace-locale"
    executable.parent.mkdir(parents=True, exist_ok=True)
    command_log(["c++", "-std=c++17", "-O2", "-Wall", "-Wextra", "-Werror", "-DU_STATIC_IMPLEMENTATION",
                 "-I", prefix / "include", "-I", cache / "deps/icu/source/common", "-I", cache / "deps/icu/source/i18n",
                 PRIMARY / "export/trace-locale.cpp", *[prefix / "lib" / name for name in ("libicui18n.a", "libicuuc.a", "libicudata.a")],
                 "-lpthread", "-ldl", "-lm", "-o", executable], output / "build.log", native_environment)
    configuration = historical["configuration"]
    _, actual = commands(configuration, historical["strength"], "utf8", executable, candidate, data, catalog)
    before = {"candidate": identity(candidate), "native_ce_trace": identity(executable), "catalog": identity(data / "catalog.json")}
    native_process = capture([executable, configuration["locale"]], output / "input-u16.tsv", output / "native-ces.tsv", native_environment)
    candidate_process = capture(actual + ["--trace"], output / "input-utf8.tsv", output / "candidate-keys.tsv", rust_environment)
    comparison = compare(output / "input-utf8.tsv", output / "expected-keys.tsv", output / "candidate-keys.tsv",
                         strength=historical["strength"], locale=configuration["locale"],
                         approved_empty_exceptions=historical["strength"] == "identical")
    result = {"schema": "boostregexrs.icu77-locale-ce-diagnostic.v1", "completed_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
              "historical_group": origin, "new_run": True, "historical_raw_replaced": False,
              "configuration": configuration, "strength": historical["strength"], "identity": before,
              "identity_unchanged": before == {"candidate": identity(candidate), "native_ce_trace": identity(executable), "catalog": identity(data / "catalog.json")},
              "source": source, "source_files": source_files,
              "generator_files": [identity(Path(__file__)), identity(PRIMARY / "export/trace-locale.cpp")],
              "native_process": native_process, "candidate_process": candidate_process, "full_key_comparison": comparison,
              "ce_contract": "ICU RuleBasedCollator::internalGetCEs using actual FCD/numeric settings; successful omitted NO_CE marker appended for trace alignment"}
    save(output / "summary.json", result)
    print(json.dumps({"output": str(output), "full_key_totals": comparison["totals"], "candidate": before["candidate"]}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--group", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=REPO / "target/research/icu77-cloud")
    parser.add_argument("--candidate", type=Path, default=REPO / "target/research/icu77-cloud/build/locales-rust/release/icu77-root-primary")
    parser.add_argument("--data-directory", type=Path, default=PRIMARY / "data/locales")
    parser.add_argument("--output", type=Path)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
