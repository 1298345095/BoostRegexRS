#!/usr/bin/env python3
"""Portable source-data formats for ICU77 collation resource resolution."""

import struct

from locale_format import begin, finish


class Writer:
    def __init__(self, magic):
        self.value = bytearray(magic + struct.pack("<7I", 1, 77, 1, 16, 0, 47, 0))

    def u32(self, value):
        self.value.extend(struct.pack("<I", value))

    def string(self, value):
        encoded = value.encode("ascii")
        if b"\0" in encoded:
            raise ValueError("NUL is not allowed in resource metadata strings")
        self.u32(len(encoded))
        self.value.extend(encoded)


def write_resources(value):
    out = Writer(b"BRSRES77")
    out.value.extend(bytes.fromhex(value["catalog_sha256"]))
    for field in ("owner_count", "settings_count", "root_owner", "root_settings"):
        out.u32(value[field])
    out.u32(len(value["bundles"]))
    for bundle in value["bundles"]:
        for field in ("locale", "bundle_alias", "explicit_parent", "collations_alias"):
            out.string(bundle[field])
        out.u32(int(bundle["no_fallback"]) | (int(bundle["parent_is_root"]) << 1) |
                (int("collations" in bundle["keys"]) << 2))
        out.u32(len(bundle["types"]))
        for item in bundle["types"]:
            out.string(item["name"])
            out.u32(item["resource_type"])
            out.string(item["alias"] if item["resource_type"] == 3 else item["string_value"])
            out.u32(int(item["has_binary"]))
            out.u32(item.get("owner", 0xffffffff))
            out.u32(item.get("settings", 0xffffffff))
    return bytes(out.value)


def write_aliases(value):
    out = Writer(b"BRSSAL77")
    out.u32(len(value))
    for item in value:
        out.string(item["name"])
        out.u32(item["code"])
    return bytes(out.value)


def write_default_scripts(fallback, value):
    out = Writer(b"BRSDST77")
    out.string(fallback)
    out.u32(len(value))
    for item in value:
        out.string(item["locale"])
        out.string(item["script"])
    return bytes(out.value)


def string(reader):
    value = reader.take(reader.u32()).decode("ascii")
    if "\0" in value:
        raise ValueError("NUL in resource metadata string")
    return value


def ascending(previous, current):
    if previous is not None and previous >= current:
        raise ValueError("Metadata keys must be strictly increasing")
    return current


def read_resources(path):
    reader, result = begin(path, b"BRSRES77")
    result.update(catalog_sha256=reader.take(32).hex(), owner_count=reader.u32(), settings_count=reader.u32(),
                  root_owner=reader.u32(), root_settings=reader.u32(), bundles=[])
    if result["root_owner"] >= result["owner_count"] or result["root_settings"] >= result["settings_count"]:
        raise ValueError("Root resource binding outside catalog")
    previous = None
    for _ in range(reader.u32()):
        bundle = {field: string(reader) for field in ("locale", "bundle_alias", "explicit_parent", "collations_alias")}
        previous = ascending(previous, bundle["locale"])
        flags = reader.u32()
        if flags & ~7:
            raise ValueError("Unknown resource bundle flag")
        bundle.update(no_fallback=bool(flags & 1), parent_is_root=bool(flags & 2), has_collations=bool(flags & 4), types=[])
        prior_type = None
        for _ in range(reader.u32()):
            item = {"name": string(reader), "resource_type": reader.u32(), "text": string(reader),
                    "has_binary": reader.u32(), "owner": reader.u32(), "settings": reader.u32()}
            prior_type = ascending(prior_type, item["name"])
            if item["resource_type"] not in (0, 2, 3) or item["has_binary"] not in (0, 1):
                raise ValueError("Unknown resource type/binary flag")
            if item["has_binary"]:
                if item["resource_type"] != 2 or item["owner"] >= result["owner_count"] or item["settings"] >= result["settings_count"]:
                    raise ValueError("Invalid raw binary owner/settings binding")
            elif item["owner"] != 0xffffffff or item["settings"] != 0xffffffff:
                raise ValueError("Missing binary must retain missing binding sentinels")
            bundle["types"].append(item)
        result["bundles"].append(bundle)
    finish(reader)
    return result


def read_aliases(path):
    reader, result = begin(path, b"BRSSAL77")
    result["aliases"] = []
    previous = None
    for _ in range(reader.u32()):
        name, code = string(reader), reader.u32()
        previous = ascending(previous, name)
        if not 1 <= len(name) <= 4 or any(ch < "a" or ch > "z" for ch in name) or code >= 208:
            raise ValueError("Script alias outside the fixed Unicode16 script domain")
        result["aliases"].append({"name": name, "code": code})
    finish(reader)
    return result


def read_default_scripts(path):
    reader, result = begin(path, b"BRSDST77")
    result.update(fallback=string(reader), default_scripts=[])
    previous = None
    for _ in range(reader.u32()):
        locale, script = string(reader), string(reader)
        previous = ascending(previous, locale)
        if len(script) != 4 or not script.isalpha():
            raise ValueError("Invalid default script identifier")
        result["default_scripts"].append({"locale": locale, "script": script})
    finish(reader)
    return result
