#!/usr/bin/env python3
"""Bind all raw ICU77 collation resources to fixed owners/settings without locale lookup.

Separate files preserve the resource tree, complete short script aliases, and
default-script fallback metadata. No request results or sort keys are consulted.
"""

import argparse
import collections
import copy
import datetime as dt
import json
import os
from pathlib import Path
import shlex
import subprocess

from data_format import read_data
from generate import ROOT, DATA, EXPORT, digest, save_json, verify_source
from inventory_locales import SOURCES, package_resources, record, run_logged
from locale_format import read_owner
from resolver_format import (read_aliases, read_default_scripts, read_resources,
                             write_aliases, write_default_scripts, write_resources)


SOURCES = tuple(dict.fromkeys(SOURCES + (
    "source/i18n/collationdatareader.h", "source/common/localefallback_data.h",
    "source/common/propname.cpp", "source/common/propname.h",
)))
GENERATORS = ("resource_bindings.py", "resource-bindings.cpp", "resolver_format.py", "locale_data.h",
              "locale_resources.h", "locale_format.py", "inventory_locales.py", "generate.py", "data_format.py")


def index_files(data, catalog, raw_root):
    owners = collections.defaultdict(list)
    root = read_data(DATA / "root-icu77.bin")
    native = read_owner(raw_root)
    if any(value != root[key] for key, value in native.items() if key not in ("bytes", "sha256")):
        raise ValueError("Direct native root differs from fixed root data")
    owners[digest(raw_root)].append(0)
    for owner in catalog["owner_files"]:
        if owner["id"] == 0:
            continue
        path = data / owner["file"]
        actual = digest(path)
        if actual != owner["sha256"]:
            raise ValueError("Existing owner blob differs from frozen catalog")
        owners[actual].append(owner["id"])
    settings = collections.defaultdict(list)
    for setting in catalog["settings_files"]:
        actual = digest(data / setting["path"])
        if actual != setting["sha256"]:
            raise ValueError("Existing settings blob differs from frozen catalog")
        settings[actual].append(setting["id"])
    return owners, settings


def bind(catalog_path, directory, native):
    catalog = json.loads(catalog_path.read_text())
    owners, settings = index_files(catalog_path.parent, catalog, directory / "root-owner.bin")
    roots = settings.get(digest(directory / "root-settings.bin"), [])
    if not roots:
        raise ValueError("Root settings are absent from the frozen catalog")
    result = {"schema": "boostregexrs.icu77-resolver-source-data.v1", "catalog_sha256": digest(catalog_path),
              "owner_count": len(catalog["owners"]), "settings_count": len(catalog["settings"]),
              "root_owner": 0, "root_settings": min(roots), "bundles": copy.deepcopy(catalog["resource_bundles"])}
    bindings = {}
    for item in native["bindings"]:
        key = item["bundle"], item["type"]
        if key in bindings:
            raise ValueError("Duplicate direct raw resource binding")
        stem = item["stem"]
        if not stem.startswith("resource-") or not stem[9:].isascii() or not stem[9:].isdigit():
            raise ValueError("Unexpected generated resource file stem")
        owner_hash, settings_hash = digest(directory / (stem + "-owner.bin")), digest(directory / (stem + "-settings.bin"))
        owner_matches, settings_matches = owners.get(owner_hash, []), settings.get(settings_hash, [])
        if not owner_matches or not settings_matches:
            raise ValueError(f"Raw resource is not represented in the fixed catalog: {key}")
        raw = directory / (stem + "-collation.bin")
        if raw.stat().st_size != item["binary_bytes"]:
            raise ValueError("Raw binary size differs from native resource metadata")
        bindings[key] = {**item, "owner": min(owner_matches), "settings": min(settings_matches),
                         "owner_matches": owner_matches, "settings_matches": settings_matches,
                         "owner_sha256": owner_hash, "settings_sha256": settings_hash,
                         "binary_sha256": digest(raw)}
    expected = set()
    for bundle in result["bundles"]:
        for item in bundle["types"]:
            if item["has_binary"]:
                key = bundle["locale"], item["name"]
                expected.add(key)
                if key not in bindings or bindings[key]["binary_bytes"] != item["binary_bytes"]:
                    raise ValueError("Raw binary bindings differ from complete resource inventory")
                item.update({field: bindings[key][field] for field in ("owner", "settings", "owner_matches", "settings_matches", "binary_sha256")})
    if expected != set(bindings):
        raise ValueError("Resource enumeration omitted a direct binary binding")
    result["direct_bindings"] = list(bindings.values())
    return result


def generate(args):
    cache, data = args.cache.resolve(), args.data_directory.resolve()
    output = (args.output or ROOT / "docs/research/assets/icu77-locales/resources" /
              dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H%M%S.%fZ")).resolve()
    output.mkdir(parents=True, exist_ok=False)
    build = cache / "build/locale-resource-export"
    build.mkdir(parents=True, exist_ok=True)
    provenance, source_files = verify_source(cache, SOURCES)
    prefix = cache / "install/icu"
    libraries = [prefix / "lib" / name for name in ("libicui18n.a", "libicuuc.a", "libicudata.a")]
    environment = dict(os.environ)
    environment.pop("ICU_DATA", None)
    environment["LD_LIBRARY_PATH"] = str(prefix / "lib")
    names, package = package_resources(cache, output, environment)
    catalog_path = data / "catalog.json"
    catalog = json.loads(catalog_path.read_text())
    if names.read_text().splitlines() != [bundle["locale"] for bundle in catalog["resource_bundles"]]:
        raise ValueError("Packaged resource names differ from the fixed catalog")
    compiler = shlex.split(args.cxx)
    executable = build / "resource-bindings"
    run_logged(compiler + ["-std=c++17", "-O2", "-Wall", "-Wextra", "-Werror", "-DU_STATIC_IMPLEMENTATION",
                          "-I" + str(prefix / "include"), "-I" + str(cache / "deps/icu/source/common"),
                          "-I" + str(cache / "deps/icu/source/i18n"), str(EXPORT / "resource-bindings.cpp"),
                          *map(str, libraries), "-lpthread", "-ldl", "-lm", "-o", str(executable)], output / "build.log", environment)
    runs = []
    for number in (1, 2):
        directory = build / f"export-{number}"
        directory.mkdir(exist_ok=True)
        raw_json = output / f"native-{number}.json"
        command = [str(executable), str(names), str(directory), str(raw_json)]
        run_logged(command, output / f"native-{number}.log", environment)
        native = json.loads(raw_json.read_text())
        runs.append((directory, native, bind(catalog_path, directory, native)))
    first, native, resource = runs[0]
    second, other_native, other_resource = runs[1]
    if native != other_native or resource != other_resource:
        raise ValueError("Independent native resource exports differ")
    generated = ["root-owner.bin", "root-settings.bin"]
    for item in native["bindings"]:
        generated += [item["stem"] + suffix for suffix in ("-owner.bin", "-settings.bin", "-collation.bin")]
    for name in generated:
        if (first / name).read_bytes() != (second / name).read_bytes():
            raise ValueError(f"Independent resource data bytes differ: {name}")
    products = {
        "resources.bin": write_resources(resource),
        "script-aliases.bin": write_aliases(native["script_aliases"]),
        "default-scripts.bin": write_default_scripts(native["default_script_fallback"], native["default_scripts"]),
    }
    for name, content in products.items():
        (output / name).write_bytes(content)
    parsed = read_resources(output / "resources.bin")
    if parsed["catalog_sha256"] != resource["catalog_sha256"] or len(parsed["bundles"]) != len(resource["bundles"]):
        raise ValueError("Serialized resource data does not match its source")
    if read_aliases(output / "script-aliases.bin")["aliases"] != native["script_aliases"]:
        raise ValueError("Serialized script aliases differ")
    if read_default_scripts(output / "default-scripts.bin")["default_scripts"] != native["default_scripts"]:
        raise ValueError("Serialized default scripts differ")
    save_json(output / "resources.json", resource)
    save_json(output / "script-aliases.json", {"domain": native["script_alias_domain"], "queries": native["script_alias_queries"], "aliases": native["script_aliases"]})
    save_json(output / "default-scripts.json", {"fallback": native["default_script_fallback"], "default_scripts": native["default_scripts"]})
    for name, content in products.items():
        destination = data / name
        if args.check:
            if destination.read_bytes() != content:
                raise ValueError(f"Regenerated resolver data differs: {destination}")
        else:
            destination.write_bytes(content)
    metadata = {
        "schema": "boostregexrs.icu77-resource-generation.v1", "completed_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "source": provenance, "source_files": source_files, "catalog": record(catalog_path),
        "packaged_resources": package, "installed_static_libraries": [record(path) for path in libraries],
        "generator_files": [record(EXPORT / name) for name in GENERATORS], "executable": record(executable),
        "counts": {"bundles": len(resource["bundles"]), "binary_bindings": len(resource["direct_bindings"]),
                   "bundle_aliases": sum(bool(row["bundle_alias"]) for row in resource["bundles"]),
                   "short_script_aliases": len(native["script_aliases"]), "script_alias_queries": native["script_alias_queries"],
                   "default_scripts": len(native["default_scripts"])},
        "determinism": {"independent_native_processes": 2, "all_exported_binary_bytes_equal": True, "metadata_equal": True},
        "binding_mechanism": "Official CollationDataReader directly reads every packaged raw %%CollationBin; canonical owner/settings bytes match the frozen complete catalog",
        "resource_alias_paths_preserved": True, "missing_private_binaries_preserved": True,
        "default_script_source": "Compiled complete localefallback_data.h defaultScriptTable; Latn fallback from uresbund.cpp; parentLocaleTable excluded from collation mode",
        "script_alias_scope": "All alphabetic normalized aliases of length 1..4; colReorder first requires exactly 4 original bytes, then ICU loose matching removes ASCII _, whitespace and case",
        "locale_request_results_used_for_binding": False, "sort_keys_used": False,
        "checked_existing_data": args.check, "data_files": [record(output / name) for name in products],
    }
    save_json(output / "summary.json", metadata)
    print(json.dumps({"evidence": str(output), "counts": metadata["counts"], "files": metadata["data_files"]}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, default=ROOT / "target/research/icu77-cloud")
    parser.add_argument("--data-directory", type=Path, default=DATA / "locales")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--cxx", default=os.environ.get("CXX", "c++"))
    parser.add_argument("--check", action="store_true")
    generate(parser.parse_args())


if __name__ == "__main__":
    main()
