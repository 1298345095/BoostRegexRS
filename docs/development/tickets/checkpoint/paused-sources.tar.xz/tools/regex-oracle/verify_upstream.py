#!/usr/bin/env python3
"""Validate the byte oracle against the original Boost regression assertions.

Assertions follow the original test_regex_search.hpp, test_regex_replace.hpp
and test_not_regex.hpp. The complete differential comparator independently
checks every observed result, including fields the original tests omit.
"""

import argparse
from collections import Counter
import json
from pathlib import Path

from protocol import read_cases, read_results, read_rows
from run import identity, save_json


ASSERTIONS_HEADER = ("source_case_id", "operation", "expected_ranges", "expected_output_hex")


def answer_table(text):
    values = [int(value) for value in text.split(",")]
    if len(values) > 800 or values[-2:] != [-2, -2]:
        raise ValueError("Original answer table is not terminated within its 800-entry bound")
    # main.cpp::make_array fills the full 800-entry buffer with -2 before
    # copying the explicit arguments. Partial matches leave later groups
    # unmatched even when only group zero is supplied by the test macro.
    return values + [-2] * (800 - len(values))


def assert_groups(match, table, offset):
    for index, group in enumerate(match["groups"]):
        start = offset + 2 * index
        if start + 1 >= len(table):
            raise ValueError("Reference capture count exceeds the original assertion table")
        expected = table[start:start + 2]
        if index == 0 and match["partial"]:
            actual = match["range"]
        else:
            actual = group
        if actual is None:
            if expected[0] >= 0:
                raise ValueError(f"Expected capture {index} is unmatched")
        elif actual != expected:
            raise ValueError(f"Capture {index} differs: expected {expected}, observed {actual}")


def assert_search(value, table):
    matches = value["matches"]
    if matches:
        assert_groups(matches[0], table, 0)
    elif table[0] >= 0:
        raise ValueError("Expected first search result is missing")


def assert_iteration(value, table, input_size):
    offset = 0
    previous_end = 0
    for match in value["matches"]:
        assert_groups(match, table, offset)
        start, end = match["range"]
        if match["prefix"] != [previous_end, start] or match["suffix"] != [end, input_size]:
            raise ValueError("Original iterator prefix/suffix assertion differs")
        previous_end = end
        if table[offset] != -2:
            while table[offset] != -2:
                offset += 1
            offset += 1
    if table[offset] >= 0:
        raise ValueError("An expected subsequent iterator result is missing")


def assert_full_match(value, table, input_size):
    # The original test deliberately does not assert regex_match when its first
    # search spans only a proper prefix. Do not invent an expected answer for
    # those rows. They remain complete native observations for Rust comparison.
    if table[0] < 0 or table[0] > 0:
        if value["matches"]:
            raise ValueError("Original full-match assertion expected no match")
    elif table[1] == input_size:
        if not value["matches"]:
            raise ValueError("Original full-match assertion expected a result")
        assert_groups(value["matches"][0], table, 0)
    else:
        return False
    return True


def verify(cases_path, results_path, assertions_path):
    cases = read_cases(cases_path)
    results, values = read_results(results_path, cases)
    observed = {case[0]: (case, result, value)
                for case, result, value in zip(cases, results, values, strict=True)}
    assertions = read_rows(assertions_path, ASSERTIONS_HEADER)
    counts = Counter()
    differences = []
    covered = set()

    def successful(identifier):
        covered.add(identifier)
        case, row, value = observed[identifier]
        if row[1] != "ok":
            raise ValueError(f"Unexpected reference status {row[1]}: {row[2]}")
        return case, value

    for identifier, operation, ranges, expected_hex in assertions:
        try:
            if operation == "search":
                table = answer_table(ranges)
                _, value = successful(identifier + "/search")
                assert_search(value, table)
                counts["search_assertions_passed"] += 1
                case, value = successful(identifier + "/iterate")
                assert_iteration(value, table, len(case[5]) // 2)
                counts["iteration_assertions_passed"] += 1
                case, value = successful(identifier + "/match")
                asserted = assert_full_match(value, table, len(case[5]) // 2)
                counts["full_match_assertions_passed" if asserted else "full_match_observations_without_original_assertion"] += 1
            elif operation == "replace":
                _, value = successful(identifier + "/replace")
                if bytes.fromhex(value["output_hex"]) != bytes.fromhex(expected_hex):
                    raise ValueError("Original replacement output differs")
                counts["replacement_assertions_passed"] += 1
            elif operation == "invalid_compile":
                key = identifier + "/compile"
                covered.add(key)
                if observed[key][1][1] != "compile_error":
                    raise ValueError("Original invalid-pattern assertion expected a compile exception")
                counts["invalid_compile_assertions_passed"] += 1
            else:
                raise ValueError("Unknown original assertion kind")
        except (KeyError, IndexError, ValueError) as error:
            counts["source_cases_with_differences"] += 1
            differences.append({"source_case_id": identifier, "error": str(error),
                                "original_ranges": ranges, "original_output_hex": expected_hex})
    missing = sorted(set(observed) - covered)
    # An assertion failing early does not discard the remaining observed rows.
    # The unexamined IDs are retained and prevent a passing verification result.
    summary = {
        "schema": "boostregexrs.byte-upstream-assertions.v1",
        "status": "passed_for_recorded_assertions" if not differences and not missing else "differences_or_unverified",
        "source_cases": len(assertions), "native_operation_records": len(cases),
        "counts": dict(sorted(counts.items())), "unexamined_native_ids": missing,
        "scope": "Original classic-byte search/capture ranges, iterator prefixes/suffixes, applicable full matches, replacement bytes and invalid compile exceptions",
        "not_claimed": ["The full upstream test executable and all its trait/overload variants",
                        "Original no_except invalid-object accessor assertions",
                        "Original token-iterator, grep, allocator, swap and saved-subexpression accessor assertions",
                        "Native observations equal Rust results"],
        "inputs": [identity(path) for path in (cases_path, results_path, assertions_path)],
    }
    return summary, differences


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--assertions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    summary, differences = verify(args.cases, args.reference, args.assertions)
    save_json(args.output / "summary.json", summary)
    save_json(args.output / "differences.json", differences)
    print(json.dumps(summary, indent=2))
    return int(summary["status"] != "passed_for_recorded_assertions")


if __name__ == "__main__":
    raise SystemExit(main())
