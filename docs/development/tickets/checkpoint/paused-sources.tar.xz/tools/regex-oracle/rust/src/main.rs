//! Development-only adapter; matching is performed by the public Rust library.
use boost_regex_rs::{ByteRegex, Captures, CompileOptions, MatchOptions, RegexError};
use std::io::{self, BufRead, Write};
use std::ops::Range;

const HEADER: &str = "case_id\toperation\tsyntax\tmatch\tpattern_hex\tinput_hex\tformat_hex";

fn unhex(value: &str) -> Result<Vec<u8>, &'static str> {
    fn nibble(value: u8) -> Result<u8, &'static str> {
        match value {
            b'0'..=b'9' => Ok(value - b'0'),
            b'a'..=b'f' => Ok(value - b'a' + 10),
            b'A'..=b'F' => Ok(value - b'A' + 10),
            _ => Err("Invalid hexadecimal input"),
        }
    }
    if !value.len().is_multiple_of(2) {
        return Err("Odd hexadecimal width");
    }
    value.as_bytes().chunks_exact(2)
        .map(|pair| Ok((nibble(pair[0])? << 4) | nibble(pair[1])?))
        .collect()
}

fn hex(value: &[u8]) -> String {
    const DIGITS: &[u8] = b"0123456789abcdef";
    let mut out = String::with_capacity(value.len() * 2);
    for &byte in value {
        out.push(DIGITS[usize::from(byte >> 4)] as char);
        out.push(DIGITS[usize::from(byte & 15)] as char);
    }
    out
}

fn flags(value: &str) -> Result<u32, &'static str> {
    if value.is_empty() || !value.bytes().all(|c| c.is_ascii_digit()) {
        return Err("Flags must be unsigned decimal");
    }
    value.parse().map_err(|_| "Flags exceed u32")
}

fn range(value: &Range<usize>) -> String {
    format!("[{},{}]", value.start, value.end)
}

fn capture_json(value: &Captures) -> String {
    let groups = value.groups().iter().enumerate().map(|(index, group)| {
        if index == 0 && value.is_partial() {
            "null".to_owned()
        } else {
            group.as_ref().map_or_else(|| "null".to_owned(), range)
        }
    }).collect::<Vec<_>>().join(",");
    let histories = (0..value.groups().len()).map(|index| {
        format!("[{}]", value.history(index).iter().map(range).collect::<Vec<_>>().join(","))
    }).collect::<Vec<_>>().join(",");
    format!("{{\"range\":{},\"partial\":{},\"groups\":[{}],\"histories\":[{}],\"prefix\":{},\"suffix\":{}}}",
        range(&value.range()), value.is_partial(), groups, histories,
        range(&value.prefix()), range(&value.suffix()))
}

fn regex_error(error: RegexError, compiling: bool) -> (&'static str, String) {
    let status = if error.resource().is_some() {
        "candidate_resource_error"
    } else if compiling {
        "compile_error"
    } else {
        "candidate_error"
    };
    (status, format!("{{\"code\":{},\"position\":{}}}", error.code(), error.position()))
}

fn execute(row: &[&str]) -> Result<(&'static str, String), &'static str> {
    if row.len() != 7 { return Err("Expected seven input columns"); }
    let syntax = flags(row[2])?;
    let options = MatchOptions::from_bits(flags(row[3])?);
    let pattern = unhex(row[4])?;
    let input = unhex(row[5])?;
    let _format = unhex(row[6])?;
    let regex = match ByteRegex::with_options(&pattern, CompileOptions::from_bits(syntax)) {
        Ok(regex) => regex,
        Err(error) => return Ok(regex_error(error, true)),
    };
    if row[1] == "compile" {
        return Ok(("ok", format!("{{\"mark_count\":{},\"compile_status\":0}}", regex.mark_count())));
    }
    let result = match row[1] {
        "search" => regex.search_with_options(&input, options),
        "match" => regex.full_match_with_options(&input, options),
        "iterate" | "replace" | "format" => {
            return Ok(("unsupported", "{\"reason\":\"public_operation_not_implemented\"}".to_owned()));
        }
        _ => return Err("Unknown operation"),
    };
    match result {
        Ok(found) => Ok(("ok", format!("{{\"mark_count\":{},\"matches\":[{}]}}",
            regex.mark_count(), found.as_ref().map_or_else(String::new, capture_json)))),
        Err(error) => Ok(regex_error(error, false)),
    }
}

fn run() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() == 2 && args[1] == "--metadata" {
        println!("{{\"implementation\":\"boost_regex_rs::ByteRegex\",\"runtime_backend\":\"pure_rust\",\"supported_operations\":[\"compile\",\"search\",\"match\"]}}");
        return Ok(());
    }
    if args.len() != 1 { return Err("No arguments expected".into()); }
    let stdin = io::stdin();
    let mut lines = stdin.lock().lines();
    if lines.next().transpose()?.as_deref() != Some(HEADER) {
        return Err("Invalid input header".into());
    }
    let stdout = io::stdout();
    let mut out = io::BufWriter::new(stdout.lock());
    writeln!(out, "case_id\tstatus\tresult")?;
    for line in lines {
        let line = line?;
        let row: Vec<_> = line.split('\t').collect();
        let (status, result) = execute(&row).unwrap_or_else(|error| {
            ("protocol_error", format!("{{\"message_hex\":\"{}\"}}", hex(error.as_bytes())))
        });
        writeln!(out, "{}\t{status}\t{result}", row[0])?;
        out.flush()?;
    }
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("{error}");
        std::process::exit(2);
    }
}
