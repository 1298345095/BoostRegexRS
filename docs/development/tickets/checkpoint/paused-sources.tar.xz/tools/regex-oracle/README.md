# Boost.Regex engine differential reference

Development reference: official Boost.Regex 1.89.0, C++17, explicitly selected
`cpp_regex_traits<char>` with the classic C locale, and capture-history support
compiled in. This byte reference accepts arbitrary bytes including NUL. It is
separate from the ICU sort-key reference and is never a Rust runtime backend.

## Protocol

Input is TSV with exactly this header:

```text
case_id	operation	syntax	match	pattern_hex	input_hex	format_hex
```

Flags use unsigned decimal Boost bit values. Byte sequences use strict even-width
hexadecimal; an empty field means an empty byte sequence. Operations are `compile`,
`search`, `match`, `iterate`, `format`, and `replace`. Default flags are zero.

Output header is `case_id\tstatus\tresult`. `result` is JSON. Successful compile
records `mark_count` and `compile_status`. Search/match/iterate record `mark_count`
and a `matches` array. Each match includes its original byte `range`, `partial`,
all indexed `groups` (unmatched groups are null), `histories`, `prefix`, and
`suffix`. Histories are requested only with `match_extra` (524288); otherwise each
history is empty. Replacement and formatting also record `output_hex`.

Compile errors record the actual Boost error `code` and original pattern byte
`position`. `reference_resource_error` and `protocol_error` are distinct from
ordinary matching results. The harness must preserve a reference process failure,
never convert it into an empty matches array.

`oracle --metadata` records the reference configuration. Native platform traits,
locale combinations and Unicode entry points will have their own explicit
configurations and evidence; passing classic byte cases does not mark them passed.

Authored source, corpus generators, minimized cases and comparison scripts are
tracked here or under `tests/`. Build products go under `target`; evidence is
saved under `docs/research/assets/regex-engine/`.
