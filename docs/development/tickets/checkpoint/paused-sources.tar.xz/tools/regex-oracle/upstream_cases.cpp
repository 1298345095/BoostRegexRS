// Development-only input adapter for the unmodified official regression sources.
// Original regression macros: Copyright (c) 2004 John Maddock.
// SPDX-License-Identifier: BSL-1.0
// See NOTICE.md and LICENSE_1_0.txt. No original test result is used by Rust.
#define BOOST_REGEX_MATCH_EXTRA
#define BOOST_NO_WREGEX
#define BOOST_REGEX_REGRESS_TEST_HPP
#include <boost/regex.hpp>
#include <boost/version.hpp>
#include <algorithm>
#include <cstdarg>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

#if BOOST_VERSION != 108900
#error Official Boost 1.89.0 is required
#endif

namespace {
std::ofstream expectations;
std::size_t sequence = 0;

std::string hex(const std::string& value) {
    const char* digits = "0123456789abcdef";
    std::string output;
    for (unsigned char byte : value) {
        output.push_back(digits[byte >> 4]);
        output.push_back(digits[byte & 15]);
    }
    return output;
}

struct Input {
    std::string id, pattern, input, format, result;
    unsigned syntax = 0;
    boost::match_flag_type flags = boost::match_default;
    std::string answer_ranges;
} current;

void emit(const char* operation) {
    std::cout << current.id << '/' << operation << '\t' << operation << '\t'
              << current.syntax << '\t' << static_cast<unsigned>(current.flags) << '\t'
              << hex(current.pattern) << '\t' << hex(current.input) << '\t'
              << hex(current.format) << '\n';
}
}  // namespace

const int* make_array(int first, ...) {
    static int values[800];
    std::fill_n(values, 800, -2);
    std::size_t count = 0;
    values[count++] = first;
    va_list arguments;
    va_start(arguments, first);
    while (count < 800) {
        const int value = va_arg(arguments, int);
        values[count++] = value;
        if (value == -2 && values[count - 2] == -2) break;
    }
    va_end(arguments);
    if (count == 800) throw std::runtime_error("Upstream answer array exceeded its original bound");
    return values;
}

struct test_regex_search_tag {};
struct test_regex_replace_tag {};
struct test_invalid_regex_tag {};

template <class Char> struct test_info {
    static void set_info(const char* file, int line, const std::basic_string<Char>& pattern,
                         unsigned syntax, const std::basic_string<Char>& input = {},
                         boost::match_flag_type flags = boost::match_default,
                         const int* answer = nullptr,
                         const std::basic_string<Char>& format = {},
                         const std::basic_string<Char>& result = {}) {
        static_assert(sizeof(Char) == 1, "This collector profile is explicitly byte-only");
        std::string filename(file);
        filename = filename.substr(filename.find_last_of("/\\") + 1);
        current = {"upstream/" + filename + '/' + std::to_string(line) + '/' + std::to_string(sequence++),
                   pattern, input, format, result, syntax, flags, ""};
        if (answer) {
            int previous = 0;
            for (std::size_t index = 0; index < 800; ++index) {
                if (index) current.answer_ranges.push_back(',');
                current.answer_ranges += std::to_string(answer[index]);
                if (previous == -2 && answer[index] == -2) break;
                previous = answer[index];
            }
        }
    }
};

void test(const char&, const test_regex_search_tag&) {
    emit("search");
    emit("match");
    emit("iterate");
    expectations << current.id << "\tsearch\t" << current.answer_ranges << "\t\n";
}
void test(const char&, const test_regex_replace_tag&) {
    emit("replace");
    expectations << current.id << "\treplace\t\t" << hex(current.result) << '\n';
}
void test(const char&, const test_invalid_regex_tag&) {
    emit("compile");
    expectations << current.id << "\tinvalid_compile\t\t\n";
}

// Preserve original array construction and sizeof-based embedded-NUL lengths.
// Only dispatch is replaced: official source files are included unchanged.
#define TEST_INVALID_REGEX_N(s, f) do { \
    const char e[] = {s}; \
    test_info<char>::set_info(__FILE__, __LINE__, std::string(e, sizeof(e)-1), f); \
    test(char(0), test_invalid_regex_tag()); \
} while (0)
#define TEST_INVALID_REGEX(s, f) TEST_INVALID_REGEX_N(s, f)
#define TEST_INVALID_REGEX_W(s, f)
#define TEST_REGEX_SEARCH_N(s, f, t, m, a) do { \
    const char e[] = {s}; const char text[] = {t}; \
    test_info<char>::set_info(__FILE__, __LINE__, std::string(e, sizeof(e)-1), \
        f, std::string(text, sizeof(text)-1), m, a); \
    test(char(0), test_regex_search_tag()); \
} while (0)
#define TEST_REGEX_SEARCH(s, f, t, m, a) TEST_REGEX_SEARCH_N(s, f, t, m, a)
#define TEST_REGEX_SEARCH_L(s, f, t, m, a) TEST_REGEX_SEARCH_N(s, f, t, m, a)
#define TEST_REGEX_SEARCH_W(s, f, t, m, a)
#define TEST_REGEX_REPLACE_N(s, f, t, m, fs, r) do { \
    const char e[] = {s}; const char text[] = {t}; const char fmt[] = {fs}; const char result[] = {r}; \
    test_info<char>::set_info(__FILE__, __LINE__, std::string(e, sizeof(e)-1), \
        f, std::string(text, sizeof(text)-1), m, nullptr, \
        std::string(fmt, sizeof(fmt)-1), std::string(result, sizeof(result)-1)); \
    test(char(0), test_regex_replace_tag()); \
} while (0)
#define TEST_REGEX_REPLACE(s, f, t, m, fs, r) TEST_REGEX_REPLACE_N(s, f, t, m, fs, r)
#define TEST_REGEX_REPLACE_W(s, f, t, m, fs, r)

#include <libs/regex/test/regress/basic_tests.cpp>
#include <libs/regex/test/regress/test_alt.cpp>
#include <libs/regex/test/regress/test_anchors.cpp>
#include <libs/regex/test/regress/test_asserts.cpp>
#include <libs/regex/test/regress/test_backrefs.cpp>
#include <libs/regex/test/regress/test_emacs.cpp>
#include <libs/regex/test/regress/test_escapes.cpp>
#include <libs/regex/test/regress/test_grep.cpp>
#include <libs/regex/test/regress/test_non_greedy_repeats.cpp>
#include <libs/regex/test/regress/test_perl_ex.cpp>
#include <libs/regex/test/regress/test_replace.cpp>
#include <libs/regex/test/regress/test_sets.cpp>
#include <libs/regex/test/regress/test_simple_repeats.cpp>
#include <libs/regex/test/regress/test_tricky_cases.cpp>

int main(int argc, char** argv) {
    if (argc != 2) return 2;
    expectations.open(argv[1], std::ios::binary);
    if (!expectations) return 2;
    std::cout << "case_id\toperation\tsyntax\tmatch\tpattern_hex\tinput_hex\tformat_hex\n";
    expectations << "source_case_id\toperation\texpected_ranges\texpected_output_hex\n";
    basic_tests(); test_simple_repeats(); test_alt(); test_sets(); test_sets2(); test_anchors();
    test_backrefs(); test_character_escapes(); test_assertion_escapes(); test_tricky_cases();
    test_grep(); test_replace(); test_non_greedy_repeats(); test_non_marking_paren();
    test_partial_match(); test_forward_lookahead_asserts(); test_fast_repeats(); test_fast_repeats2();
    test_independent_subs(); test_nosubs(); test_conditionals(); test_options(); test_options2();
    test_emacs(); test_pocessive_repeats(); test_mark_resets(); test_recursion(); test_verbs();
    return std::cout && expectations ? 0 : 2;
}
