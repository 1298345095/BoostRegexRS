//! Invariants derived from the pinned Boost 1.89 implementation, independently
//! of the differential corpus. Source mapping is in byte-engine-architecture.md.

use boost_regex_rs::{ByteRegex, CompileOptions as C, ErrorKind, Limits, MatchOptions as M};

#[test]
fn negative_character_class_masks_are_combined_before_complement() {
    for pattern in [br"[\D\S]".as_slice(), br"[[:^digit:][:^space:]]"] {
        let regex = ByteRegex::new(pattern).unwrap();
        for byte in 0u8..=255 {
            let excluded = byte.is_ascii_digit() || matches!(byte, b' ' | b'\t'..=b'\r');
            assert_eq!(
                regex.full_match(&[byte]).unwrap().is_some(),
                !excluded,
                "byte {byte}"
            );
        }
    }
}

#[test]
fn collating_elements_keep_original_order_before_case_translation() {
    let element = ByteRegex::new(br"[[.ch.]]").unwrap();
    assert_eq!(element.search(b"xxch").unwrap().unwrap().range(), 2..4);
    assert!(element.full_match(b"c").unwrap().is_none());
    assert_eq!(
        ByteRegex::new(br"[c[.ch.]]")
            .unwrap()
            .search(b"ch")
            .unwrap()
            .unwrap()
            .range(),
        0..1
    );
    assert_eq!(
        ByteRegex::with_options(br"[c[.CH.]]", C::ICASE)
            .unwrap()
            .search(b"ch")
            .unwrap()
            .unwrap()
            .range(),
        0..2
    );
    let negative = ByteRegex::new(br"[^[.ch.]]").unwrap();
    assert!(negative.full_match(b"c").unwrap().is_some());
    assert_eq!(negative.search(b"ch").unwrap().unwrap().range(), 1..2);
}

#[test]
fn collating_range_endpoints_are_also_single_elements() {
    let regex = ByteRegex::new(br"[[.ch.]-d]").unwrap();
    assert!(regex.full_match(b"ch").unwrap().is_some());
    assert!(regex.full_match(b"d").unwrap().is_some());
    assert!(regex.full_match(b"c").unwrap().is_none());
    assert!(
        ByteRegex::new(br"[[=A=]]")
            .unwrap()
            .full_match(b"a")
            .unwrap()
            .is_some()
    );
    assert_eq!(
        ByteRegex::new(br"\N{ESC}")
            .unwrap()
            .search(&[27])
            .unwrap()
            .unwrap()
            .range(),
        0..1
    );
    assert_eq!(
        ByteRegex::new(br"\N{ch}").unwrap_err().kind(),
        ErrorKind::Escape
    );
}

#[test]
fn brackets_dispatch_class_shortcuts_before_the_no_escape_option() {
    let digits = ByteRegex::with_options(br"[\d]", C::BASIC).unwrap();
    assert!(digits.full_match(b"7").unwrap().is_some());
    assert!(digits.full_match(b"d").unwrap().is_none());
    let range = ByteRegex::new(br"[a-\d]").unwrap();
    assert!(range.full_match(b"c").unwrap().is_some());
    assert!(range.full_match(b"7").unwrap().is_none());
    let property = ByteRegex::new(br"[\p{digit}]").unwrap();
    assert!(property.full_match(b"p").unwrap().is_some());
    assert!(property.full_match(b"7").unwrap().is_none());
}

#[test]
fn classic_byte_separators_vertical_space_and_line_escape_are_distinct() {
    let vertical = ByteRegex::new(br"\v").unwrap();
    let line_escape = ByteRegex::new(br"\R").unwrap();
    let dot = ByteRegex::new(b".").unwrap();
    let blank = ByteRegex::new(br"[[:blank:]]").unwrap();
    let bracket_vertical = ByteRegex::new(br"[\v]").unwrap();
    for byte in 0u8..=255 {
        assert_eq!(
            vertical.full_match(&[byte]).unwrap().is_some(),
            matches!(byte, b'\n' | b'\r' | 11 | 12)
        );
        assert_eq!(
            line_escape.full_match(&[byte]).unwrap().is_some(),
            matches!(byte, b'\n' | b'\r' | 11 | 12 | 0x85)
        );
        assert_eq!(
            dot.full_match_with_options(&[byte], M::NOT_DOT_NEWLINE)
                .unwrap()
                .is_some(),
            !matches!(byte, b'\n' | b'\r' | 12)
        );
        assert_eq!(
            blank.full_match(&[byte]).unwrap().is_some(),
            matches!(byte, b' ' | b'\t' | 11)
        );
        assert_eq!(
            bracket_vertical.full_match(&[byte]).unwrap().is_some(),
            byte == 11
        );
    }
    assert_eq!(line_escape.search(b"\r\n").unwrap().unwrap().range(), 0..2);
}

#[test]
fn bracket_range_errors_belong_to_set_finalization() {
    let error = ByteRegex::new(br"[z-a]").unwrap_err();
    assert_eq!(
        (error.kind(), error.position()),
        (ErrorKind::CharacterClass, Some(5))
    );
    let error = ByteRegex::with_options(br"[Z-a]", C::ICASE).unwrap_err();
    assert_eq!(
        (error.kind(), error.position()),
        (ErrorKind::CharacterClass, Some(5))
    );
    let error = ByteRegex::new(br"[a-b-c]").unwrap_err();
    assert_eq!(
        (error.kind(), error.position()),
        (ErrorKind::Range, Some(5))
    );
}

#[test]
fn no_except_preserves_the_compilation_stage_and_rejects_execution() {
    let early = ByteRegex::with_options(b"(", C::NO_EXCEPT).unwrap();
    assert_eq!(early.status(), 8);
    assert_eq!(early.mark_count(), usize::MAX);
    let late = ByteRegex::with_options(br"(a)\2", C::NO_EXCEPT).unwrap();
    assert_eq!(late.status(), 6);
    assert_eq!(late.mark_count(), 1);
    assert_eq!(late.compile_error().unwrap().position(), Some(5));
    let error = late.search(b"aa").unwrap_err();
    assert_eq!(error.kind(), ErrorKind::InvalidArgument);
    assert_eq!((error.code(), error.position()), (None, None));
}

#[test]
fn zero_prefix_recursion_is_checked_by_compiled_start_analysis() {
    let error = ByteRegex::new(br"(?R)").unwrap_err();
    assert_eq!(
        (error.kind(), error.position()),
        (ErrorKind::BadPattern, Some(0))
    );
    let invalid = ByteRegex::with_options(br"(?R)", C::NO_EXCEPT).unwrap();
    assert_eq!(invalid.mark_count(), 0);
    assert_eq!(invalid.status(), 2);
    let consuming = ByteRegex::new(br"(?<p>a(?&p)?b)").unwrap();
    assert!(consuming.full_match(b"aaabbb").unwrap().is_some());
}

#[test]
fn zero_length_repetition_saturates_before_the_nominal_minimum() {
    let regex = ByteRegex::new(br"(a?){3}").unwrap();
    let captures = regex
        .full_match_with_options(b"", M::EXTRA)
        .unwrap()
        .unwrap();
    assert_eq!(captures.groups(), &[Some(0..0), Some(0..0)]);
    assert_eq!(captures.history(1), std::slice::from_ref(&(0..0)));
    assert!(
        ByteRegex::new(br"(?:^)*")
            .unwrap()
            .full_match(b"")
            .unwrap()
            .is_some()
    );
    assert!(
        ByteRegex::new(br"a*?+a")
            .unwrap()
            .full_match(b"a")
            .unwrap()
            .is_some()
    );
    assert!(
        ByteRegex::new(br"a*+a")
            .unwrap()
            .full_match(b"a")
            .unwrap()
            .is_none()
    );
}

#[test]
fn single_state_repetition_retains_a_bounded_backtrack_record() {
    let input = vec![b'a'; 65_536];
    let limits = Limits {
        backtracking_bytes: 1_024,
        ..Limits::default()
    };
    for pattern in [b"a+".as_slice(), b"[a]+", b".+", b"a+?a$"] {
        let regex = ByteRegex::with_limits(pattern, C::NORMAL, limits).unwrap();
        assert_eq!(
            regex.full_match(&input).unwrap().unwrap().range(),
            0..input.len()
        );
    }
}

#[test]
fn invalid_match_option_combinations_are_operation_errors() {
    let plain = ByteRegex::new(b"a").unwrap();
    let committed = ByteRegex::new(b"a(*COMMIT)").unwrap();
    for (regex, options) in [
        (&plain, M::POSIX | M::PERL),
        (&plain, M::POSIX | M::EXTRA),
        (&committed, M::POSIX),
    ] {
        let error = regex.search_with_options(b"a", options).unwrap_err();
        assert_eq!(error.kind(), ErrorKind::InvalidMatchOptions);
        assert_eq!((error.code(), error.position()), (None, None));
    }
    let regex = ByteRegex::new(b"a+(*PRUNE)").unwrap();
    assert_eq!(
        regex
            .search_with_options(b"aaa", M::ANY)
            .unwrap()
            .unwrap()
            .range(),
        0..3
    );
}

#[test]
fn partial_results_publish_registers_after_failed_unwind() {
    for pattern in [br"(a)b".as_slice(), br"(?=(a)b)c", br"(?!(a)b)c"] {
        let captures = ByteRegex::new(pattern)
            .unwrap()
            .search_with_options(b"a", M::PARTIAL | M::EXTRA)
            .unwrap()
            .unwrap();
        assert!(captures.is_partial());
        assert_eq!(captures.range(), 0..1);
        assert_eq!(captures.groups(), &[None, None]);
        assert!(captures.history(1).is_empty());
    }
}

#[test]
fn successful_assertion_histories_survive_later_search_attempts() {
    let regex = ByteRegex::new(br"(?=(a)+)b|c").unwrap();
    let captures = regex
        .search_with_options(b"aac", M::EXTRA)
        .unwrap()
        .unwrap();
    assert_eq!(captures.groups(), &[Some(2..3), None]);
    assert_eq!(captures.history(1), std::slice::from_ref(&(0..1)));
}

#[test]
fn conditional_assertions_share_lookbehind_and_recursion_rules() {
    let behind = ByteRegex::new(br"(?(?<=a)b|c)").unwrap();
    assert_eq!(
        behind
            .search_from(b"ab", 1, M::DEFAULT)
            .unwrap()
            .unwrap()
            .range(),
        1..2
    );
    assert!(behind.search_from(b"ac", 1, M::DEFAULT).unwrap().is_none());
    assert!(behind.search_from(b"xc", 1, M::DEFAULT).unwrap().is_some());
    assert!(
        ByteRegex::new(br"(?(999)a|b)")
            .unwrap()
            .full_match(b"b")
            .unwrap()
            .is_some()
    );
    let recursive = ByteRegex::new(br"(?<p>a(?(R0)b|(?&p))c)").unwrap();
    assert!(recursive.full_match(b"aabcc").unwrap().is_some());
    assert_eq!(
        ByteRegex::new(br"(?(DEFINE)a|b)").unwrap_err().kind(),
        ErrorKind::BadPattern
    );
}

#[test]
fn full_match_requires_the_original_beginning_after_keep_reset() {
    let regex = ByteRegex::new(br"foo\Kbar").unwrap();
    assert!(regex.full_match(b"foobar").unwrap().is_none());
    assert_eq!(
        regex
            .search_with_options(b"foobar", M::ALL)
            .unwrap()
            .unwrap()
            .range(),
        3..6
    );
}
