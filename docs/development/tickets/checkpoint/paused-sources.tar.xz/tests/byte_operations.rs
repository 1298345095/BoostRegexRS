use boost_regex_rs::{ByteRegex, CompileOptions as C, Limits, MatchOptions as M, Resource};

#[test]
fn iteration_allows_nonempty_after_empty_at_the_same_position() {
    let regex = ByteRegex::new(b"|a").unwrap();
    let matches = regex
        .find_iter(b"a")
        .collect::<Result<Vec<_>, _>>()
        .unwrap();
    assert_eq!(
        matches
            .iter()
            .map(|captures| captures.range())
            .collect::<Vec<_>>(),
        vec![0..0, 0..1, 1..1]
    );
    assert_eq!(matches[2].prefix(), 1..1);
}

#[test]
fn iteration_preserves_prefix_and_original_anchor_context() {
    let regex = ByteRegex::new(br"\b").unwrap();
    let matches = regex
        .find_iter(b"ab cd")
        .collect::<Result<Vec<_>, _>>()
        .unwrap();
    assert_eq!(
        matches
            .iter()
            .map(|captures| captures.range())
            .collect::<Vec<_>>(),
        vec![0..0, 2..2, 3..3, 5..5]
    );
    assert_eq!(matches[1].prefix(), 0..2);
    assert_eq!(ByteRegex::new(br"\A").unwrap().find_iter(b"abc").count(), 1);
}

#[test]
fn iterator_reports_a_resource_error_once_then_ends() {
    let regex = ByteRegex::with_limits(
        b"(a|aa)*b",
        C::NORMAL,
        Limits {
            match_work: 20,
            ..Limits::default()
        },
    )
    .unwrap();
    let mut matches = regex.find_iter(b"aaaaaaaaaaaa");
    assert_eq!(
        matches.next().unwrap().unwrap_err().resource(),
        Some(Resource::MatchWork)
    );
    assert!(matches.next().is_none());
    assert!(matches.next().is_none());
}

#[test]
fn perl_format_uses_all_capture_and_context_placeholders() {
    let regex = ByteRegex::new(br"(?<first>a)(b)?").unwrap();
    let captures = regex.search(b"xaby").unwrap().unwrap();
    let output = regex
        .format(
            b"xaby",
            &captures,
            br"$&|$1|${2}|$+{first}|$`|$'|$$|$+|$^N",
            M::DEFAULT,
        )
        .unwrap();
    assert_eq!(output, b"ab|a|b|a|x|y|$|b|b");
    assert_eq!(
        regex
            .format(
                b"xaby",
                &captures,
                b"$MATCH/$PREMATCH/$POSTMATCH",
                M::DEFAULT
            )
            .unwrap(),
        b"ab/x/y"
    );
}

#[test]
fn formatting_modes_and_conditional_branches() {
    let regex = ByteRegex::new(b"(a)?b").unwrap();
    let matched = regex.search(b"ab").unwrap().unwrap();
    let missing = regex.search(b"b").unwrap().unwrap();
    assert_eq!(
        regex
            .format(b"ab", &matched, br"\U$&\E-\lXYZ", M::DEFAULT)
            .unwrap(),
        b"AB-xYZ"
    );
    assert_eq!(
        regex
            .format(b"ab", &matched, br"(?1yes:no)", M::FORMAT_ALL)
            .unwrap(),
        b"yes"
    );
    assert_eq!(
        regex
            .format(b"b", &missing, br"(?1yes:no)", M::FORMAT_ALL)
            .unwrap(),
        b"no"
    );
    assert_eq!(
        regex
            .format(b"ab", &matched, br"&-\1-\&", M::FORMAT_SED)
            .unwrap(),
        b"ab-a-&"
    );
    assert_eq!(
        regex
            .format(b"ab", &matched, br"$&\1", M::FORMAT_LITERAL)
            .unwrap(),
        br"$&\1"
    );
}

#[test]
fn replacement_modes_preserve_unmatched_input() {
    let regex = ByteRegex::new(br"(\d+)").unwrap();
    assert_eq!(regex.replace(b"a12b34c", b"[$1]").unwrap(), b"a[12]b[34]c");
    assert_eq!(
        regex
            .replace_with_options(b"a12b34c", b"[$1]", M::FORMAT_FIRST_ONLY)
            .unwrap(),
        b"a[12]b34c"
    );
    assert_eq!(
        regex
            .replace_with_options(b"a12b34c", b"[$1]", M::FORMAT_NO_COPY)
            .unwrap(),
        b"[12][34]"
    );
    assert_eq!(
        ByteRegex::new(b"").unwrap().replace(b"ab", b"-").unwrap(),
        b"-a-b-"
    );
}
