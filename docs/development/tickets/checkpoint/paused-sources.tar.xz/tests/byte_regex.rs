use boost_regex_rs::{
    ByteRegex, CompileOptions as C, ErrorKind, Limits, MatchOptions as M, Resource,
};
use std::ops::Range;

fn range(pattern: &[u8], input: &[u8]) -> Option<Range<usize>> {
    ByteRegex::new(pattern)
        .unwrap()
        .search(input)
        .unwrap()
        .map(|captures| captures.range())
}

#[test]
fn arbitrary_bytes_and_original_positions() {
    let regex = ByteRegex::new(&[0xff, 0, b'(', 0x80, b')']).unwrap();
    let captures = regex.search(&[b'x', 0xff, 0, 0x80, b'y']).unwrap().unwrap();
    assert_eq!(captures.groups(), &[Some(1..4), Some(3..4)]);
    assert_eq!(captures.prefix(), 0..1);
    assert_eq!(captures.suffix(), 4..5);
    assert_eq!(regex.pattern(), &[0xff, 0, b'(', 0x80, b')']);
}

#[test]
fn perl_alternation_and_posix_longest_match() {
    let regex = ByteRegex::new(b"(a|aa)").unwrap();
    assert_eq!(regex.search(b"aa").unwrap().unwrap().range(), 0..1);
    assert_eq!(
        regex
            .search_with_options(b"aa", M::POSIX)
            .unwrap()
            .unwrap()
            .groups(),
        &[Some(0..2), Some(0..2)]
    );
    assert_eq!(regex.full_match(b"aa").unwrap().unwrap().range(), 0..2);
}

#[test]
fn quantifier_order_and_atomicity() {
    assert_eq!(range(b"a+", b"aaa"), Some(0..3));
    assert_eq!(range(b"a+?", b"aaa"), Some(0..1));
    assert_eq!(range(b"a{2,3}", b"aaaa"), Some(0..3));
    assert_eq!(range(b"a{2,3}?", b"aaaa"), Some(0..2));
    assert_eq!(range(b"a*+a", b"aaa"), None);
    assert_eq!(range(b"(?>a*)a", b"aaa"), None);
    assert_eq!(range(b"(?:a?)*", b"aa"), Some(0..2));
}

#[test]
fn captures_restore_on_backtracking_and_retain_repeated_history() {
    let regex = ByteRegex::new(b"(a(b)?)+").unwrap();
    let captures = regex
        .search_with_options(b"aba", M::EXTRA)
        .unwrap()
        .unwrap();
    assert_eq!(captures.groups(), &[Some(0..3), Some(2..3), Some(1..2)]);
    assert_eq!(captures.history(1), &[0..2, 2..3]);
    assert_eq!(captures.history(2), std::slice::from_ref(&(1..2)));
    assert_eq!(range(b"(ab|a)b", b"ab"), Some(0..2));
}

#[test]
fn branch_reset_and_named_references() {
    let reset = ByteRegex::new(b"(?|(a)|(b)(c))(d)").unwrap();
    assert_eq!(reset.mark_count(), 3);
    assert_eq!(
        reset.full_match(b"bcd").unwrap().unwrap().groups(),
        &[Some(0..3), Some(0..1), Some(1..2), Some(2..3)]
    );
    let named = ByteRegex::new(br"(?<name>[a-z]+)-\k<name>").unwrap();
    assert_eq!(
        named.capture_names().get(b"name".as_slice()),
        Some(&vec![1])
    );
    assert_eq!(
        named.full_match(b"ab-ab").unwrap().unwrap().group(1),
        Some(0..2)
    );
    assert!(named.full_match(b"ab-ac").unwrap().is_none());
}

#[test]
fn lookaround_is_zero_width_and_retains_positive_captures() {
    assert_eq!(range(b"(?<=ab)c", b"zabc"), Some(3..4));
    assert_eq!(range(b"(?<!a)b", b"ab b"), Some(3..4));
    assert_eq!(range(b"a(?!b)", b"ab ac"), Some(3..4));
    let captures = ByteRegex::new(br"(?=(a+))a*b\1")
        .unwrap()
        .search(b"aaabaaa")
        .unwrap()
        .unwrap();
    assert_eq!(captures.groups(), &[Some(0..7), Some(0..3)]);
}

#[test]
fn recursive_groups_and_conditions() {
    let recursive = ByteRegex::new(br"(?<pair>\((?:[^()]|(?&pair))*\))").unwrap();
    assert_eq!(
        recursive.full_match(b"(a(b)c)").unwrap().unwrap().range(),
        0..7
    );
    assert!(recursive.full_match(b"(a(b)c").unwrap().is_none());
    assert_eq!(range(b"(a)?(?(1)b|c)", b"ab"), Some(0..2));
    assert_eq!(range(b"(a)?(?(1)b|c)", b"c"), Some(0..1));
    assert_eq!(range(b"(?(?=a)ab|bc)", b"bc"), Some(0..2));
    assert_eq!(
        range(br"(?(DEFINE)(?<word>[a-z]+))(?&word)", b"abc"),
        Some(0..3)
    );
}

#[test]
fn backtracking_control_verbs() {
    assert_eq!(range(b"a(*SKIP)(*FAIL)|b", b"aab"), Some(2..3));
    assert_eq!(range(b"a(*COMMIT)b|ac", b"ac ab"), None);
    assert_eq!(range(b"a(*PRUNE)b|ac", b"ac ab"), Some(3..5));
    assert_eq!(range(b"(?:a(*THEN)b|ac)d|acd", b"acd"), Some(0..3));
    let accepted = ByteRegex::new(b"(a(*ACCEPT)b)")
        .unwrap()
        .search(b"ab")
        .unwrap()
        .unwrap();
    assert_eq!(accepted.groups(), &[Some(0..1), Some(0..1)]);
}

#[test]
fn modifiers_quoting_and_keep_escape() {
    assert_eq!(range(b"(?i)a|b", b"B"), Some(0..1));
    assert_eq!(range(b"(?i:a)b", b"Ab"), Some(0..2));
    assert_eq!(range(b"(?i:a)b", b"AB"), None);
    assert_eq!(range(br"\Q.*\E+", b".***"), Some(0..4));
    assert_eq!(range(b"(?x) a # comment\n b", b"ab"), Some(0..2));
    let captures = ByteRegex::new(br"foo\Kbar")
        .unwrap()
        .search(b"foobar")
        .unwrap()
        .unwrap();
    assert_eq!(captures.range(), 3..6);
    assert_eq!(captures.prefix(), 0..3);
}

#[test]
fn byte_character_classes_and_dot_options() {
    assert_eq!(range(br"[[:alpha:]\d]+", b"=ab12!"), Some(1..5));
    assert_eq!(range(br"[^a-c]+", b"abZ9"), Some(2..4));
    assert_eq!(range(br"\p{digit}+", b"a12"), Some(1..3));
    assert_eq!(range(br"[[.NUL.]]", b"a\0"), Some(1..2));
    assert_eq!(range(b".", b"\n"), Some(0..1));
    let dot = ByteRegex::new(b".").unwrap();
    assert!(
        dot.search_with_options(b"\n", M::NOT_DOT_NEWLINE)
            .unwrap()
            .is_none()
    );
    assert!(
        dot.search_with_options(b"\0", M::NOT_DOT_NULL)
            .unwrap()
            .is_none()
    );
    assert!(
        ByteRegex::new(b"(?s:.)")
            .unwrap()
            .search_with_options(b"\n", M::NOT_DOT_NEWLINE)
            .unwrap()
            .is_some()
    );
}

#[test]
fn basic_extended_and_literal_grammars() {
    let basic = ByteRegex::with_options(br"\(ab\)\{2\}", C::BASIC).unwrap();
    assert_eq!(
        basic.full_match(b"abab").unwrap().unwrap().groups(),
        &[Some(0..4), Some(2..4)]
    );
    let extended = ByteRegex::with_options(b"a|aa", C::EXTENDED).unwrap();
    assert_eq!(extended.search(b"aa").unwrap().unwrap().range(), 0..2);
    let literal = ByteRegex::with_options(b"a+b[", C::LITERAL).unwrap();
    assert_eq!(literal.search(b"xa+b[").unwrap().unwrap().range(), 1..5);
}

#[test]
fn original_context_and_match_flags() {
    let regex = ByteRegex::new(b"^b").unwrap();
    assert_eq!(
        regex
            .search_from(b"a\nb", 2, M::PREV_AVAIL)
            .unwrap()
            .unwrap()
            .range(),
        2..3
    );
    assert!(
        regex
            .search_from(b"aab", 2, M::PREV_AVAIL)
            .unwrap()
            .is_none()
    );
    assert!(
        ByteRegex::new(b"a*")
            .unwrap()
            .search_with_options(b"bbb", M::NOT_NULL)
            .unwrap()
            .is_none()
    );
    assert!(
        ByteRegex::new(b"b")
            .unwrap()
            .search_with_options(b"ab", M::CONTINUOUS)
            .unwrap()
            .is_none()
    );
    let partial = ByteRegex::new(b"abcd")
        .unwrap()
        .search_with_options(b"abc", M::PARTIAL)
        .unwrap()
        .unwrap();
    assert!(partial.is_partial());
    assert_eq!(partial.range(), 0..3);
    assert_eq!(partial.group(0), None);
}

#[test]
fn error_categories_and_explicit_resources() {
    assert_eq!(ByteRegex::new(b"[").unwrap_err().kind(), ErrorKind::Bracket);
    assert_eq!(
        ByteRegex::new(b"(").unwrap_err().kind(),
        ErrorKind::Parenthesis
    );
    assert_eq!(
        ByteRegex::new(b"*").unwrap_err().kind(),
        ErrorKind::BadRepeat
    );
    assert_eq!(
        ByteRegex::new(br"\1").unwrap_err().kind(),
        ErrorKind::BackReference
    );
    let limits = Limits {
        match_work: 100,
        ..Limits::default()
    };
    let regex = ByteRegex::with_limits(b"(a|aa)*b", C::NORMAL, limits).unwrap();
    let error = regex.search(b"aaaaaaaaaaaaaaaaaaaa").unwrap_err();
    assert_eq!(error.resource(), Some(Resource::MatchWork));
}

#[test]
fn compiled_program_is_shared_but_capture_state_is_independent() {
    fn send_sync<T: Send + Sync>() {}
    send_sync::<ByteRegex>();
    let regex = ByteRegex::new(b"(a)+").unwrap();
    let other = regex.clone();
    let task = std::thread::spawn(move || {
        other
            .search_with_options(b"aaa", M::EXTRA)
            .unwrap()
            .unwrap()
    });
    let first = regex.search_with_options(b"a", M::EXTRA).unwrap().unwrap();
    assert_eq!(first.history(1), std::slice::from_ref(&(0..1)));
    assert_eq!(task.join().unwrap().history(1), &[0..1, 1..2, 2..3]);
}
