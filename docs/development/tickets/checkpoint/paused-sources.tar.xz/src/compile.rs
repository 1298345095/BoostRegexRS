//! Fixed instruction graph, lowered from the parsed byte grammar.
//!
//! Adapted from Boost.Regex 1.89.0 basic_regex_creator.hpp.
//! Copyright (c) 2004 John Maddock. Distributed under the Boost Software
//! License, Version 1.0; see LICENSE_1_0.txt and NOTICE.md.

use crate::charset::{ByteSet, CollatingSet};
use crate::start::{self, Branches, Restart, StartMap};
use crate::syntax::{self, Anchor, Condition, Node, NodeId, RepeatKind, Verb};
use crate::{CompileOptions, ErrorKind, Limits, RegexError, Resource};
use std::collections::BTreeMap;

pub(crate) type Address = usize;

#[derive(Clone, Debug)]
pub(crate) struct Program {
    pub pattern: Vec<u8>,
    pub options: CompileOptions,
    pub code: Vec<Instruction>,
    pub groups: Vec<Option<Address>>,
    pub names: BTreeMap<Vec<u8>, Vec<usize>>,
    pub repeat_count: usize,
    pub start: StartMap,
    pub branches: Vec<Branches>,
    pub restart: Restart,
    pub disable_match_any: bool,
    pub error: Option<RegexError>,
    pub mark_count: usize,
}

#[derive(Clone, Debug)]
pub(crate) enum Test {
    Matched(Vec<usize>),
    Recursing(Option<Vec<usize>>),
    Define,
}

#[derive(Clone, Copy, Debug)]
pub(crate) enum Scope {
    Assertion {
        negative: bool,
        behind: Option<usize>,
    },
    Atomic,
    Condition {
        negative: bool,
        yes: Address,
        no: Address,
        behind: Option<usize>,
    },
}

#[derive(Clone, Debug)]
pub(crate) enum Instruction {
    Byte(u8, bool),
    Literal(Vec<u8>, bool),
    Set(ByteSet),
    CollatingSet(CollatingSet),
    Dot(Option<bool>),
    Anchor(Anchor),
    Jump(Address),
    Alternative {
        second: Address,
        prediction: usize,
    },
    Open {
        group: usize,
        end: Address,
    },
    Close(usize),
    Group {
        end: Address,
    },
    GroupEnd,
    RepeatStart {
        slot: usize,
    },
    Repeat {
        slot: usize,
        min: usize,
        max: usize,
        greedy: bool,
        exit: Address,
        prediction: usize,
        simple: bool,
        leading: bool,
    },
    BackRef {
        groups: Vec<usize>,
        icase: bool,
    },
    ScopeStart {
        scope: Scope,
        end: Address,
    },
    ScopeEnd,
    Backstep(usize),
    Call(usize),
    Condition {
        test: Test,
        no: Address,
    },
    ConditionalEnd,
    ResetStart,
    Verb(Verb),
    Match,
}

pub(crate) fn compile(parsed: syntax::Program, limits: Limits) -> Result<Program, RegexError> {
    if parsed.error.is_some() {
        return Ok(invalid(parsed));
    }
    let mut compiler = Compiler {
        parsed: &parsed,
        code: Vec::new(),
        groups: vec![None; parsed.groups.len()],
        repeat_count: 0,
        limits,
    };
    compiler.groups[0] = Some(0);
    let result = (|| {
        compiler.node(parsed.root, 0)?;
        compiler.emit(Instruction::Match)?;
        start::analyze(&mut compiler.code, &compiler.groups, limits)
    })();
    let metadata = match result {
        Ok(metadata) => metadata,
        Err(error) => {
            if !parsed.options.contains(CompileOptions::NO_EXCEPT) || error.resource().is_some() {
                return Err(error);
            }
            let mut parsed = parsed;
            parsed.error = Some(error);
            return Ok(invalid(parsed));
        }
    };
    Ok(Program {
        code: compiler.code,
        groups: compiler.groups,
        repeat_count: compiler.repeat_count,
        start: metadata.start,
        branches: metadata.branches,
        restart: metadata.restart,
        disable_match_any: metadata.disable_match_any,
        error: None,
        mark_count: parsed.mark_count,
        pattern: parsed.pattern,
        options: parsed.options,
        names: parsed.names,
    })
}

fn invalid(parsed: syntax::Program) -> Program {
    Program {
        pattern: parsed.pattern,
        options: parsed.options,
        code: Vec::new(),
        groups: parsed.groups,
        names: parsed.names,
        repeat_count: 0,
        start: StartMap {
            bytes: ByteSet::empty(),
            nullable: false,
        },
        branches: Vec::new(),
        restart: Restart::Any,
        disable_match_any: false,
        error: parsed.error,
        mark_count: parsed.mark_count,
    }
}

struct Compiler<'a> {
    parsed: &'a syntax::Program,
    code: Vec<Instruction>,
    groups: Vec<Option<Address>>,
    repeat_count: usize,
    limits: Limits,
}

impl Compiler<'_> {
    fn emit(&mut self, instruction: Instruction) -> Result<Address, RegexError> {
        if self.code.len() >= self.limits.compile_work {
            return Err(RegexError::limit(
                Resource::CompileWork,
                self.parsed.pattern.len(),
            ));
        }
        let address = self.code.len();
        self.code.push(instruction);
        Ok(address)
    }

    fn node(&mut self, node: NodeId, depth: usize) -> Result<(), RegexError> {
        if depth > self.limits.nesting {
            return Err(RegexError::limit(
                Resource::Nesting,
                self.parsed.pattern.len(),
            ));
        }
        match &self.parsed.nodes[node] {
            Node::Empty => {}
            Node::Byte(byte, icase) => {
                self.emit(Instruction::Byte(*byte, *icase))?;
            }
            Node::Set(set) => {
                self.emit(Instruction::Set(*set))?;
            }
            Node::CollatingSet(set) => {
                self.emit(Instruction::CollatingSet(set.clone()))?;
            }
            Node::Dot(mode) => {
                self.emit(Instruction::Dot(*mode))?;
            }
            Node::Combining => {
                let mut set = ByteSet::empty();
                set.negate();
                self.emit(Instruction::Set(set))?;
            }
            Node::Anchor(anchor) => {
                self.emit(Instruction::Anchor(*anchor))?;
            }
            Node::Sequence(children) => {
                let mut index = 0;
                while index < children.len() {
                    if let Node::Byte(_, icase) = self.parsed.nodes[children[index]] {
                        let mut bytes = Vec::new();
                        while let Some(child) = children.get(index) {
                            if let Node::Byte(byte, mode) = self.parsed.nodes[*child] {
                                if mode != icase {
                                    break;
                                }
                                bytes.push(byte);
                                index += 1;
                            } else {
                                break;
                            }
                        }
                        if bytes.len() == 1 {
                            self.emit(Instruction::Byte(bytes[0], icase))?;
                        } else {
                            self.emit(Instruction::Literal(bytes, icase))?;
                        }
                    } else {
                        self.node(children[index], depth + 1)?;
                        index += 1;
                    }
                }
            }
            Node::Alternative(children) => {
                let mut ends = Vec::new();
                for (index, child) in children.iter().enumerate() {
                    if index + 1 < children.len() {
                        let branch = self.emit(Instruction::Alternative {
                            second: 0,
                            prediction: 0,
                        })?;
                        self.node(*child, depth + 1)?;
                        ends.push(self.emit(Instruction::Jump(0))?);
                        self.code[branch] = Instruction::Alternative {
                            second: self.code.len(),
                            prediction: 0,
                        };
                    } else {
                        self.node(*child, depth + 1)?;
                    }
                }
                let end = self.code.len();
                for jump in ends {
                    self.code[jump] = Instruction::Jump(end);
                }
            }
            Node::Capture { group, child } => {
                let start = self.emit(Instruction::Open {
                    group: *group,
                    end: 0,
                })?;
                // Boost resolves duplicate capture numbers/names to the first opening.
                self.groups[*group].get_or_insert(start);
                self.node(*child, depth + 1)?;
                let end = self.emit(Instruction::Close(*group))?;
                self.code[start] = Instruction::Open { group: *group, end };
            }
            Node::Group(child) => {
                let start = self.emit(Instruction::Group { end: 0 })?;
                self.node(*child, depth + 1)?;
                let end = self.emit(Instruction::GroupEnd)?;
                self.code[start] = Instruction::Group { end };
            }
            Node::Repeat {
                child,
                min,
                max,
                kind,
            } => {
                let atomic = if *kind == RepeatKind::Possessive {
                    Some(self.emit(Instruction::ScopeStart {
                        scope: Scope::Atomic,
                        end: 0,
                    })?)
                } else {
                    None
                };
                let slot = self.repeat_count;
                self.repeat_count += 1;
                let simple = matches!(
                    self.parsed.nodes[*child],
                    Node::Byte(..) | Node::Set(_) | Node::Dot(_)
                );
                self.emit(Instruction::RepeatStart { slot })?;
                let repeat = self.emit(Instruction::Repeat {
                    slot,
                    min: *min,
                    max: max.unwrap_or(usize::MAX),
                    greedy: *kind != RepeatKind::Lazy,
                    exit: 0,
                    prediction: 0,
                    simple,
                    leading: false,
                })?;
                self.node(*child, depth + 1)?;
                self.emit(Instruction::Jump(repeat))?;
                let exit = self.code.len();
                self.code[repeat] = Instruction::Repeat {
                    slot,
                    min: *min,
                    max: max.unwrap_or(usize::MAX),
                    greedy: *kind != RepeatKind::Lazy,
                    exit,
                    prediction: 0,
                    simple,
                    leading: false,
                };
                if let Some(start) = atomic {
                    let end = self.emit(Instruction::ScopeEnd)?;
                    self.code[start] = Instruction::ScopeStart {
                        scope: Scope::Atomic,
                        end,
                    };
                }
            }
            Node::BackRef(reference, icase) => {
                self.emit(Instruction::BackRef {
                    groups: self.parsed.reference_groups(reference).to_vec(),
                    icase: *icase,
                })?;
            }
            Node::Look {
                child,
                negative,
                behind,
            } => {
                let behind = if behind.is_some() {
                    Some(
                        self.parsed
                            .width(*child)
                            .filter(|width| *width <= i32::MAX as usize)
                            .ok_or_else(|| {
                                RegexError::new(
                                    ErrorKind::BadPattern,
                                    0,
                                    "Invalid fixed-width lookbehind",
                                )
                            })?,
                    )
                } else {
                    None
                };
                self.scope(
                    *child,
                    Scope::Assertion {
                        negative: *negative,
                        behind,
                    },
                    depth,
                )?;
            }
            Node::Atomic(child) => {
                self.scope(*child, Scope::Atomic, depth)?;
            }
            Node::Call(reference) => {
                self.emit(Instruction::Call(
                    self.parsed.reference_groups(reference)[0],
                ))?;
            }
            Node::Conditional { condition, yes, no } => {
                let start = self.code.len();
                match condition {
                    Condition::Assert {
                        child,
                        negative,
                        behind,
                    } => {
                        let behind = if *behind {
                            Some(
                                self.parsed
                                    .width(*child)
                                    .filter(|width| *width <= i32::MAX as usize)
                                    .ok_or_else(|| {
                                        RegexError::new(
                                            ErrorKind::BadPattern,
                                            0,
                                            "Invalid fixed-width conditional lookbehind",
                                        )
                                    })?,
                            )
                        } else {
                            None
                        };
                        self.scope(
                            *child,
                            Scope::Condition {
                                negative: *negative,
                                yes: 0,
                                no: 0,
                                behind,
                            },
                            depth,
                        )?;
                    }
                    _ => {
                        let test = match condition {
                            Condition::Matched(reference) => {
                                Test::Matched(self.parsed.reference_groups(reference).to_vec())
                            }
                            Condition::Recursing(reference) => {
                                Test::Recursing(reference.as_ref().map(|reference| {
                                    self.parsed.reference_groups(reference).to_vec()
                                }))
                            }
                            Condition::Define => Test::Define,
                            Condition::Assert { .. } => unreachable!(),
                        };
                        self.emit(Instruction::Condition { test, no: 0 })?;
                    }
                }
                let yes_start = self.code.len();
                self.node(*yes, depth + 1)?;
                let jump = self.emit(Instruction::Jump(0))?;
                let no_start = self.code.len();
                self.node(*no, depth + 1)?;
                self.code[jump] = Instruction::Jump(self.code.len());
                self.emit(Instruction::ConditionalEnd)?;
                match &mut self.code[start] {
                    Instruction::ScopeStart {
                        scope: Scope::Condition { yes, no, .. },
                        ..
                    } => {
                        *yes = yes_start;
                        *no = no_start;
                    }
                    Instruction::Condition { no, .. } => *no = no_start,
                    _ => unreachable!(),
                }
            }
            Node::ResetStart => {
                self.emit(Instruction::ResetStart)?;
            }
            Node::Verb(verb) => {
                self.emit(Instruction::Verb(*verb))?;
            }
        }
        Ok(())
    }

    fn scope(&mut self, child: NodeId, scope: Scope, depth: usize) -> Result<(), RegexError> {
        let start = self.emit(Instruction::ScopeStart { scope, end: 0 })?;
        if let Scope::Assertion {
            behind: Some(length),
            ..
        }
        | Scope::Condition {
            behind: Some(length),
            ..
        } = scope
        {
            self.emit(Instruction::Backstep(length))?;
        }
        self.node(child, depth + 1)?;
        let end = self.emit(Instruction::ScopeEnd)?;
        self.code[start] = Instruction::ScopeStart { scope, end };
        Ok(())
    }
}
