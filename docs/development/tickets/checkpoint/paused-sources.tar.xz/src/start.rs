//! Start maps, nullability and zero-prefix recursion checks.
//!
//! Adapted from Boost.Regex 1.89.0 basic_regex_creator.hpp.
//! Copyright (c) 2004 John Maddock. Distributed under the Boost Software
//! License, Version 1.0; see LICENSE_1_0.txt and NOTICE.md.

use crate::charset::ByteSet;
use crate::compile::{Address, Instruction, Scope};
use crate::syntax::{Anchor, Verb};
use crate::{ErrorKind, Limits, RegexError, Resource};

#[derive(Clone, Copy, Debug)]
pub(crate) struct StartMap {
    pub(crate) bytes: ByteSet,
    pub(crate) nullable: bool,
}

impl StartMap {
    fn empty() -> Self {
        Self {
            bytes: ByteSet::empty(),
            nullable: false,
        }
    }
    fn all(nullable: bool) -> Self {
        let mut bytes = ByteSet::empty();
        bytes.negate();
        Self { bytes, nullable }
    }
    fn union(&mut self, other: Self) {
        self.bytes.union(other.bytes);
        self.nullable |= other.nullable;
    }
    pub(crate) fn accepts(self, byte: Option<u8>) -> bool {
        byte.map_or(self.nullable, |byte| self.bytes.contains(byte))
    }
}

#[derive(Clone, Copy, Debug)]
pub(crate) struct Branches {
    pub(crate) take: StartMap,
    pub(crate) skip: StartMap,
}

impl Branches {
    fn combined(self) -> StartMap {
        let mut result = self.take;
        result.union(self.skip);
        result
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum Restart {
    Any,
    Line,
    Word,
    Buffer,
    Continue,
}

pub(crate) struct Metadata {
    pub(crate) start: StartMap,
    pub(crate) branches: Vec<Branches>,
    pub(crate) restart: Restart,
    pub(crate) disable_match_any: bool,
}

pub(crate) fn analyze(
    code: &mut [Instruction],
    groups: &[Option<Address>],
    limits: Limits,
) -> Result<Metadata, RegexError> {
    let mut addresses = Vec::new();
    for (address, instruction) in code.iter_mut().enumerate() {
        if let Instruction::Alternative { prediction, .. }
        | Instruction::Repeat { prediction, .. } = instruction
        {
            *prediction = addresses.len();
            addresses.push(address);
        }
    }
    let mut analyzer = Analyzer {
        code,
        groups,
        branches: vec![None; addresses.len()],
        limits,
        work: code.len(),
        bad_repeats: 0,
    };
    // Later alternatives are finalized first; earlier maps reuse their unions.
    for &address in addresses.iter().rev() {
        let (prediction, skip) = match code[address] {
            Instruction::Alternative { prediction, second } => (prediction, second),
            Instruction::Repeat {
                prediction, exit, ..
            } => (prediction, exit),
            _ => unreachable!(),
        };
        let take = analyzer.entry(address + 1)?;
        let skip = analyzer.entry(skip)?;
        analyzer.branches[prediction] = Some(Branches { take, skip });
    }
    let start = analyzer.entry(0)?;
    let branches = analyzer
        .branches
        .into_iter()
        .map(|branch| branch.expect("all branch maps have been finalized"))
        .collect();
    let restart = code
        .iter()
        .find_map(|instruction| match instruction {
            Instruction::Open { .. }
            | Instruction::Close(_)
            | Instruction::Group { .. }
            | Instruction::GroupEnd => None,
            Instruction::Anchor(Anchor::LineStart(_)) => Some(Restart::Line),
            Instruction::Anchor(Anchor::WordStart) => Some(Restart::Word),
            Instruction::Anchor(Anchor::BufferStart) => Some(Restart::Buffer),
            Instruction::Anchor(Anchor::Continue) => Some(Restart::Continue),
            _ => Some(Restart::Any),
        })
        .unwrap_or(Restart::Any);
    let disable_match_any = code.iter().any(|instruction| {
        matches!(
            instruction,
            Instruction::Verb(Verb::Commit | Verb::Prune | Verb::Skip | Verb::Then)
        )
    });
    mark_leading_repeat(code);
    Ok(Metadata {
        start,
        branches,
        restart,
        disable_match_any,
    })
}

fn mark_leading_repeat(code: &mut [Instruction]) {
    if code
        .iter()
        .any(|instruction| matches!(instruction, Instruction::BackRef { .. }))
    {
        return;
    }
    let mut address = 0;
    loop {
        match &mut code[address] {
            Instruction::Open { .. }
            | Instruction::Close(_)
            | Instruction::Group { .. }
            | Instruction::GroupEnd
            | Instruction::ScopeEnd
            | Instruction::RepeatStart { .. } => {}
            Instruction::Anchor(anchor) if !matches!(anchor, Anchor::SoftEnd) => {}
            Instruction::ScopeStart {
                scope: Scope::Assertion { .. },
                end,
            } => {
                address = *end + 1;
                continue;
            }
            Instruction::ScopeStart {
                scope: Scope::Atomic,
                ..
            } => {}
            Instruction::Repeat {
                simple: true,
                leading,
                ..
            } => {
                *leading = true;
                return;
            }
            _ => return,
        }
        address += 1;
    }
}

struct Analyzer<'a> {
    code: &'a [Instruction],
    groups: &'a [Option<Address>],
    branches: Vec<Option<Branches>>,
    limits: Limits,
    work: usize,
    bad_repeats: u64,
}

impl Analyzer<'_> {
    fn entry(&mut self, address: Address) -> Result<StartMap, RegexError> {
        self.bad_repeats = 0;
        self.walk(address, vec![0; self.groups.len()], 0)
    }

    fn walk(
        &mut self,
        mut address: Address,
        mut recursions: Vec<u8>,
        depth: usize,
    ) -> Result<StartMap, RegexError> {
        if depth > self.limits.nesting {
            return Err(RegexError::limit(Resource::Nesting, 0));
        }
        let mut result = StartMap::empty();
        let mut active_call = None;
        let mut after_jump = false;
        loop {
            self.work += 1;
            if self.work > self.limits.compile_work {
                return Err(RegexError::limit(Resource::CompileWork, 0));
            }
            let following_jump = std::mem::take(&mut after_jump);
            match &self.code[address] {
                Instruction::Byte(byte, icase) => {
                    result.bytes.insert(*byte);
                    if *icase {
                        result.bytes.fold();
                    }
                    return Ok(result);
                }
                Instruction::Literal(bytes, icase) => {
                    result.bytes.insert(bytes[0]);
                    if *icase {
                        result.bytes.fold();
                    }
                    return Ok(result);
                }
                Instruction::Set(set) => {
                    result.bytes.union(*set);
                    return Ok(result);
                }
                Instruction::CollatingSet(_) | Instruction::Dot(_) => {
                    result.union(StartMap::all(false));
                    return Ok(result);
                }
                Instruction::BackRef { .. } => {
                    result.union(StartMap::all(true));
                    return Ok(result);
                }
                Instruction::Match
                | Instruction::Verb(Verb::Accept)
                | Instruction::ScopeEnd
                | Instruction::ConditionalEnd => {
                    result.union(StartMap::all(true));
                    return Ok(result);
                }
                Instruction::Anchor(Anchor::BufferEnd) => {
                    result.nullable = true;
                    return Ok(result);
                }
                Instruction::Anchor(Anchor::SoftEnd) => {
                    result.bytes.insert(b'\n');
                    result.bytes.insert(b'\r');
                    result.nullable = true;
                    return Ok(result);
                }
                Instruction::Anchor(Anchor::LineEnd(_)) => {
                    for byte in [b'\n', b'\r', 12, 0x85] {
                        result.bytes.insert(byte);
                    }
                    result.nullable |= self.walk(address + 1, recursions, depth + 1)?.nullable;
                    return Ok(result);
                }
                Instruction::Anchor(Anchor::WordStart | Anchor::WordEnd) => {
                    let want_word =
                        matches!(self.code[address], Instruction::Anchor(Anchor::WordStart));
                    result.union(self.walk(address + 1, recursions, depth + 1)?);
                    let mut filtered = ByteSet::empty();
                    for byte in 0u8..=255 {
                        if result.bytes.contains(byte)
                            && (byte.is_ascii_alphanumeric() || byte == b'_') == want_word
                        {
                            filtered.insert(byte);
                        }
                    }
                    result.bytes = filtered;
                    return Ok(result);
                }
                Instruction::Jump(target) => {
                    address = *target;
                    after_jump = true;
                    continue;
                }
                Instruction::Alternative { prediction, second } => {
                    let known = self.branches[*prediction];
                    if let Some(known) = known {
                        result.union(known.combined());
                    } else {
                        let second = *second;
                        result.union(self.walk(address + 1, recursions.clone(), depth + 1)?);
                        result.union(self.walk(second, recursions, depth + 1)?);
                    }
                    return Ok(result);
                }
                Instruction::Repeat {
                    prediction,
                    slot,
                    min,
                    exit,
                    ..
                } => {
                    if let Some(known) = self.branches[*prediction] {
                        result.union(known.combined());
                    } else if *slot >= u64::BITS as usize || self.bad_repeats & (1u64 << slot) != 0
                    {
                        result.union(StartMap::all(true));
                    } else {
                        self.bad_repeats |= 1u64 << slot;
                        let exit = *exit;
                        let can_skip = *min == 0 || following_jump;
                        result.union(self.walk(address + 1, recursions.clone(), depth + 1)?);
                        if can_skip {
                            result.union(self.walk(exit, recursions, depth + 1)?);
                        }
                    }
                    return Ok(result);
                }
                Instruction::Call(group) => {
                    let group = *group;
                    if recursions[group] & 1 != 0 {
                        return Err(RegexError::new(
                            ErrorKind::BadPattern,
                            0,
                            "Encountered an infinite recursion",
                        ));
                    }
                    recursions[group] |= 1;
                    if active_call.is_some() {
                        result.union(StartMap::all(true));
                        return Ok(result);
                    }
                    active_call = Some((group, address + 1));
                    address = self.groups[group]
                        .expect("recursive targets are resolved before start analysis");
                    continue;
                }
                Instruction::Close(group) => {
                    let group = *group;
                    if let Some((target, restart)) = active_call
                        && group != 0
                        && group == target
                    {
                        active_call = None;
                        address = restart;
                        continue;
                    }
                    if group != 0 && recursions[group] & 2 == 0
                        && let Some(call) = self.code.iter().position(|instruction| matches!(instruction, Instruction::Call(target) if *target == group))
                    {
                        recursions[group] |= 2;
                        result.union(self.walk(call + 1, recursions.clone(), depth + 1)?);
                    }
                }
                Instruction::ScopeStart {
                    scope: Scope::Assertion { .. } | Scope::Condition { .. },
                    end,
                } => {
                    address = *end;
                    continue;
                }
                Instruction::Condition { no, .. } => {
                    let no = *no;
                    result.union(self.walk(address + 1, recursions.clone(), depth + 1)?);
                    result.union(self.walk(no, recursions, depth + 1)?);
                    return Ok(result);
                }
                Instruction::Verb(Verb::Commit | Verb::Prune | Verb::Skip) => {
                    result.bytes = StartMap::all(false).bytes;
                }
                _ => {}
            }
            address += 1;
        }
    }
}
