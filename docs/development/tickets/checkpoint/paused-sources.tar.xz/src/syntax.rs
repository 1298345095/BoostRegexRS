//! Pattern parsing and immutable compiled representation.
//!
//! Adapted from Boost.Regex 1.89.0 basic_regex_parser.hpp.
//! Copyright (c) 2004 John Maddock. Distributed under the Boost Software
//! License, Version 1.0; see LICENSE_1_0.txt and NOTICE.md.
//! Nodes refer to arena indices, including recursive subexpressions.

use crate::charset::{BracketSet, ByteSet, CollatingSet, Element, SetEncoding, collating_element};
use crate::options::Grammar;
use crate::{CompileOptions, ErrorKind, Limits, RegexError, Resource};
use std::collections::BTreeMap;

pub(crate) type NodeId = usize;

#[derive(Clone, Debug)]
pub(crate) struct Program {
    pub pattern: Vec<u8>,
    pub options: CompileOptions,
    pub nodes: Vec<Node>,
    pub root: NodeId,
    pub groups: Vec<Option<NodeId>>,
    pub names: BTreeMap<Vec<u8>, Vec<usize>>,
    pub error: Option<RegexError>,
    pub mark_count: usize,
}

#[derive(Clone, Debug)]
pub(crate) enum GroupRef {
    Number(usize),
    Name(Vec<u8>),
}

#[derive(Clone, Copy, Debug)]
pub(crate) enum Anchor {
    LineStart(bool),
    LineEnd(bool),
    BufferStart,
    BufferEnd,
    SoftEnd,
    Word,
    NotWord,
    WordStart,
    WordEnd,
    Continue,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum RepeatKind {
    Greedy,
    Lazy,
    Possessive,
}

#[derive(Clone, Copy, Debug)]
pub(crate) enum Verb {
    Fail,
    Accept,
    Prune,
    Skip,
    Commit,
    Then,
}

#[derive(Clone, Debug)]
pub(crate) enum Condition {
    Matched(GroupRef),
    Recursing(Option<GroupRef>),
    Assert {
        child: NodeId,
        negative: bool,
        behind: bool,
    },
    Define,
}

#[derive(Clone, Debug)]
pub(crate) enum Node {
    Empty,
    Byte(u8, bool),
    Set(ByteSet),
    CollatingSet(CollatingSet),
    Dot(Option<bool>),
    Combining,
    Sequence(Vec<NodeId>),
    Alternative(Vec<NodeId>),
    Repeat {
        child: NodeId,
        min: usize,
        max: Option<usize>,
        kind: RepeatKind,
    },
    Capture {
        group: usize,
        child: NodeId,
    },
    Group(NodeId),
    Anchor(Anchor),
    BackRef(GroupRef, bool),
    Look {
        child: NodeId,
        negative: bool,
        behind: Option<usize>,
    },
    Atomic(NodeId),
    Call(GroupRef),
    Conditional {
        condition: Condition,
        yes: NodeId,
        no: NodeId,
    },
    ResetStart,
    Verb(Verb),
}

impl Program {
    pub fn reference_groups<'a>(&'a self, reference: &'a GroupRef) -> &'a [usize] {
        match reference {
            GroupRef::Number(number) => std::slice::from_ref(number),
            GroupRef::Name(name) => self.names.get(name).map_or(&[], Vec::as_slice),
        }
    }

    pub(crate) fn width(&self, node: NodeId) -> Option<usize> {
        match &self.nodes[node] {
            Node::Empty
            | Node::Anchor(_)
            | Node::Look { .. }
            | Node::ResetStart
            | Node::Verb(_) => Some(0),
            Node::Byte(..) | Node::Set(_) | Node::Dot(_) => Some(1),
            Node::Sequence(children) => children.iter().try_fold(0usize, |total, child| {
                total.checked_add(self.width(*child)?)
            }),
            Node::Alternative(children) => {
                let width = self.width(*children.first()?)?;
                children
                    .iter()
                    .all(|child| self.width(*child) == Some(width))
                    .then_some(width)
            }
            Node::Capture { child, .. } | Node::Atomic(child) | Node::Group(child) => {
                self.width(*child)
            }
            Node::Repeat {
                child,
                min,
                max: Some(max),
                ..
            } if min == max
                && matches!(
                    self.nodes[*child],
                    Node::Byte(..) | Node::Set(_) | Node::Dot(_)
                ) =>
            {
                Some(*min)
            }
            Node::Conditional { yes, no, .. } => {
                let width = self.width(*yes)?;
                (self.width(*no) == Some(width)).then_some(width)
            }
            Node::Call(_) => Some(0),
            _ => None,
        }
    }
}

pub(crate) fn parse(
    pattern: &[u8],
    options: CompileOptions,
    limits: Limits,
) -> Result<Program, RegexError> {
    if pattern.len() > limits.compile_work {
        return Err(RegexError::limit(Resource::CompileWork, 0));
    }
    let mut parser = Parser {
        program: Program {
            pattern: pattern.to_vec(),
            options,
            nodes: vec![],
            root: 0,
            groups: vec![None],
            names: BTreeMap::new(),
            error: None,
            mark_count: usize::MAX,
        },
        position: 0,
        flags: options,
        limits,
        depth: 0,
        group_count: 0,
        quoted: false,
        preserve_flags: false,
        openings: Vec::new(),
        last: LastState::None,
    };
    if let Err(error) = parser.parse_body() {
        if !options.contains(CompileOptions::NO_EXCEPT) || error.resource().is_some() {
            return Err(error);
        }
        parser.program.error = Some(error);
    }
    Ok(parser.program)
}

impl Parser {
    fn parse_body(&mut self) -> Result<(), RegexError> {
        let options = self.program.options;
        if self.bytes().is_empty()
            && (options.grammar() != Grammar::Extended
                || options.contains(CompileOptions::NO_EMPTY_EXPRESSIONS))
        {
            return Err(self.error(ErrorKind::Empty, "Empty regular expression"));
        }
        if options.grammar() == Grammar::Invalid {
            return Err(self.error(ErrorKind::Unknown, "Invalid main grammar flags"));
        }
        let root = if options.literal() {
            let pattern = self.bytes().to_vec();
            let parser = &mut *self;
            let children = pattern
                .iter()
                .map(|byte| parser.add(Node::Byte(*byte, options.contains(CompileOptions::ICASE))))
                .collect::<Result<_, _>>()?;
            parser.position = pattern.len();
            parser.add(Node::Sequence(children))?
        } else {
            self.alternative(false, false)?
        };
        if self.position != self.bytes().len() {
            return Err(self.error(ErrorKind::Parenthesis, "Unmatched closing parenthesis"));
        }
        self.program.root = root;
        self.program.groups[0] = Some(root);
        self.program.mark_count = self.group_count;
        let has_calls = self
            .program
            .nodes
            .iter()
            .any(|node| matches!(node, Node::Call(_)));
        for node in &self.program.nodes {
            if has_calls
                && let Node::Conditional {
                    condition: Condition::Recursing(Some(GroupRef::Name(name))),
                    ..
                } = node
                && self
                    .program
                    .names
                    .get(name)
                    .is_none_or(|groups| groups.iter().all(|group| *group == 0))
            {
                return Err(RegexError::new(
                    ErrorKind::BadPattern,
                    0,
                    "Recursive condition refers to an unknown subexpression",
                ));
            }
            let reference = match node {
                Node::BackRef(reference, _) | Node::Call(reference) => Some(reference),
                _ => None,
            };
            if let Some(reference) = reference
                && (self.program.reference_groups(reference).is_empty()
                    || self
                        .program
                        .reference_groups(reference)
                        .iter()
                        .any(|group| *group >= self.program.groups.len()))
            {
                let error = if matches!(node, Node::Call(_)) {
                    RegexError::new(
                        ErrorKind::BadPattern,
                        0,
                        "Reference to an unknown recursive subexpression",
                    )
                } else {
                    self.error(
                        ErrorKind::BackReference,
                        "Reference to an unknown subexpression",
                    )
                };
                return Err(error);
            }
        }
        Ok(())
    }
}

struct Parser {
    program: Program,
    position: usize,
    flags: CompileOptions,
    limits: Limits,
    depth: usize,
    group_count: usize,
    quoted: bool,
    preserve_flags: bool,
    openings: Vec<usize>,
    last: LastState,
}

#[derive(Clone, Copy, Eq, PartialEq)]
enum LastState {
    None,
    LineStart,
    Other,
}

impl Parser {
    fn error(&self, kind: ErrorKind, message: &'static str) -> RegexError {
        RegexError::new(kind, self.position, message)
    }
    fn extension_error(&self, kind: ErrorKind, message: &'static str) -> RegexError {
        RegexError::new(kind, self.openings.last().copied().unwrap_or(0), message)
    }
    fn bytes(&self) -> &[u8] {
        &self.program.pattern
    }
    fn peek(&self) -> Option<u8> {
        self.bytes().get(self.position).copied()
    }
    fn starts(&self, value: &[u8]) -> bool {
        self.bytes()[self.position..].starts_with(value)
    }
    fn take(&mut self) -> Option<u8> {
        let result = self.peek();
        if result.is_some() {
            self.position += 1;
        }
        result
    }
    fn add(&mut self, node: Node) -> Result<NodeId, RegexError> {
        if self.program.nodes.len() >= self.limits.compile_work {
            return Err(RegexError::limit(Resource::CompileWork, self.position));
        }
        let id = self.program.nodes.len();
        self.program.nodes.push(node);
        Ok(id)
    }
    fn skip_ignored(&mut self) {
        loop {
            if self.quoted && self.starts(b"\\E") {
                self.position += 2;
                self.quoted = false;
                continue;
            }
            if self.quoted || !self.flags.perl() || !self.flags.contains(CompileOptions::MOD_X) {
                break;
            }
            match self.peek() {
                Some(byte) if is_space(byte) => {
                    self.position += 1;
                }
                Some(b'#') => {
                    while self
                        .take()
                        .is_some_and(|byte| !matches!(byte, b'\n' | b'\r' | 12))
                    {
                    }
                }
                _ => break,
            }
        }
    }
    fn operator(&self, operator: u8) -> usize {
        if self.quoted {
            return 0;
        }
        if operator == b'|'
            && self.peek() == Some(b'\n')
            && self.flags.contains(CompileOptions::NEWLINE_ALT)
        {
            return 1;
        }
        if !self.flags.basic() {
            return usize::from(self.peek() == Some(operator));
        }
        match operator {
            b'(' | b')' => {
                if self.starts(&[b'\\', operator]) {
                    2
                } else {
                    0
                }
            }
            b'|' if self.flags.contains(CompileOptions::BK_VBAR) => {
                if self.starts(b"\\|") {
                    2
                } else {
                    0
                }
            }
            b'+' | b'?' => {
                if self.flags.contains(CompileOptions::BK_PLUS_QM)
                    && self.starts(&[b'\\', operator])
                {
                    2
                } else {
                    usize::from(self.flags.emacs() && self.peek() == Some(operator))
                }
            }
            b'{' | b'}' if !self.flags.contains(CompileOptions::NO_INTERVALS) => {
                if self.starts(&[b'\\', operator]) {
                    2
                } else {
                    0
                }
            }
            b'*' | b'[' | b'.' | b'^' | b'$' => usize::from(self.peek() == Some(operator)),
            _ => 0,
        }
    }

    fn alternative(&mut self, in_group: bool, reset_groups: bool) -> Result<NodeId, RegexError> {
        let first_group = self.group_count;
        let mut max_group = first_group;
        let mut children = vec![];
        loop {
            if reset_groups {
                self.group_count = first_group;
            }
            let child = self.sequence(in_group)?;
            let empty = matches!(self.program.nodes[child], Node::Empty);
            if empty
                && (self.flags.basic() || self.flags.contains(CompileOptions::NO_EMPTY_EXPRESSIONS))
                && (!children.is_empty() || self.operator(b'|') != 0)
            {
                return Err(self.error(ErrorKind::Empty, "Empty alternative"));
            }
            children.push(child);
            max_group = max_group.max(self.group_count);
            let length = self.operator(b'|');
            if length == 0 {
                break;
            }
            self.position += length;
            self.last = LastState::Other;
        }
        if reset_groups {
            self.group_count = max_group;
        }
        if children.len() == 1 {
            Ok(children[0])
        } else {
            self.add(Node::Alternative(children))
        }
    }

    fn sequence(&mut self, in_group: bool) -> Result<NodeId, RegexError> {
        let mut children = vec![];
        loop {
            self.skip_ignored();
            if self.peek().is_none() || self.operator(b'|') != 0 || self.operator(b')') != 0 {
                break;
            }
            let child = self.atom()?;
            if matches!(self.program.nodes[child], Node::Empty) {
                if let Some(previous) = children.pop() {
                    children.push(self.quantifier(previous)?);
                }
                continue;
            }
            let child = self.quantifier(child)?;
            self.last = if matches!(
                self.program.nodes[child],
                Node::Anchor(Anchor::LineStart(_))
            ) {
                LastState::LineStart
            } else {
                LastState::Other
            };
            children.push(child);
        }
        if !in_group && self.operator(b')') != 0 {
            return Err(self.error(ErrorKind::Parenthesis, "Unmatched closing parenthesis"));
        }
        match children.len() {
            0 => self.add(Node::Empty),
            1 => Ok(children[0]),
            _ => self.add(Node::Sequence(children)),
        }
    }

    fn atom(&mut self) -> Result<NodeId, RegexError> {
        if self.quoted {
            let byte = self.take().unwrap();
            if byte == b'\\' && self.peek().is_none() {
                return Err(self.error(ErrorKind::Escape, "Trailing escape in quoted text"));
            }
            return self.literal(byte);
        }
        let opening = self.operator(b'(');
        if opening != 0 {
            let origin = self.position + opening - 1;
            self.position += opening;
            self.openings.push(origin);
            self.last = LastState::Other;
            let group = self.group();
            self.openings.pop();
            return group;
        }
        if self.operator(b'[') != 0 {
            self.position += 1;
            return self.character_set();
        }
        if self.operator(b'*') != 0 || self.operator(b'+') != 0 || self.operator(b'?') != 0 {
            if self.flags.basic()
                && matches!(self.last, LastState::None | LastState::LineStart)
                && self.peek() != Some(b'\\')
            {
                let byte = self.take().unwrap();
                return self.literal(byte);
            }
            if self.position == 0 && !self.flags.basic() {
                return Err(self.error(ErrorKind::BadRepeat, "Nothing to repeat"));
            }
            self.position += self
                .operator(b'*')
                .max(self.operator(b'+'))
                .max(self.operator(b'?'));
            self.repeat_suffix();
            return Err(self.error(ErrorKind::BadRepeat, "Nothing to repeat"));
        }
        if self.operator(b'{') != 0 {
            let origin = self.position;
            let length = self.operator(b'{');
            if self.repeat_range()?.is_some() {
                self.repeat_suffix();
                return Err(self.error(ErrorKind::BadRepeat, "Nothing to repeat"));
            }
            self.position = origin + length;
            return self.literal(b'{');
        }
        let byte = self.take().unwrap();
        match byte {
            b'.' => self.add(Node::Dot(self.dot_mode())),
            b'^' => self.add(Node::Anchor(
                if !self.flags.basic() && self.flags.contains(CompileOptions::NO_MOD_M) {
                    Anchor::BufferStart
                } else {
                    Anchor::LineStart(true)
                },
            )),
            b'$' => self.add(Node::Anchor(
                if !self.flags.basic() && self.flags.contains(CompileOptions::NO_MOD_M) {
                    Anchor::BufferEnd
                } else {
                    Anchor::LineEnd(true)
                },
            )),
            b'}' if !self.flags.basic() && self.flags.contains(CompileOptions::NO_PERL_EX) => {
                Err(RegexError::new(
                    ErrorKind::Brace,
                    self.position - 1,
                    "Unmatched closing repeat brace",
                ))
            }
            b'\\' => self.escape(false),
            _ => self.literal(byte),
        }
    }
    fn literal(&mut self, byte: u8) -> Result<NodeId, RegexError> {
        self.add(Node::Byte(byte, self.flags.contains(CompileOptions::ICASE)))
    }
    fn dot_mode(&self) -> Option<bool> {
        if self.flags.contains(CompileOptions::NO_MOD_S) {
            Some(false)
        } else if self.flags.contains(CompileOptions::MOD_S) {
            Some(true)
        } else {
            None
        }
    }

    fn quantifier(&mut self, child: NodeId) -> Result<NodeId, RegexError> {
        self.skip_ignored();
        if self.flags.basic()
            && matches!(
                self.program.nodes[child],
                Node::Anchor(Anchor::LineStart(_))
            )
            && matches!(self.peek(), Some(b'*' | b'+' | b'?'))
        {
            return Ok(child);
        }
        let (min, max) = if self.operator(b'*') != 0 {
            self.position += self.operator(b'*');
            (0, None)
        } else if self.operator(b'+') != 0 {
            self.position += self.operator(b'+');
            (1, None)
        } else if self.operator(b'?') != 0 {
            self.position += self.operator(b'?');
            (0, Some(1))
        } else if self.operator(b'{') != 0 {
            let Some(range) = self.repeat_range()? else {
                return Ok(child);
            };
            range
        } else {
            return Ok(child);
        };
        let (kind, possessive) = self.repeat_suffix();
        if matches!(
            self.program.nodes[child],
            Node::Anchor(_) | Node::ResetStart | Node::Repeat { .. } | Node::Empty
        ) {
            return Err(self.error(ErrorKind::BadRepeat, "Expression cannot be repeated"));
        }
        let repeat = self.add(Node::Repeat {
            child,
            min,
            max,
            kind,
        })?;
        if possessive {
            self.add(Node::Atomic(repeat))
        } else {
            Ok(repeat)
        }
    }

    fn repeat_suffix(&mut self) -> (RepeatKind, bool) {
        let mut kind = RepeatKind::Greedy;
        let mut possessive = false;
        if self.flags.extensions() {
            if self.flags.perl() && self.flags.contains(CompileOptions::MOD_X) {
                self.skip_space();
            }
            if self.peek() == Some(b'?') {
                self.position += 1;
                kind = RepeatKind::Lazy;
            }
            if self.flags.grammar() == Grammar::Extended && self.peek() == Some(b'+') {
                self.position += 1;
                possessive = true;
            }
        }
        (kind, possessive)
    }

    fn skip_space(&mut self) {
        while self.peek().is_some_and(is_space) {
            self.position += 1;
        }
    }

    fn repeat_range(&mut self) -> Result<Option<(usize, Option<usize>)>, RegexError> {
        let origin = self.position;
        self.position += self.operator(b'{');
        self.skip_space();
        let min = self.range_number();
        let Some(min) = min else {
            return self.range_incomplete(origin);
        };
        self.skip_space();
        if self.peek().is_none() {
            return self.range_incomplete(origin);
        }
        let max = if self.peek() == Some(b',') {
            self.position += 1;
            self.skip_space();
            if self.peek().is_none() {
                return self.range_incomplete(origin);
            }
            self.range_number()
                .filter(|number| *number < i64::MAX as usize)
        } else {
            Some(min)
        };
        self.skip_space();
        if self.peek().is_none() {
            return self.range_incomplete(origin);
        }
        if self.flags.basic() {
            if self.take() != Some(b'\\') {
                self.position -= 1;
                return Err(self.error(ErrorKind::Brace, "Missing escaped closing repeat brace"));
            }
            if self.peek().is_none() {
                return Err(self.error(ErrorKind::Brace, "Missing closing repeat brace"));
            }
        }
        if self.peek() != Some(b'}') {
            self.position = origin;
            return Ok(None);
        }
        self.position += 1;
        if max.is_some_and(|max| min > max) {
            let mut position = self.position - 2;
            while position != 0 && is_word(self.bytes()[position]) {
                position -= 1;
            }
            return Err(RegexError::new(
                ErrorKind::BadBrace,
                position + 1,
                "Invalid repeat range",
            ));
        }
        Ok(Some((min, max)))
    }

    fn range_number(&mut self) -> Option<usize> {
        self.number(10, None)
            .filter(|number| *number >= 0)
            .and_then(|number| usize::try_from(number).ok())
    }

    fn range_incomplete(
        &mut self,
        origin: usize,
    ) -> Result<Option<(usize, Option<usize>)>, RegexError> {
        if !self.flags.perl() {
            return Err(self.error(ErrorKind::Brace, "Incomplete quantified repetition"));
        }
        self.position = origin;
        Ok(None)
    }

    fn close_group(&mut self) -> Result<(), RegexError> {
        let length = self.operator(b')');
        if length == 0 {
            return Err(self.error(ErrorKind::Parenthesis, "Unmatched opening parenthesis"));
        }
        self.position += length;
        Ok(())
    }

    fn group(&mut self) -> Result<NodeId, RegexError> {
        if self.depth >= self.limits.nesting {
            return Err(RegexError::limit(Resource::Nesting, self.position));
        }
        self.depth += 1;
        let saved = self.flags;
        let node = self.group_body()?;
        if !std::mem::take(&mut self.preserve_flags) {
            self.flags = saved;
        }
        self.depth -= 1;
        Ok(node)
    }

    fn group_body(&mut self) -> Result<NodeId, RegexError> {
        if self.flags.extensions() && self.peek() == Some(b'*') {
            self.position += 1;
            return self.verb();
        }
        if !self.flags.extensions() || self.peek() != Some(b'?') {
            return self.capture(None);
        }
        self.position += 1;
        match self.take().ok_or_else(|| {
            self.extension_error(ErrorKind::PerlExtension, "Incomplete Perl extension")
        })? {
            b':' => {
                let child = self.alternative(true, false)?;
                self.close_group()?;
                self.add(Node::Group(child))
            }
            b'|' => {
                let child = self.alternative(true, true)?;
                self.close_group()?;
                self.add(Node::Group(child))
            }
            b'=' => self.look(false, false),
            b'!' => self.look(true, false),
            b'>' => {
                let child = self.alternative(true, false)?;
                self.close_group()?;
                if matches!(self.program.nodes[child], Node::Empty) {
                    return Err(self.extension_error(
                        ErrorKind::PerlExtension,
                        "Empty independent expression",
                    ));
                }
                self.add(Node::Atomic(child))
            }
            b'<' => match self.peek() {
                Some(b'=') => {
                    self.position += 1;
                    self.look(false, true)
                }
                Some(b'!') => {
                    self.position += 1;
                    self.look(true, true)
                }
                _ => {
                    let name = self.name_until(b'>')?;
                    self.capture(Some(name))
                }
            },
            b'\'' => {
                let name = self.name_until(b'\'')?;
                self.capture(Some(name))
            }
            b'#' => {
                while self.peek().is_some_and(|byte| byte != b')') {
                    self.position += 1;
                }
                if self.peek().is_some() {
                    self.position += 1;
                }
                self.add(Node::Empty)
            }
            b'R' => self.recursive_group(GroupRef::Number(0)),
            b'&' => self.named_recursion(),
            b'P' if self.peek() == Some(b'>') => {
                self.position += 1;
                self.named_recursion()
            }
            b'(' => self.conditional(),
            b'0'..=b'9' | b'+' | b'-' => {
                self.position -= 1;
                self.numeric_recursion()
            }
            b'i' | b'm' | b's' | b'x' => {
                self.position -= 1;
                self.modifiers()
            }
            _ => Err(self.extension_error(ErrorKind::PerlExtension, "Invalid Perl extension")),
        }
    }

    fn capture(&mut self, name: Option<Vec<u8>>) -> Result<NodeId, RegexError> {
        if self.peek().is_none() {
            return Err(self.error(ErrorKind::Parenthesis, "Unmatched opening parenthesis"));
        }
        let group = if self.flags.contains(CompileOptions::NOSUBS) {
            0
        } else {
            self.group_count += 1;
            self.group_count
        };
        if self.program.groups.len() <= group {
            self.program.groups.resize(group + 1, None);
        }
        if let Some(name) = name {
            self.program.names.entry(name).or_default().push(group);
        }
        let child = self.alternative(true, false)?;
        self.close_group()?;
        let node = if group == 0 {
            self.add(Node::Group(child))?
        } else {
            self.add(Node::Capture { group, child })?
        };
        if group != 0 {
            self.program.groups[group].get_or_insert(node);
        }
        Ok(node)
    }

    fn look(&mut self, negative: bool, backwards: bool) -> Result<NodeId, RegexError> {
        let child = self.alternative(true, false)?;
        self.close_group()?;
        if !backwards && !negative && matches!(self.program.nodes[child], Node::Empty) {
            return Err(self.extension_error(ErrorKind::PerlExtension, "Empty positive assertion"));
        }
        // Width is finalized after parsing, as in basic_regex_creator. This
        // preserves the mark count of an invalid object returned by no_except.
        let behind = backwards.then_some(0);
        self.add(Node::Look {
            child,
            negative,
            behind,
        })
    }

    fn name_until(&mut self, closing: u8) -> Result<Vec<u8>, RegexError> {
        let start = self.position;
        while self.peek().is_some_and(|byte| byte != closing) {
            self.position += 1;
        }
        if self.peek().is_none() {
            return Err(
                self.extension_error(ErrorKind::PerlExtension, "Unterminated subexpression name")
            );
        }
        let name = self.bytes()[start..self.position].to_vec();
        self.position += 1;
        Ok(name)
    }

    fn named_recursion(&mut self) -> Result<NodeId, RegexError> {
        let start = self.position;
        while self.peek().is_some_and(|byte| byte != b')') {
            self.position += 1;
        }
        let name = self.bytes()[start..self.position].to_vec();
        self.recursive_group(GroupRef::Name(name))
    }

    fn recursive_group(&mut self, reference: GroupRef) -> Result<NodeId, RegexError> {
        if self.peek() != Some(b')') {
            return Err(self.extension_error(
                ErrorKind::PerlExtension,
                "Invalid or unterminated recursive subexpression",
            ));
        }
        let call = self.add(Node::Call(reference))?;
        // The Perl extension owns an ordinary unmarked group. Its closing
        // token is subsequently consumed by the active main grammar.
        let rest = self.alternative(true, false)?;
        self.close_group()?;
        let child = if matches!(self.program.nodes[rest], Node::Empty) {
            call
        } else {
            self.add(Node::Sequence(vec![call, rest]))?
        };
        self.add(Node::Group(child))
    }

    fn numeric_recursion(&mut self) -> Result<NodeId, RegexError> {
        let origin = self.position;
        let sign = self.peek().filter(|byte| matches!(byte, b'+' | b'-'));
        if sign.is_some() {
            self.position += 1;
        }
        let number = self.number(10, None);
        if sign == Some(b'-') && number.is_none_or(|number| number <= 0) {
            self.position = origin;
            return self.modifiers();
        }
        let number = number
            .filter(|number| *number >= if sign.is_some() { 1 } else { 0 })
            .ok_or_else(|| {
                self.extension_error(
                    ErrorKind::PerlExtension,
                    "Invalid recursive subexpression number",
                )
            })? as usize;
        let index = match sign {
            Some(b'-') => (self.group_count + 1)
                .checked_sub(number)
                .filter(|index| *index != 0),
            Some(b'+') => self
                .group_count
                .checked_add(number)
                .filter(|index| *index <= i64::MAX as usize),
            _ => Some(number),
        }
        .ok_or_else(|| {
            self.extension_error(
                ErrorKind::PerlExtension,
                "Invalid relative recursive subexpression",
            )
        })?;
        self.recursive_group(GroupRef::Number(index))
    }

    fn modifiers(&mut self) -> Result<NodeId, RegexError> {
        let mut enabled = true;
        while let Some(byte) = self.take() {
            let flag = match byte {
                b'-' if enabled => {
                    enabled = false;
                    continue;
                }
                b'i' => CompileOptions::ICASE,
                b'm' => CompileOptions::NO_MOD_M,
                b's' => CompileOptions::MOD_S,
                b'x' => CompileOptions::MOD_X,
                b':' => {
                    let child = self.alternative(true, false)?;
                    self.close_group()?;
                    return self.add(Node::Group(child));
                }
                b')' => {
                    self.preserve_flags = true;
                    let child = self.add(Node::Empty)?;
                    return self.add(Node::Group(child));
                }
                _ => {
                    return Err(
                        self.extension_error(ErrorKind::PerlExtension, "Invalid pattern modifier")
                    );
                }
            };
            let set = if byte == b'm' { !enabled } else { enabled };
            let bits = if set {
                self.flags.bits() | flag.bits()
            } else {
                self.flags.bits() & !flag.bits()
            };
            self.flags = CompileOptions::from_bits(bits);
            if byte == b's' {
                self.flags = CompileOptions::from_bits(if enabled {
                    self.flags.bits() & !CompileOptions::NO_MOD_S.bits()
                } else {
                    self.flags.bits() | CompileOptions::NO_MOD_S.bits()
                });
            }
        }
        Err(self.extension_error(ErrorKind::Parenthesis, "Unclosed pattern modifier"))
    }

    fn conditional(&mut self) -> Result<NodeId, RegexError> {
        let number = self.number(10, None);
        if self.peek().is_none() {
            return Err(self.extension_error(
                ErrorKind::PerlExtension,
                "Incomplete conditional expression",
            ));
        }
        let condition = if self.peek() == Some(b'R') {
            self.position += 1;
            let reference = if self.peek() == Some(b'&') {
                self.position += 1;
                let start = self.position;
                while self.peek().is_some_and(|byte| byte != b')') {
                    self.position += 1;
                }
                Some(GroupRef::Name(self.bytes()[start..self.position].to_vec()))
            } else {
                self.number(10, None)
                    .filter(|number| *number > 0)
                    .map(|number| GroupRef::Number(number as usize))
            };
            self.condition_end()?;
            Condition::Recursing(reference)
        } else if matches!(self.peek(), Some(b'<' | b'\'')) {
            self.position += 1;
            let start = self.position;
            while self
                .peek()
                .is_some_and(|byte| !matches!(byte, b'>' | b'\''))
            {
                self.position += 1;
            }
            let name = self.bytes()[start..self.position].to_vec();
            if self.take().is_none() {
                return Err(self.extension_error(
                    ErrorKind::PerlExtension,
                    "Unterminated conditional capture name",
                ));
            }
            self.condition_end()?;
            Condition::Matched(GroupRef::Name(name))
        } else if self.starts(b"DEFINE") {
            self.position += 6;
            self.condition_end()?;
            Condition::Define
        } else if let Some(number) = number.filter(|number| *number > 0) {
            self.condition_end()?;
            if number == 9999 {
                Condition::Define
            } else {
                Condition::Matched(GroupRef::Number(number as usize))
            }
        } else {
            if self.take() != Some(b'?') {
                return Err(
                    self.extension_error(ErrorKind::PerlExtension, "Invalid conditional test")
                );
            }
            let behind = self.peek() == Some(b'<');
            if behind {
                self.position += 1;
            }
            let negative = match self.take() {
                Some(b'=') => false,
                Some(b'!') => true,
                _ => {
                    return Err(self.extension_error(
                        ErrorKind::PerlExtension,
                        "Invalid conditional assertion",
                    ));
                }
            };
            let assertion = self.look(negative, behind)?;
            let repeated = self.quantifier(assertion)?;
            if repeated != assertion {
                return Err(self.extension_error(
                    ErrorKind::BadRepeat,
                    "A conditional assertion cannot be repeated",
                ));
            }
            let Node::Look { child, .. } = self.program.nodes[assertion] else {
                unreachable!()
            };
            Condition::Assert {
                child,
                negative,
                behind,
            }
        };
        let yes = self.sequence(true)?;
        let has_alternative = self.operator(b'|') != 0;
        let no = if has_alternative {
            self.position += self.operator(b'|');
            self.sequence(true)?
        } else {
            self.add(Node::Empty)?
        };
        if self.operator(b'|') != 0 {
            return Err(self.extension_error(
                ErrorKind::BadPattern,
                "More than one alternative in a conditional expression",
            ));
        }
        self.close_group()?;
        if has_alternative && matches!(condition, Condition::Define) {
            return Err(self.extension_error(
                ErrorKind::BadPattern,
                "Alternatives are not allowed in a DEFINE block",
            ));
        }
        self.add(Node::Conditional { condition, yes, no })
    }

    fn condition_end(&mut self) -> Result<(), RegexError> {
        if self.take() != Some(b')') || self.peek().is_none() {
            return Err(
                self.extension_error(ErrorKind::PerlExtension, "Unterminated conditional test")
            );
        }
        Ok(())
    }

    fn verb(&mut self) -> Result<NodeId, RegexError> {
        let name = self.name_until(b')')?;
        let verb = match name.as_slice() {
            b"FAIL" | b"F" => Verb::Fail,
            b"ACCEPT" => Verb::Accept,
            b"PRUNE" => Verb::Prune,
            b"SKIP" => Verb::Skip,
            b"COMMIT" => Verb::Commit,
            b"THEN" => Verb::Then,
            _ => {
                return Err(self.extension_error(
                    ErrorKind::PerlExtension,
                    "Unknown backtracking control verb",
                ));
            }
        };
        self.add(Node::Verb(verb))
    }

    fn escape(&mut self, in_set: bool) -> Result<NodeId, RegexError> {
        let origin = self.position - 1;
        let byte = self.take().ok_or_else(|| {
            self.error(
                if self.flags.basic() && !in_set {
                    ErrorKind::Parenthesis
                } else {
                    ErrorKind::Escape
                },
                "Trailing escape",
            )
        })?;
        if in_set {
            if b"dDsSwWlLuUhHV".contains(&byte) {
                return self.class_escape(byte);
            }
            return self.escaped_character(byte, origin);
        }
        if self.flags.basic() {
            return self.basic_escape(byte, origin);
        }
        let anchor = match byte {
            b'A' | 0x60 => Some(Anchor::BufferStart),
            b'z' | b'\'' => Some(Anchor::BufferEnd),
            b'Z' => Some(Anchor::SoftEnd),
            b'G' => Some(Anchor::Continue),
            b'b' => Some(Anchor::Word),
            b'B' => Some(Anchor::NotWord),
            b'<' => Some(Anchor::WordStart),
            b'>' => Some(Anchor::WordEnd),
            _ => None,
        };
        if let Some(anchor) = anchor {
            return self.add(Node::Anchor(anchor));
        }
        if b"dDsSwWlLuUhHV".contains(&byte) || (byte == b'v' && self.flags.perl()) {
            return self.class_escape(byte);
        }
        match byte {
            b'1'..=b'9' if !self.flags.contains(CompileOptions::NO_BK_REFS) => {
                self.add(Node::BackRef(
                    GroupRef::Number(usize::from(byte - b'0')),
                    self.flags.contains(CompileOptions::ICASE),
                ))
            }
            b'g' | b'k' if self.flags.perl() => self.extended_reference(),
            b'p' | b'P' => {
                if self.peek().is_none() {
                    return Err(self.error(ErrorKind::Escape, "Incomplete property escape"));
                }
                let name = if self.peek() == Some(b'{') {
                    self.position += 1;
                    let start = self.position;
                    while self.peek().is_some_and(|byte| byte != b'}') {
                        self.position += 1;
                    }
                    if self.peek().is_none() {
                        return Err(self.error(ErrorKind::Escape, "Unclosed property escape"));
                    }
                    let name = self.bytes()[start..self.position].to_vec();
                    self.position += 1;
                    name
                } else {
                    vec![self.take().unwrap()]
                };
                let mut set = ByteSet::named(&name).ok_or_else(|| {
                    self.error(ErrorKind::CharacterClass, "Unknown character property")
                })?;
                if self.flags.contains(CompileOptions::ICASE) {
                    set.fold();
                }
                if byte == b'P' {
                    set.negate();
                }
                self.add(Node::Set(set))
            }
            b'Q' => {
                self.quoted = true;
                self.skip_ignored();
                if self.peek().is_none() {
                    self.add(Node::Empty)
                } else {
                    self.atom()
                }
            }
            b'K' if self.flags.perl() => self.add(Node::ResetStart),
            b'C' => self.add(Node::Dot(self.dot_mode())),
            b'X' => self.add(Node::Combining),
            b'R' if self.flags.perl() => {
                let cr = self.literal(b'\r')?;
                let lf = self.literal(b'\n')?;
                let optional = self.add(Node::Repeat {
                    child: lf,
                    min: 0,
                    max: Some(1),
                    kind: RepeatKind::Greedy,
                })?;
                let pair = self.add(Node::Sequence(vec![cr, optional]))?;
                // get_escape_R_string<char> explicitly includes NEL, whereas
                // cpp_regex_traits<char>'s vertical class does not.
                let mut set = ByteSet::empty();
                for byte in [b'\n', 11, 12, 0x85] {
                    set.insert(byte);
                }
                let single = self.add(Node::Set(set))?;
                let alternatives = self.add(Node::Alternative(vec![pair, single]))?;
                let atomic = self.add(Node::Atomic(alternatives))?;
                self.add(Node::Group(atomic))
            }
            _ => self.escaped_character(byte, origin),
        }
    }

    fn class_escape(&mut self, byte: u8) -> Result<NodeId, RegexError> {
        let mut set = ByteSet::named(&[byte.to_ascii_lowercase()])
            .expect("classified escape has a built-in class");
        if self.flags.contains(CompileOptions::ICASE) {
            set.fold();
        }
        if byte.is_ascii_uppercase() {
            set.negate();
        }
        self.add(Node::Set(set))
    }

    fn basic_escape(&mut self, byte: u8, origin: usize) -> Result<NodeId, RegexError> {
        if byte == b'}' && !self.flags.contains(CompileOptions::NO_INTERVALS) {
            return Err(RegexError::new(
                ErrorKind::Brace,
                self.position - 1,
                "Unmatched closing repeat brace",
            ));
        }
        if byte.is_ascii_digit() {
            if byte == b'0' {
                return self.escaped_character(byte, origin);
            }
            return self.add(Node::BackRef(
                GroupRef::Number(usize::from(byte - b'0')),
                self.flags.contains(CompileOptions::ICASE),
            ));
        }
        if self.flags.emacs() {
            let anchor = match byte {
                b'A' | 0x60 => Some(Anchor::BufferStart),
                b'z' | b'\'' => Some(Anchor::BufferEnd),
                b'b' => Some(Anchor::Word),
                b'B' => Some(Anchor::NotWord),
                b'<' => Some(Anchor::WordStart),
                b'>' => Some(Anchor::WordEnd),
                _ => None,
            };
            if let Some(anchor) = anchor {
                return self.add(Node::Anchor(anchor));
            }
            match byte {
                b'w' | b'W' => return self.class_escape(byte),
                b's' | b'S' => return self.emacs_class(byte == b'S', origin),
                b'c' | b'C' => {
                    return Err(RegexError::new(
                        ErrorKind::Escape,
                        self.position - 1,
                        "Invalid Emacs escape",
                    ));
                }
                _ => {}
            }
        }
        self.literal(byte)
    }

    fn emacs_class(&mut self, negative: bool, origin: usize) -> Result<NodeId, RegexError> {
        let byte = self.take().ok_or_else(|| {
            RegexError::new(ErrorKind::Escape, origin, "Incomplete Emacs syntax class")
        })?;
        let mut set = match byte {
            b's' | b' ' => ByteSet::named(b"space").unwrap(),
            b'w' => ByteSet::named(b"word").unwrap(),
            b'.' => ByteSet::named(b"punct").unwrap(),
            _ => {
                let bytes: &[u8] = match byte {
                    b'_' => b"$&*+-_<>",
                    b'(' => b"([{",
                    b')' => b")]}",
                    b'"' => &[b'"', b'\'', 0x60],
                    b'\'' => b"',#",
                    b'<' => b";",
                    b'>' => b"\n\x0c",
                    _ => {
                        return Err(RegexError::new(
                            ErrorKind::CharacterClass,
                            self.position - 1,
                            "Unknown Emacs syntax class",
                        ));
                    }
                };
                let mut set = ByteSet::empty();
                for byte in bytes {
                    set.insert(*byte);
                }
                set
            }
        };
        if self.flags.contains(CompileOptions::ICASE) {
            set.fold();
        }
        if negative {
            set.negate();
        }
        self.add(Node::Set(set))
    }

    fn extended_reference(&mut self) -> Result<NodeId, RegexError> {
        if self.peek().is_none() {
            return Err(self.error(ErrorKind::Escape, "Incomplete extended backreference"));
        }
        let closing = match self.peek() {
            Some(b'{') => Some(b'}'),
            Some(b'<') => Some(b'>'),
            Some(b'\'') => Some(b'\''),
            _ => None,
        };
        if closing.is_some() {
            self.position += 1;
        }
        if self.peek().is_none() {
            return Err(self.error(ErrorKind::Escape, "Incomplete extended backreference"));
        }
        let negative = self.peek() == Some(b'-');
        if negative {
            self.position += 1;
        }
        if self.peek().is_none() {
            return Err(self.error(ErrorKind::Escape, "Incomplete extended backreference"));
        }
        let origin = self.position;
        let reference = if let Some(number) = self.number(10, None).filter(|number| *number >= 0) {
            let number = number as usize;
            let group = if negative {
                (self.group_count + 1).checked_sub(number)
            } else {
                Some(number)
            };
            let Some(group) = group.filter(|group| *group != 0) else {
                self.position = origin;
                return Err(self.error(ErrorKind::BackReference, "Invalid extended backreference"));
            };
            GroupRef::Number(group)
        } else if let Some(closing) = closing {
            self.position = origin;
            while self.peek().is_some_and(|byte| byte != closing) {
                self.position += 1;
            }
            let name = self.bytes()[origin..self.position].to_vec();
            if negative
                || self
                    .program
                    .names
                    .get(&name)
                    .is_none_or(|groups| groups.iter().all(|group| *group == 0))
            {
                return Err(self.error(ErrorKind::BackReference, "Unknown named backreference"));
            }
            GroupRef::Name(name)
        } else {
            self.position = origin;
            return Err(self.error(ErrorKind::BackReference, "Invalid extended backreference"));
        };
        if let Some(closing) = closing {
            if self.peek() != Some(closing) {
                return Err(self.error(ErrorKind::Escape, "Unclosed extended backreference"));
            }
            self.position += 1;
        }
        self.add(Node::BackRef(
            reference,
            self.flags.contains(CompileOptions::ICASE),
        ))
    }

    fn escaped_character(&mut self, byte: u8, origin: usize) -> Result<NodeId, RegexError> {
        let value = self.unescape_value(byte, origin)?;
        self.literal(value)
    }

    fn unescape_value(&mut self, byte: u8, origin: usize) -> Result<u8, RegexError> {
        let value = match byte {
            b'a' => 7,
            b'e' => 27,
            b'f' => 12,
            b'n' => b'\n',
            b'r' => b'\r',
            b't' => b'\t',
            b'v' => 11,
            b'b' => 8,
            b'c' => {
                self.take().ok_or_else(|| {
                    RegexError::new(ErrorKind::Escape, origin, "Incomplete control escape")
                })? % 32
            }
            b'x' => self.hex_escape(origin)?,
            b'0'..=b'9' => {
                if byte != b'0' {
                    return Err(RegexError::new(
                        ErrorKind::Escape,
                        origin,
                        "Octal escapes require an initial zero",
                    ));
                }
                self.position -= 1;
                let value = self.number(8, Some(4)).ok_or_else(|| {
                    RegexError::new(ErrorKind::Escape, origin, "Invalid octal escape")
                })?;
                if value < 0 || value > i64::from(std::ffi::c_char::MAX) {
                    return Err(RegexError::new(
                        ErrorKind::Escape,
                        origin,
                        "Octal escape is outside the native char range",
                    ));
                }
                value as u8
            }
            b'N' => {
                if self.take() != Some(b'{') {
                    return Err(RegexError::new(
                        ErrorKind::Escape,
                        origin,
                        "Missing collating-name brace",
                    ));
                }
                let start = self.position;
                while self.peek().is_some_and(|byte| byte != b'}') {
                    self.position += 1;
                }
                if self.peek().is_none() {
                    return Err(RegexError::new(
                        ErrorKind::Escape,
                        origin,
                        "Unclosed collating-name escape",
                    ));
                }
                let name = self.bytes()[start..self.position].to_vec();
                self.position += 1;
                let element = collating_element(&name).ok_or_else(|| {
                    RegexError::new(ErrorKind::Collate, origin, "Unknown collating element")
                })?;
                if element[1] != 0 {
                    return Err(RegexError::new(
                        ErrorKind::Escape,
                        origin,
                        "Named character is a collating digraph",
                    ));
                }
                element[0]
            }
            _ => byte,
        };
        Ok(value)
    }

    fn hex_escape(&mut self, origin: usize) -> Result<u8, RegexError> {
        if self.peek().is_none() {
            return Err(RegexError::new(
                ErrorKind::Escape,
                origin,
                "Incomplete hexadecimal escape",
            ));
        }
        let braces = self.peek() == Some(b'{');
        if braces {
            self.position += 1;
            if self.peek().is_none() {
                return Err(RegexError::new(
                    ErrorKind::Escape,
                    origin,
                    "Incomplete hexadecimal brace",
                ));
            }
        }
        let value = self.number(16, (!braces).then_some(2));
        let error = if braces {
            ErrorKind::BadBrace
        } else {
            ErrorKind::Escape
        };
        let maximum = if braces {
            i64::from(std::ffi::c_char::MAX)
        } else {
            255
        };
        let Some(value) = value.filter(|value| *value >= 0 && *value <= maximum) else {
            return Err(RegexError::new(
                error,
                origin,
                "Invalid byte hexadecimal escape",
            ));
        };
        if braces && self.take() != Some(b'}') {
            return Err(RegexError::new(error, origin, "Invalid hexadecimal brace"));
        }
        Ok(value as u8)
    }

    /// cpp_regex_traits::toi uses a classic-locale integer stream. Failure
    /// preserves the original cursor; whitespace and an optional sign belong
    /// to the conversion, and a comma terminates it.
    fn number(&mut self, radix: u32, length: Option<usize>) -> Option<i64> {
        let origin = self.position;
        let end = length.map_or(self.bytes().len(), |length| {
            origin.saturating_add(length).min(self.bytes().len())
        });
        let mut cursor = origin;
        while cursor < end && is_space(self.bytes()[cursor]) {
            cursor += 1;
        }
        let negative = self.bytes().get(cursor).is_some_and(|byte| *byte == b'-') && cursor < end;
        if cursor < end && matches!(self.bytes()[cursor], b'+' | b'-') {
            cursor += 1;
        }
        if radix == 16
            && cursor + 1 < end
            && self.bytes()[cursor] == b'0'
            && matches!(self.bytes()[cursor + 1], b'x' | b'X')
        {
            cursor += 2;
        }
        let digits = cursor;
        let mut value = 0u64;
        let limit = (i64::MAX as u64) + u64::from(negative);
        while cursor < end {
            let byte = self.bytes()[cursor];
            let Some(digit) = (byte as char).to_digit(radix) else {
                break;
            };
            value = value
                .checked_mul(u64::from(radix))?
                .checked_add(u64::from(digit))?;
            if value > limit {
                return None;
            }
            cursor += 1;
        }
        if cursor == digits {
            return None;
        }
        self.position = cursor;
        Some(if negative {
            (value as i64).wrapping_neg()
        } else {
            value as i64
        })
    }

    fn character_set(&mut self) -> Result<NodeId, RegexError> {
        let negative = self.peek() == Some(b'^');
        if negative {
            self.position += 1;
        }
        let item_base = self.position;
        let mut set = BracketSet::new(negative);
        loop {
            match self.peek() {
                None => return Err(self.error(ErrorKind::Bracket, "Unclosed character set")),
                Some(b']') if self.position != item_base => {
                    self.position += 1;
                    let encoding = set
                        .compile(
                            self.flags.contains(CompileOptions::ICASE),
                            self.flags.contains(CompileOptions::COLLATE),
                        )
                        .map_err(|()| {
                            self.error(ErrorKind::CharacterClass, "Invalid character-set range")
                        })?;
                    return self.add(match encoding {
                        SetEncoding::Bytes(set) => Node::Set(set),
                        SetEncoding::Collating(set) => Node::CollatingSet(set),
                    });
                }
                Some(b'[') => {
                    if self.bytes().get(self.position + 1).is_none() {
                        self.position += 1;
                        return Err(
                            self.error(ErrorKind::Bracket, "Incomplete inner character set")
                        );
                    }
                    if self.starts(b"[:")
                        && !(self.flags.basic()
                            && self.flags.contains(CompileOptions::NO_CHAR_CLASSES))
                    {
                        if let Some(anchor) = self.set_class(&mut set)? {
                            return self.add(Node::Anchor(anchor));
                        }
                    } else if self.starts(b"[=") {
                        let name = self.set_name(b'=', ErrorKind::Bracket)?;
                        let element =
                            collating_element(&self.bytes()[name.clone()]).ok_or_else(|| {
                                RegexError::new(
                                    ErrorKind::Collate,
                                    name.start,
                                    "Unknown equivalence element",
                                )
                            })?;
                        set.equivalent(element);
                    } else {
                        self.set_literal(&mut set)?;
                    }
                }
                Some(b'\\') => {
                    let shortcut = self.bytes().get(self.position + 1).copied().filter(|byte| {
                        matches!(
                            byte,
                            b'd' | b'D'
                                | b's'
                                | b'S'
                                | b'w'
                                | b'W'
                                | b'l'
                                | b'L'
                                | b'u'
                                | b'U'
                                | b'h'
                                | b'H'
                                | b'V'
                        )
                    });
                    if let Some(byte) = shortcut {
                        set.class(
                            ByteSet::named(&[byte.to_ascii_lowercase()]).unwrap(),
                            byte.is_ascii_uppercase(),
                        );
                        self.position += 2;
                    } else {
                        self.set_literal(&mut set)?;
                    }
                }
                _ => self.set_literal(&mut set)?,
            }
        }
    }

    fn set_name(
        &mut self,
        marker: u8,
        error: ErrorKind,
    ) -> Result<std::ops::Range<usize>, RegexError> {
        self.position += 2;
        let start = self.position;
        if self.take().is_none() {
            return Err(self.error(error, "Incomplete character-set name"));
        }
        while self.peek().is_some_and(|byte| byte != marker) {
            self.position += 1;
        }
        let end = self.position;
        if self.take() != Some(marker) || self.peek() != Some(b']') {
            let position = if marker == b'.' {
                start
            } else {
                self.position.min(self.bytes().len())
            };
            return Err(RegexError::new(
                error,
                position,
                "Unclosed character-set name",
            ));
        }
        self.position += 1;
        Ok(start..end)
    }

    fn set_class(&mut self, set: &mut BracketSet) -> Result<Option<Anchor>, RegexError> {
        let mut name = self.set_name(b':', ErrorKind::Bracket)?;
        let negative = self.bytes().get(name.start) == Some(&b'^');
        if negative {
            name.start += 1;
        }
        if let Some(class) = ByteSet::named(&self.bytes()[name.clone()]) {
            set.class(class, negative);
            return Ok(None);
        }
        if set.is_empty() && name.len() == 1 && self.peek() == Some(b']') {
            let anchor = match self.bytes()[name.start] {
                b'<' => Some(Anchor::WordStart),
                b'>' => Some(Anchor::WordEnd),
                _ => None,
            };
            if anchor.is_some() {
                self.position += 1;
                return Ok(anchor);
            }
        }
        Err(RegexError::new(
            ErrorKind::CharacterClass,
            name.start,
            "Unknown character class",
        ))
    }

    fn set_literal(&mut self, set: &mut BracketSet) -> Result<(), RegexError> {
        let lower = self.set_element(set)?;
        if self.peek().is_none() {
            return Err(self.error(ErrorKind::Bracket, "Unclosed character set"));
        }
        if self.peek() == Some(b'-') {
            self.position += 1;
            if self.peek().is_none() {
                return Err(self.error(ErrorKind::Bracket, "Unclosed character range"));
            }
            if self.peek() != Some(b']') {
                let upper = self.set_element(set)?;
                set.range(lower, upper);
                if self.peek() == Some(b'-') {
                    self.position += 1;
                    if self.peek().is_none() {
                        return Err(self.error(ErrorKind::Bracket, "Unclosed character range"));
                    }
                    if self.peek() != Some(b']') {
                        return Err(self.error(ErrorKind::Range, "Unexpected range separator"));
                    }
                    self.position -= 1;
                }
                return Ok(());
            }
            self.position -= 1;
        }
        set.single(lower);
        Ok(())
    }

    fn set_element(&mut self, set: &BracketSet) -> Result<Element, RegexError> {
        let origin = self.position;
        let byte = self
            .take()
            .ok_or_else(|| self.error(ErrorKind::Bracket, "Missing range endpoint"))?;
        match byte {
            b'-' if !set.is_empty() && self.peek() != Some(b']') => {
                Err(self.error(ErrorKind::Range, "Unexpected range separator"))
            }
            b'\\' if !self.flags.contains(CompileOptions::NO_ESCAPE_IN_LISTS) => {
                let byte = self.take().ok_or_else(|| {
                    self.error(ErrorKind::Escape, "Incomplete character-set escape")
                })?;
                self.unescape_value(byte, origin).map(|byte| [byte, 0])
            }
            b'[' if self.peek() == Some(b'.') => {
                self.position = origin;
                let name = self.set_name(b'.', ErrorKind::Collate)?;
                collating_element(&self.bytes()[name.clone()]).ok_or_else(|| {
                    RegexError::new(ErrorKind::Collate, name.start, "Unknown collating element")
                })
            }
            b'[' if self.peek().is_none() => {
                Err(self.error(ErrorKind::Collate, "Incomplete collating element"))
            }
            _ => Ok([byte, 0]),
        }
    }
}

fn is_space(byte: u8) -> bool {
    matches!(byte, b'\t'..=b'\r' | b' ')
}
fn is_word(byte: u8) -> bool {
    byte.is_ascii_alphanumeric() || byte == b'_'
}
