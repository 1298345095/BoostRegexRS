//! A pure Rust implementation of Boost.Regex matching over arbitrary bytes.
//!
//! Ranges and error positions use original byte offsets. A compiled expression
//! is immutable and shareable; every match owns its backtracking and captures.

mod charset;
mod compile;
mod execute;
mod format;
mod options;
mod registers;
mod start;
mod syntax;

use std::collections::BTreeMap;
use std::fmt;
use std::ops::Range;
use std::sync::Arc;

pub use options::{CompileOptions, MatchOptions};

/// Error categories retain the numeric Boost.Regex 1.89.0 `error_type` values.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[repr(u32)]
pub enum ErrorKind {
    BadPattern = 2,
    Collate = 3,
    CharacterClass = 4,
    Escape = 5,
    BackReference = 6,
    Bracket = 7,
    Parenthesis = 8,
    Brace = 9,
    BadBrace = 10,
    Range = 11,
    Space = 12,
    BadRepeat = 13,
    Size = 15,
    Empty = 17,
    Complexity = 18,
    Stack = 19,
    PerlExtension = 20,
    Unknown = 21,
    InvalidMatchOptions = 0x100,
    InvalidArgument = 0x101,
}

/// The independently configurable resource whose budget was exhausted.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Resource {
    CompileWork,
    MatchWork,
    BacktrackingMemory,
    Nesting,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RegexError {
    kind: ErrorKind,
    position: Option<usize>,
    message: &'static str,
    resource: Option<Resource>,
}

impl RegexError {
    pub fn kind(&self) -> ErrorKind {
        self.kind
    }
    /// A Boost regex_error code, absent for operation/precondition errors.
    pub fn code(&self) -> Option<u32> {
        match self.kind {
            ErrorKind::InvalidMatchOptions | ErrorKind::InvalidArgument => None,
            _ => Some(self.kind as u32),
        }
    }
    pub fn position(&self) -> Option<usize> {
        self.position
    }
    pub fn resource(&self) -> Option<Resource> {
        self.resource
    }

    pub(crate) fn new(kind: ErrorKind, position: usize, message: &'static str) -> Self {
        Self {
            kind,
            position: Some(position),
            message,
            resource: None,
        }
    }

    pub(crate) fn operation(kind: ErrorKind, message: &'static str) -> Self {
        Self {
            kind,
            position: None,
            message,
            resource: None,
        }
    }

    pub(crate) fn limit(resource: Resource, position: usize) -> Self {
        let kind = match resource {
            Resource::BacktrackingMemory => ErrorKind::Space,
            Resource::Nesting => ErrorKind::Stack,
            Resource::CompileWork | Resource::MatchWork => ErrorKind::Complexity,
        };
        Self {
            kind,
            position: Some(position),
            message: "Regular expression resource limit exceeded",
            resource: Some(resource),
        }
    }
}

impl fmt::Display for RegexError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(position) = self.position {
            write!(formatter, "{} at byte {}", self.message, position)
        } else {
            formatter.write_str(self.message)
        }
    }
}

impl std::error::Error for RegexError {}

/// Engine budgets, independent of Boost's implementation-specific limits.
///
/// These limits do not impose a result/output quota or a cumulative iteration
/// quota. Exhaustion is always an error, never a successful truncated result.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Limits {
    pub compile_work: usize,
    pub match_work: usize,
    pub backtracking_bytes: usize,
    pub nesting: usize,
}

impl Default for Limits {
    fn default() -> Self {
        Self {
            compile_work: 1_000_000,
            match_work: 10_000_000,
            backtracking_bytes: 64 * 1024 * 1024,
            nesting: 256,
        }
    }
}

/// Captures from one match. Group zero is the whole match, including `\K`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Captures {
    pub(crate) groups: Vec<Option<Range<usize>>>,
    pub(crate) histories: Vec<Vec<Range<usize>>>,
    pub(crate) partial: bool,
    pub(crate) input_len: usize,
    pub(crate) prefix_start: usize,
    pub(crate) range: Range<usize>,
    pub(crate) last_closed: Option<usize>,
}

impl Captures {
    pub fn groups(&self) -> &[Option<Range<usize>>] {
        &self.groups
    }
    pub fn group(&self, index: usize) -> Option<Range<usize>> {
        self.groups.get(index).cloned().flatten()
    }
    pub fn range(&self) -> Range<usize> {
        self.range.clone()
    }
    pub fn history(&self, index: usize) -> &[Range<usize>] {
        self.histories.get(index).map_or(&[], Vec::as_slice)
    }
    pub fn is_partial(&self) -> bool {
        self.partial
    }
    pub fn prefix(&self) -> Range<usize> {
        self.prefix_start..self.range().start
    }
    pub fn suffix(&self) -> Range<usize> {
        self.range().end..self.input_len
    }
    pub fn last_closed_group(&self) -> Option<usize> {
        self.last_closed
    }
}

/// An immutable compiled byte expression. `ByteRegex` is `Send + Sync`.
#[derive(Clone, Debug)]
pub struct ByteRegex {
    program: Arc<compile::Program>,
    limits: Limits,
}

impl ByteRegex {
    pub fn new(pattern: &[u8]) -> Result<Self, RegexError> {
        Self::with_options(pattern, CompileOptions::NORMAL)
    }
    pub fn with_options(pattern: &[u8], options: CompileOptions) -> Result<Self, RegexError> {
        Self::with_limits(pattern, options, Limits::default())
    }
    pub fn with_limits(
        pattern: &[u8],
        options: CompileOptions,
        limits: Limits,
    ) -> Result<Self, RegexError> {
        let parsed = syntax::parse(pattern, options, limits)?;
        Ok(Self {
            program: Arc::new(compile::compile(parsed, limits)?),
            limits,
        })
    }
    pub fn pattern(&self) -> &[u8] {
        &self.program.pattern
    }
    pub fn options(&self) -> CompileOptions {
        self.program.options
    }
    /// Zero for a valid expression; under `NO_EXCEPT`, the first compile error.
    pub fn status(&self) -> u32 {
        self.program
            .error
            .as_ref()
            .and_then(RegexError::code)
            .unwrap_or(0)
    }
    pub fn compile_error(&self) -> Option<&RegexError> {
        self.program.error.as_ref()
    }
    pub fn mark_count(&self) -> usize {
        self.program.mark_count
    }
    pub fn capture_names(&self) -> &BTreeMap<Vec<u8>, Vec<usize>> {
        &self.program.names
    }
    pub fn limits(&self) -> Limits {
        self.limits
    }
    pub fn search(&self, input: &[u8]) -> Result<Option<Captures>, RegexError> {
        self.search_with_options(input, MatchOptions::DEFAULT)
    }
    pub fn search_with_options(
        &self,
        input: &[u8],
        options: MatchOptions,
    ) -> Result<Option<Captures>, RegexError> {
        self.search_from(input, 0, options)
    }
    pub fn search_from(
        &self,
        input: &[u8],
        start: usize,
        options: MatchOptions,
    ) -> Result<Option<Captures>, RegexError> {
        self.search_with_limits(input, start, options, self.limits)
    }
    pub fn search_with_limits(
        &self,
        input: &[u8],
        start: usize,
        options: MatchOptions,
        limits: Limits,
    ) -> Result<Option<Captures>, RegexError> {
        execute::search(&self.program, input, start, options, limits, false)
    }
    pub fn full_match(&self, input: &[u8]) -> Result<Option<Captures>, RegexError> {
        self.full_match_with_options(input, MatchOptions::DEFAULT)
    }
    pub fn full_match_with_options(
        &self,
        input: &[u8],
        options: MatchOptions,
    ) -> Result<Option<Captures>, RegexError> {
        execute::search(&self.program, input, 0, options, self.limits, true)
    }

    pub fn find_iter<'r, 'i>(&'r self, input: &'i [u8]) -> Matches<'r, 'i> {
        self.find_iter_with_options(input, MatchOptions::DEFAULT)
    }
    pub fn find_iter_with_options<'r, 'i>(
        &'r self,
        input: &'i [u8],
        options: MatchOptions,
    ) -> Matches<'r, 'i> {
        Matches {
            regex: self,
            input,
            options,
            next_start: 0,
            previous_empty: false,
            started: false,
            done: false,
        }
    }
    pub fn format(
        &self,
        input: &[u8],
        captures: &Captures,
        replacement: &[u8],
        options: MatchOptions,
    ) -> Result<Vec<u8>, RegexError> {
        format::format(
            self.capture_names(),
            input,
            captures,
            replacement,
            options,
            self.limits,
        )
    }
    pub fn replace(&self, input: &[u8], replacement: &[u8]) -> Result<Vec<u8>, RegexError> {
        self.replace_with_options(input, replacement, MatchOptions::DEFAULT)
    }
    pub fn replace_with_options(
        &self,
        input: &[u8],
        replacement: &[u8],
        options: MatchOptions,
    ) -> Result<Vec<u8>, RegexError> {
        let mut result = Vec::new();
        let mut copied_until = 0;
        for captures in self.find_iter_with_options(input, options) {
            let captures = captures?;
            if !options.contains(MatchOptions::FORMAT_NO_COPY) {
                result.extend_from_slice(&input[copied_until..captures.range.start]);
            }
            result.extend_from_slice(&self.format(input, &captures, replacement, options)?);
            copied_until = captures.range.end;
            if options.contains(MatchOptions::FORMAT_FIRST_ONLY) {
                break;
            }
        }
        if !options.contains(MatchOptions::FORMAT_NO_COPY) {
            result.extend_from_slice(&input[copied_until..]);
        }
        Ok(result)
    }
}

/// Successive matches. A resource/error result is yielded once, then iteration ends.
pub struct Matches<'r, 'i> {
    regex: &'r ByteRegex,
    input: &'i [u8],
    options: MatchOptions,
    next_start: usize,
    previous_empty: bool,
    started: bool,
    done: bool,
}

impl Iterator for Matches<'_, '_> {
    type Item = Result<Captures, RegexError>;
    fn next(&mut self) -> Option<Self::Item> {
        if self.done {
            return None;
        }
        let mut options = self.options;
        if self.started && (self.previous_empty || options.contains(MatchOptions::POSIX)) {
            options |= MatchOptions::NOT_INITIAL_NULL;
        }
        match self.regex.search_from(self.input, self.next_start, options) {
            Ok(Some(captures)) => {
                self.next_start = captures.range.end;
                self.previous_empty = captures.is_partial() || captures.range.is_empty();
                self.started = true;
                Some(Ok(captures))
            }
            Ok(None) => {
                self.done = true;
                None
            }
            Err(error) => {
                self.done = true;
                Some(Err(error))
            }
        }
    }
}

impl std::iter::FusedIterator for Matches<'_, '_> {}
