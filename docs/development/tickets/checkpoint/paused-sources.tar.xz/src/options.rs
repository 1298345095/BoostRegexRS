//! Public option bits correspond to the fixed Boost.Regex 1.89.0 baseline.

macro_rules! flags {
    ($name:ident) => {
        #[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
        pub struct $name(u32);
        impl $name {
            pub const fn from_bits(bits: u32) -> Self {
                Self(bits)
            }
            pub const fn bits(self) -> u32 {
                self.0
            }
            pub const fn contains(self, other: Self) -> bool {
                self.0 & other.0 == other.0
            }
        }
        impl std::ops::BitOr for $name {
            type Output = Self;
            fn bitor(self, other: Self) -> Self {
                Self(self.0 | other.0)
            }
        }
        impl std::ops::BitOrAssign for $name {
            fn bitor_assign(&mut self, other: Self) {
                self.0 |= other.0;
            }
        }
        impl std::ops::BitAnd for $name {
            type Output = Self;
            fn bitand(self, other: Self) -> Self {
                Self(self.0 & other.0)
            }
        }
    };
}

flags!(CompileOptions);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum Grammar {
    Extended,
    Basic,
    Literal,
    Invalid,
}

impl CompileOptions {
    pub const NORMAL: Self = Self(0);
    pub const PERL: Self = Self(0);
    pub const LITERAL: Self = Self(2);
    pub const NO_BK_REFS: Self = Self(1 << 8);
    pub const NO_PERL_EX: Self = Self(1 << 9);
    pub const NO_MOD_M: Self = Self(1 << 10);
    pub const MOD_X: Self = Self(1 << 11);
    pub const MOD_S: Self = Self(1 << 12);
    pub const NO_MOD_S: Self = Self(1 << 13);
    pub const NO_CHAR_CLASSES: Self = Self(1 << 8);
    pub const NO_INTERVALS: Self = Self(1 << 9);
    pub const BK_PLUS_QM: Self = Self(1 << 10);
    pub const BK_VBAR: Self = Self(1 << 11);
    pub const EMACS_EX: Self = Self(1 << 12);
    pub const NO_ESCAPE_IN_LISTS: Self = Self(1 << 16);
    pub const NEWLINE_ALT: Self = Self(1 << 17);
    pub const NO_EXCEPT: Self = Self(1 << 18);
    pub const FAILBIT: Self = Self(1 << 19);
    pub const ICASE: Self = Self(1 << 20);
    pub const NOCOLLATE: Self = Self(0);
    pub const COLLATE: Self = Self(1 << 21);
    pub const NOSUBS: Self = Self(1 << 22);
    pub const SAVE_SUBEXPRESSION_LOCATION: Self = Self(1 << 23);
    pub const NO_EMPTY_EXPRESSIONS: Self = Self(1 << 24);
    pub const OPTIMIZE: Self = Self(0);
    pub const BASIC: Self = Self(1 | (1 << 21) | (1 << 16));
    pub const EXTENDED: Self = Self((1 << 8) | (1 << 9) | (1 << 21) | (1 << 16));
    pub const EMACS: Self = Self(1 | (1 << 21) | (1 << 12) | (1 << 11));
    pub const AWK: Self = Self((1 << 8) | (1 << 9) | (1 << 21));
    pub const GREP: Self = Self(Self::BASIC.0 | (1 << 17));
    pub const EGREP: Self = Self(Self::EXTENDED.0 | (1 << 17));
    pub const SED: Self = Self::BASIC;
    pub const ECMASCRIPT: Self = Self::PERL;
    pub const JAVASCRIPT: Self = Self::PERL;
    pub const JSCRIPT: Self = Self::PERL;
    pub(crate) fn grammar(self) -> Grammar {
        match self.0 & 3 {
            0 => Grammar::Extended,
            1 => Grammar::Basic,
            2 => Grammar::Literal,
            _ => Grammar::Invalid,
        }
    }
    pub(crate) fn basic(self) -> bool {
        self.grammar() == Grammar::Basic
    }
    pub(crate) fn literal(self) -> bool {
        self.grammar() == Grammar::Literal
    }
    pub(crate) fn perl(self) -> bool {
        self.grammar() == Grammar::Extended && !self.contains(Self::NO_PERL_EX)
    }
    pub(crate) fn emacs(self) -> bool {
        self.basic() && self.contains(Self::EMACS_EX)
    }
    pub(crate) fn extensions(self) -> bool {
        self.perl() || self.emacs()
    }
    pub(crate) fn perl_matching(self) -> bool {
        match self.0 & 3 {
            0 => !self.contains(Self::NO_PERL_EX),
            1 => self.contains(Self::EMACS_EX),
            2 => true,
            _ => false,
        }
    }
}

flags!(MatchOptions);
impl MatchOptions {
    pub const DEFAULT: Self = Self(0);
    pub const NOT_BOL: Self = Self(1);
    pub const NOT_EOL: Self = Self(1 << 1);
    pub const NOT_BOB: Self = Self(1 << 2);
    pub const NOT_EOB: Self = Self(1 << 3);
    pub const NOT_BOW: Self = Self(1 << 4);
    pub const NOT_EOW: Self = Self(1 << 5);
    pub const NOT_DOT_NEWLINE: Self = Self(1 << 6);
    pub const NOT_DOT_NULL: Self = Self(1 << 7);
    pub const PREV_AVAIL: Self = Self(1 << 8);
    pub const ANY: Self = Self(1 << 10);
    pub const NOT_NULL: Self = Self(1 << 11);
    pub const CONTINUOUS: Self = Self(1 << 12);
    pub const PARTIAL: Self = Self(1 << 13);
    pub const NOT_INITIAL_NULL: Self = Self(1 << 14);
    pub const ALL: Self = Self(1 << 15);
    pub const PERL: Self = Self(1 << 16);
    pub const POSIX: Self = Self(1 << 17);
    pub const NOSUBS: Self = Self(1 << 18);
    pub const EXTRA: Self = Self(1 << 19);
    pub const SINGLE_LINE: Self = Self(1 << 20);
    pub const FORMAT_SED: Self = Self(1 << 24);
    pub const FORMAT_ALL: Self = Self(1 << 25);
    pub const FORMAT_NO_COPY: Self = Self(1 << 26);
    pub const FORMAT_FIRST_ONLY: Self = Self(1 << 27);
    pub const FORMAT_LITERAL: Self = Self(1 << 29);
}
