//! Ordered matching and typed unwind, with per-invocation mutable state.
//!
//! Adapted from Boost.Regex 1.89.0 perl_matcher_common.hpp and
//! perl_matcher_non_recursive.hpp. Copyright (c) 2002 John Maddock.
//! Distributed under the Boost Software License, Version 1.0;
//! see LICENSE_1_0.txt and NOTICE.md.

use crate::compile::{Address, Instruction, Program, Scope, Test};
use crate::registers::{Register, Registers, history_bytes};
use crate::start::{Branches, Restart};
use crate::syntax::{Anchor, Verb};
use crate::{Captures, ErrorKind, Limits, MatchOptions, RegexError, Resource};
use std::mem::size_of;

#[derive(Clone, Copy, Debug)]
struct Counter {
    count: usize,
    previous: Option<usize>,
}

struct Call {
    group: usize,
    position: usize,
    return_to: Address,
    registers: Registers,
    counters: Vec<Option<Counter>>,
}

struct ReturnedCall {
    caller: Call,
    internal: Registers,
    counters: Vec<Option<Counter>>,
}

enum Frame {
    Choice {
        address: Address,
        position: usize,
        increment: Option<usize>,
    },
    SingleRepeat {
        repeat: Address,
        position: usize,
        count: usize,
        greedy: bool,
    },
    Capture {
        group: usize,
        previous: Register,
    },
    Counter {
        slot: usize,
        previous: Option<Counter>,
    },
    Scope {
        scope: Scope,
        return_to: Address,
        position: usize,
        independent: bool,
    },
    CallEntry,
    CallReturn(Box<ReturnedCall>),
    AppendHistories(Vec<Vec<Register>>),
    Commit,
    Then,
}

/// Tracks allocated vector capacities, including results saved by recursion.
struct Memory {
    used: usize,
    limit: usize,
}

impl Memory {
    fn charge(&mut self, bytes: usize, position: usize) -> Result<(), RegexError> {
        if bytes > self.limit.saturating_sub(self.used) {
            return Err(RegexError::limit(Resource::BacktrackingMemory, position));
        }
        self.used += bytes;
        Ok(())
    }
    fn release(&mut self, bytes: usize) {
        self.used -= bytes;
    }
    fn reserve<T>(
        &mut self,
        values: &mut Vec<T>,
        additional: usize,
        position: usize,
    ) -> Result<(), RegexError> {
        let required = values
            .len()
            .checked_add(additional)
            .ok_or_else(|| RegexError::limit(Resource::BacktrackingMemory, position))?;
        if required <= values.capacity() {
            return Ok(());
        }
        let capacity = required.max(values.capacity().saturating_mul(2));
        let bytes = (capacity - values.capacity())
            .checked_mul(size_of::<T>())
            .ok_or_else(|| RegexError::limit(Resource::BacktrackingMemory, position))?;
        self.charge(bytes, position)?;
        values
            .try_reserve_exact(capacity - values.len())
            .map_err(|_| RegexError::limit(Resource::BacktrackingMemory, position))?;
        Ok(())
    }
    fn vector<T: Clone>(
        &mut self,
        length: usize,
        value: T,
        position: usize,
    ) -> Result<Vec<T>, RegexError> {
        let mut result = Vec::new();
        self.reserve(&mut result, length, position)?;
        result.resize(length, value);
        Ok(result)
    }
    fn copy<T: Clone>(&mut self, values: &[T], position: usize) -> Result<Vec<T>, RegexError> {
        let mut result = Vec::new();
        self.reserve(&mut result, values.len(), position)?;
        result.extend_from_slice(values);
        Ok(result)
    }
    fn copy_registers(
        &mut self,
        values: &Registers,
        position: usize,
    ) -> Result<Registers, RegexError> {
        let groups = self.copy(&values.groups, position)?;
        let mut histories = self.vector(values.histories.len(), Vec::new(), position)?;
        for (target, source) in histories.iter_mut().zip(&values.histories) {
            *target = self.copy(source, position)?;
        }
        Ok(Registers {
            groups,
            histories,
            last_closed: values.last_closed,
        })
    }
}

struct Search<'a> {
    input: &'a [u8],
    begin: usize,
    options: MatchOptions,
    limits: Limits,
    work: usize,
    require_end: bool,
}

impl Search<'_> {
    fn step(&mut self, position: usize) -> Result<(), RegexError> {
        self.work += 1;
        if self.work > self.limits.match_work {
            return Err(RegexError::limit(Resource::MatchWork, position));
        }
        Ok(())
    }
}

struct Machine<'p, 's, 'i> {
    program: &'p Program,
    search: &'s mut Search<'i>,
    address: Address,
    position: usize,
    registers: Registers,
    counters: Vec<Option<Counter>>,
    frames: Vec<Frame>,
    calls: Vec<Call>,
    memory: Memory,
    independent: bool,
    scopes: usize,
    has_partial: bool,
    best: Option<Registers>,
    restart: Option<usize>,
    committed: bool,
}

enum Progress {
    Continue,
    Unwind(bool),
}

pub(crate) fn search(
    program: &Program,
    input: &[u8],
    begin: usize,
    mut options: MatchOptions,
    limits: Limits,
    full: bool,
) -> Result<Option<Captures>, RegexError> {
    if program.error.is_some() {
        return Err(RegexError::operation(
            ErrorKind::InvalidArgument,
            "Invalid regular expression object",
        ));
    }
    if begin > input.len() {
        return Err(RegexError::new(
            ErrorKind::Range,
            begin,
            "Search start is outside the input",
        ));
    }
    if options.contains(MatchOptions::PREV_AVAIL) && begin == 0 {
        return Err(RegexError::new(
            ErrorKind::Range,
            begin,
            "Previous input requested at the beginning of the buffer",
        ));
    }
    if !(options.contains(MatchOptions::PERL) || options.contains(MatchOptions::POSIX)) {
        options |= if program.options.perl_matching() {
            MatchOptions::PERL
        } else {
            MatchOptions::POSIX
        };
    }
    if program.disable_match_any {
        if options.contains(MatchOptions::POSIX) {
            return Err(RegexError::operation(
                ErrorKind::InvalidMatchOptions,
                "Invalid regex for POSIX-style matching",
            ));
        }
        options = MatchOptions::from_bits(options.bits() & !MatchOptions::ANY.bits());
    }
    if options.contains(MatchOptions::POSIX) && options.contains(MatchOptions::PERL) {
        return Err(RegexError::operation(
            ErrorKind::InvalidMatchOptions,
            "Cannot mix Perl and POSIX matching rules",
        ));
    }
    if options.contains(MatchOptions::POSIX) && options.contains(MatchOptions::EXTRA) {
        return Err(RegexError::operation(
            ErrorKind::InvalidMatchOptions,
            "Cannot mix capture histories and POSIX matching rules",
        ));
    }
    let mut search = Search {
        input,
        begin,
        options,
        limits,
        work: 0,
        require_end: full || options.contains(MatchOptions::ALL),
    };
    let mut start = begin;
    let mut machine = Machine::new(program, &mut search, start)?;
    loop {
        if !full && !options.contains(MatchOptions::CONTINUOUS) {
            match program.restart {
                Restart::Any => {
                    while start < input.len() && !program.start.bytes.contains(input[start]) {
                        machine.search.step(start)?;
                        start += 1;
                    }
                    if start == input.len() && !program.start.nullable {
                        break;
                    }
                }
                Restart::Buffer => {
                    if start != begin || options.contains(MatchOptions::NOT_BOB) {
                        break;
                    }
                }
                Restart::Continue => {
                    if start != begin {
                        break;
                    }
                }
                Restart::Line if start != begin => {
                    while start < input.len()
                        && (!is_separator(input[start - 1])
                            || !program.start.bytes.contains(input[start]))
                    {
                        machine.search.step(start)?;
                        start += 1;
                    }
                    if start == input.len()
                        && (!program.start.nullable
                            || start == 0
                            || !is_separator(input[start - 1]))
                    {
                        break;
                    }
                }
                Restart::Word if start != begin || options.contains(MatchOptions::PREV_AVAIL) => {
                    while start < input.len()
                        && (!is_word(input[start])
                            || (start != 0 && is_word(input[start - 1]))
                            || !program.start.bytes.contains(input[start]))
                    {
                        machine.search.step(start)?;
                        start += 1;
                    }
                    if start == input.len() {
                        break;
                    }
                }
                _ => {}
            }
        }
        machine.begin_attempt(start);
        machine.run()?;
        if let Some(result) = machine.best.take() {
            if full && result.groups[0].start != begin {
                return Ok(None);
            }
            return Ok(Some(result.into_captures(
                input.len(),
                begin,
                options.contains(MatchOptions::EXTRA),
            )));
        }
        if machine.has_partial && options.contains(MatchOptions::PARTIAL) {
            if full && machine.registers.groups[0].start != begin {
                return Ok(None);
            }
            machine.registers.groups[0].end = input.len();
            machine.registers.groups[0].matched = false;
            return Ok(Some(machine.registers.into_captures(
                input.len(),
                begin,
                options.contains(MatchOptions::EXTRA),
            )));
        }
        if full
            || options.contains(MatchOptions::CONTINUOUS)
            || machine.committed
            || start == input.len()
        {
            break;
        }
        start = machine.restart.unwrap_or(start + 1);
        if start > input.len() {
            break;
        }
    }
    Ok(None)
}

impl<'p, 's, 'i> Machine<'p, 's, 'i> {
    fn new(
        program: &'p Program,
        search: &'s mut Search<'i>,
        start: usize,
    ) -> Result<Self, RegexError> {
        let mut memory = Memory {
            used: 0,
            limit: search.limits.backtracking_bytes,
        };
        let count = if search.options.contains(MatchOptions::NOSUBS) {
            1
        } else {
            program.groups.len()
        };
        let mut groups = memory.vector(count, Register::unmatched(search.input.len()), start)?;
        groups[0].start = start;
        let histories = memory.vector(count, Vec::new(), start)?;
        let counters = memory.vector(program.repeat_count, None, start)?;
        Ok(Self {
            program,
            search,
            address: 0,
            position: start,
            registers: Registers {
                groups,
                histories,
                last_closed: None,
            },
            counters,
            frames: Vec::new(),
            calls: Vec::new(),
            memory,
            independent: false,
            scopes: 0,
            has_partial: false,
            best: None,
            restart: None,
            committed: false,
        })
    }

    fn begin_attempt(&mut self, start: usize) {
        // match_results::set_first resets registers between search attempts,
        // but capture histories produced by successful assertion unwinds stay.
        self.address = 0;
        self.position = start;
        for register in &mut self.registers.groups {
            *register = Register::unmatched(self.search.input.len());
        }
        self.registers.groups[0].start = start;
        self.counters.fill(None);
        self.has_partial = false;
        self.restart = None;
        self.committed = false;
    }

    fn push(&mut self, frame: Frame) -> Result<(), RegexError> {
        self.memory.reserve(&mut self.frames, 1, self.position)?;
        self.frames.push(frame);
        Ok(())
    }

    fn observe_partial(&mut self) {
        if self.search.options.contains(MatchOptions::PARTIAL)
            && self.position == self.search.input.len()
            && self.position != self.search.begin
        {
            self.has_partial = true;
        }
    }

    fn history(&mut self, group: usize, register: Register) -> Result<(), RegexError> {
        if register.matched && self.search.options.contains(MatchOptions::EXTRA) {
            let history = &mut self.registers.histories[group];
            self.memory.reserve(history, 1, self.position)?;
            history.push(register);
        }
        Ok(())
    }

    fn open(&mut self, group: usize) -> Result<(), RegexError> {
        if let Some(register) = self.registers.groups.get(group).copied() {
            self.push(Frame::Capture {
                group,
                previous: register,
            })?;
            self.registers.groups[group].start = self.position;
        }
        Ok(())
    }

    fn close(&mut self, group: usize) {
        if let Some(register) = self.registers.groups.get_mut(group) {
            register.end = self.position;
            register.matched = true;
            if group != 0 {
                self.registers.last_closed = Some(group);
            }
        }
    }

    fn run(&mut self) -> Result<(), RegexError> {
        loop {
            self.search.step(self.position)?;
            if let Progress::Unwind(success) = self.instruction()? {
                if !success {
                    self.observe_partial();
                }
                let resume = self.unwind(success)?;
                if !success {
                    self.observe_partial();
                }
                if !resume {
                    break;
                }
            }
        }
        Ok(())
    }

    fn instruction(&mut self) -> Result<Progress, RegexError> {
        let program = self.program;
        let instruction = &program.code[self.address];
        self.address += 1;
        let matched = match instruction {
            Instruction::Byte(byte, icase) => self.byte(*byte, *icase),
            Instruction::Literal(bytes, icase) => {
                for byte in bytes {
                    self.search.step(self.position)?;
                    if !self.byte(*byte, *icase) {
                        return Ok(Progress::Unwind(false));
                    }
                }
                true
            }
            Instruction::Set(set) => {
                let matched = self
                    .search
                    .input
                    .get(self.position)
                    .is_some_and(|byte| set.contains(*byte));
                self.position += usize::from(matched);
                matched
            }
            Instruction::CollatingSet(set) => {
                let consumed = set.consume(&self.search.input[self.position..]);
                self.position += consumed.unwrap_or(0);
                consumed.is_some()
            }
            Instruction::Dot(newline) => self.dot(*newline),
            Instruction::Anchor(anchor) => self.anchor(*anchor),
            Instruction::Jump(address) => {
                self.address = *address;
                true
            }
            Instruction::Alternative { second, prediction } => {
                let branches = self.program.branches[*prediction];
                let byte = self.search.input.get(self.position).copied();
                let take = branches.take.accepts(byte);
                let skip = branches.skip.accepts(byte);
                if take {
                    if skip {
                        self.push(Frame::Choice {
                            address: *second,
                            position: self.position,
                            increment: None,
                        })?;
                    }
                } else if skip {
                    self.address = *second;
                }
                take || skip
            }
            Instruction::Open { group, .. } => {
                self.open(*group)?;
                true
            }
            Instruction::Close(group) => {
                self.close(*group);
                if self.calls.last().is_some_and(|call| call.group == *group) {
                    self.return_call(false)?;
                }
                true
            }
            Instruction::Group { .. } | Instruction::GroupEnd | Instruction::ConditionalEnd => true,
            Instruction::RepeatStart { slot } => {
                if matches!(
                    program.code[self.address],
                    Instruction::Repeat { simple: true, .. }
                ) {
                    return Ok(Progress::Continue);
                }
                self.push(Frame::Counter {
                    slot: *slot,
                    previous: self.counters[*slot],
                })?;
                self.counters[*slot] = Some(Counter {
                    count: 0,
                    previous: None,
                });
                true
            }
            Instruction::Repeat { simple: true, .. } => self.single_repeat(self.address - 1)?,
            Instruction::Repeat {
                slot,
                min,
                max,
                greedy,
                exit,
                prediction,
                ..
            } => self.repeat(
                *slot,
                *min,
                *max,
                *greedy,
                *exit,
                self.program.branches[*prediction],
            )?,
            Instruction::BackRef { groups, icase } => {
                let register = groups
                    .iter()
                    .filter_map(|group| self.registers.groups.get(*group))
                    .find(|group| group.matched)
                    .or_else(|| {
                        groups
                            .last()
                            .and_then(|group| self.registers.groups.get(*group))
                    })
                    .copied()
                    .unwrap_or_else(|| Register::unmatched(self.search.input.len()));
                if !register.matched && self.search.options.contains(MatchOptions::PERL) {
                    return Ok(Progress::Unwind(false));
                }
                let mut source = register.start;
                while source != register.end {
                    self.search.step(self.position)?;
                    if self.position == self.search.input.len() {
                        return Ok(Progress::Unwind(false));
                    }
                    let byte = self.search.input.get(source).copied().ok_or_else(|| {
                        RegexError::operation(
                            ErrorKind::InvalidArgument,
                            "Backreference extends beyond the input",
                        )
                    })?;
                    if !self.byte(byte, *icase) {
                        return Ok(Progress::Unwind(false));
                    }
                    source += 1;
                }
                true
            }
            Instruction::ScopeStart { scope, end } => {
                if self.scopes + self.calls.len() >= self.search.limits.nesting {
                    return Err(RegexError::limit(Resource::Nesting, self.position));
                }
                let original = self.position;
                self.push(Frame::Scope {
                    scope: *scope,
                    return_to: end + 1,
                    position: original,
                    independent: self.independent,
                })?;
                self.scopes += 1;
                if matches!(scope, Scope::Atomic) {
                    self.independent = true;
                }
                true
            }
            Instruction::ScopeEnd => return Ok(Progress::Unwind(true)),
            Instruction::Backstep(length) => {
                let Some(position) = self.position.checked_sub(*length) else {
                    return Ok(Progress::Unwind(false));
                };
                self.position = position;
                true
            }
            Instruction::Call(group) => return self.call(*group),
            Instruction::Condition { test, no } => {
                let matched = match test {
                    Test::Matched(groups) => groups.iter().any(|group| {
                        self.registers
                            .groups
                            .get(*group)
                            .is_some_and(|capture| capture.matched)
                    }),
                    Test::Recursing(None) => !self.calls.is_empty(),
                    Test::Recursing(Some(groups)) => self
                        .calls
                        .last()
                        .is_some_and(|call| groups.contains(&call.group)),
                    Test::Define => false,
                };
                if !matched {
                    self.address = *no;
                }
                true
            }
            Instruction::ResetStart => {
                self.open(0)?;
                true
            }
            Instruction::Verb(Verb::Fail) => false,
            Instruction::Verb(Verb::Accept) => return self.accept(),
            Instruction::Verb(verb) => {
                match verb {
                    Verb::Commit => self.committed = true,
                    Verb::Skip if self.position != self.search.begin => {
                        self.restart = Some(self.position)
                    }
                    _ => {}
                }
                self.push(if matches!(verb, Verb::Then) {
                    Frame::Then
                } else {
                    Frame::Commit
                })?;
                true
            }
            Instruction::Match => return self.finish(),
        };
        Ok(if matched {
            Progress::Continue
        } else {
            Progress::Unwind(false)
        })
    }

    fn byte(&mut self, expected: u8, icase: bool) -> bool {
        let matched = self.search.input.get(self.position).is_some_and(|byte| {
            if icase {
                byte.eq_ignore_ascii_case(&expected)
            } else {
                *byte == expected
            }
        });
        self.position += usize::from(matched);
        matched
    }

    fn dot(&mut self, newline: Option<bool>) -> bool {
        let matched = self.search.input.get(self.position).is_some_and(|byte| {
            (!self.search.options.contains(MatchOptions::NOT_DOT_NULL) || *byte != 0)
                && (newline.unwrap_or(!self.search.options.contains(MatchOptions::NOT_DOT_NEWLINE))
                    || !is_separator(*byte))
        });
        self.position += usize::from(matched);
        matched
    }

    fn single_step(&mut self, address: Address) -> bool {
        match &self.program.code[address] {
            Instruction::Byte(byte, icase) => self.byte(*byte, *icase),
            Instruction::Set(set) => {
                let matched = self
                    .search
                    .input
                    .get(self.position)
                    .is_some_and(|byte| set.contains(*byte));
                self.position += usize::from(matched);
                matched
            }
            Instruction::Dot(newline) => self.dot(*newline),
            _ => unreachable!("single-state repeats only contain a byte, byte set, or dot"),
        }
    }

    fn single_repeat(&mut self, repeat: Address) -> Result<bool, RegexError> {
        let Instruction::Repeat {
            min,
            max,
            greedy,
            exit,
            prediction,
            leading,
            ..
        } = self.program.code[repeat]
        else {
            unreachable!()
        };
        let greedy =
            greedy && (!self.search.options.contains(MatchOptions::ANY) || self.independent);
        let desired = if greedy { max } else { min };
        let mut count = 0;
        while count < desired {
            self.search.step(self.position)?;
            if !self.single_step(repeat + 1) {
                break;
            }
            count += 1;
        }
        if count < min {
            return Ok(false);
        }
        if greedy && leading && count < max {
            self.restart = Some(self.position + 1);
        }
        if (greedy && count > min) || (!greedy && count < max) {
            self.push(Frame::SingleRepeat {
                repeat,
                position: self.position,
                count,
                greedy,
            })?;
        }
        self.address = exit;
        Ok(greedy
            || self.program.branches[prediction]
                .skip
                .accepts(self.search.input.get(self.position).copied()))
    }

    fn unwind_single_repeat(
        &mut self,
        repeat: Address,
        position: usize,
        mut count: usize,
        greedy: bool,
    ) -> Result<bool, RegexError> {
        let Instruction::Repeat {
            min,
            max,
            exit,
            prediction,
            leading,
            ..
        } = self.program.code[repeat]
        else {
            unreachable!()
        };
        let skip = self.program.branches[prediction].skip;
        if greedy {
            if self.search.options.contains(MatchOptions::PARTIAL)
                && self.position == self.search.input.len()
            {
                self.has_partial = true;
            }
            self.position = position;
            loop {
                self.position -= 1;
                count -= 1;
                self.search.step(self.position)?;
                if count == min || skip.bytes.contains(self.search.input[self.position]) {
                    break;
                }
            }
            if count > min {
                self.push(Frame::SingleRepeat {
                    repeat,
                    position: self.position,
                    count,
                    greedy,
                })?;
            }
            if !skip.bytes.contains(self.search.input[self.position]) {
                return Ok(false);
            }
        } else {
            self.position = position;
            if self.position != self.search.input.len() {
                loop {
                    self.search.step(self.position)?;
                    if !self.single_step(repeat + 1) {
                        return Ok(false);
                    }
                    count += 1;
                    if count == max
                        || self.position == self.search.input.len()
                        || skip.bytes.contains(self.search.input[self.position])
                    {
                        break;
                    }
                }
            }
            let slow_dot = matches!(self.program.code[repeat + 1], Instruction::Dot(newline)
                if self.search.options.contains(MatchOptions::NOT_DOT_NULL)
                    || !newline.unwrap_or(!self.search.options.contains(MatchOptions::NOT_DOT_NEWLINE)));
            if leading && !slow_dot && count < max {
                self.restart = Some(self.position + 1);
            }
            if self.position == self.search.input.len() {
                self.observe_partial();
                if !skip.nullable {
                    return Ok(false);
                }
            } else if count == max {
                if !skip.bytes.contains(self.search.input[self.position]) {
                    return Ok(false);
                }
            } else {
                self.push(Frame::SingleRepeat {
                    repeat,
                    position: self.position,
                    count,
                    greedy,
                })?;
            }
        }
        self.address = exit;
        Ok(true)
    }

    fn repeat(
        &mut self,
        slot: usize,
        min: usize,
        max: usize,
        greedy: bool,
        exit: Address,
        branches: Branches,
    ) -> Result<bool, RegexError> {
        let previous = self.counters[slot];
        let mut counter = previous.expect("repeat entry initializes its counter");
        self.push(Frame::Counter { slot, previous })?;
        // repeater_count::check_null_repeat saturates before checking the minimum.
        if counter.count != 0 && counter.previous == Some(self.position) {
            counter.count = max;
        } else {
            counter.previous = Some(self.position);
        }
        let byte = self.search.input.get(self.position).copied();
        let take = branches.take.accepts(byte);
        let skip = branches.skip.accepts(byte);
        let more = counter.count < max && take;
        let greedy =
            greedy && (!self.search.options.contains(MatchOptions::ANY) || self.independent);
        let matched = if counter.count < min {
            if take {
                counter.count += 1;
            }
            take
        } else if greedy && more {
            if skip {
                self.push(Frame::Choice {
                    address: exit,
                    position: self.position,
                    increment: None,
                })?;
            }
            counter.count += 1;
            true
        } else if skip {
            if more {
                self.push(Frame::Choice {
                    address: self.address,
                    position: self.position,
                    increment: Some(slot),
                })?;
            }
            self.address = exit;
            true
        } else if more {
            counter.count += 1;
            true
        } else {
            false
        };
        self.counters[slot] = Some(counter);
        Ok(matched)
    }

    fn call(&mut self, group: usize) -> Result<Progress, RegexError> {
        if self
            .calls
            .iter()
            .rev()
            .find(|call| call.group == group)
            .is_some_and(|call| call.position == self.position)
        {
            return Ok(Progress::Unwind(false));
        }
        if self.calls.len() + self.scopes >= self.search.limits.nesting {
            return Err(RegexError::limit(Resource::Nesting, self.position));
        }
        let registers = self.memory.copy_registers(&self.registers, self.position)?;
        let counters = self
            .memory
            .vector(self.program.repeat_count, None, self.position)?;
        let caller = Call {
            group,
            position: self.position,
            return_to: self.address,
            registers,
            counters: std::mem::replace(&mut self.counters, counters),
        };
        self.memory.reserve(&mut self.calls, 1, self.position)?;
        self.calls.push(caller);
        self.push(Frame::CallEntry)?;
        self.address =
            self.program.groups[group].expect("recursive targets are resolved during compilation");
        Ok(Progress::Continue)
    }

    fn return_call(&mut self, root: bool) -> Result<(), RegexError> {
        let caller = self
            .calls
            .pop()
            .expect("a recursive return has an active call");
        let restored = self
            .memory
            .copy_registers(&caller.registers, self.position)?;
        let internal = std::mem::replace(&mut self.registers, restored);
        // match_endmark saves its return record after restoring the caller;
        // match_match saves it before restoration for whole-pattern recursion.
        let internal = if root {
            internal
        } else {
            self.memory.release(internal.heap_bytes());
            self.memory.copy_registers(&self.registers, self.position)?
        };
        let restored_counters = self.memory.copy(&caller.counters, self.position)?;
        let counters = std::mem::replace(&mut self.counters, restored_counters);
        self.address = caller.return_to;
        self.memory
            .charge(size_of::<ReturnedCall>(), self.position)?;
        self.push(Frame::CallReturn(Box::new(ReturnedCall {
            caller,
            internal,
            counters,
        })))?;
        Ok(())
    }

    fn finish(&mut self) -> Result<Progress, RegexError> {
        if !self.calls.is_empty() {
            self.return_call(true)?;
            return Ok(Progress::Continue);
        }
        if (self.search.options.contains(MatchOptions::NOT_NULL)
            && self.position == self.registers.groups[0].start)
            || (self.search.require_end && self.position != self.search.input.len())
            || (self.search.options.contains(MatchOptions::NOT_INITIAL_NULL)
                && self.position == self.search.begin)
        {
            return Ok(Progress::Unwind(false));
        }
        self.close(0);
        if self.search.options.contains(MatchOptions::POSIX) {
            if self
                .best
                .as_ref()
                .is_none_or(|best| self.registers.better_than(best, self.search.input.len()))
            {
                if let Some(previous) = self.best.take() {
                    self.memory.release(previous.heap_bytes());
                }
                self.best = Some(self.memory.copy_registers(&self.registers, self.position)?);
            }
            if !self.search.options.contains(MatchOptions::ANY) {
                return Ok(Progress::Unwind(false));
            }
        }
        for group in 0..self.registers.groups.len() {
            self.history(group, self.registers.groups[group])?;
        }
        Ok(Progress::Unwind(true))
    }

    fn accept(&mut self) -> Result<Progress, RegexError> {
        let target = self.calls.last().map(|call| call.group);
        loop {
            self.search.step(self.position)?;
            match self.program.code[self.address] {
                Instruction::Open { group, end } => {
                    self.open(group)?;
                    self.address = end + 1;
                }
                Instruction::ScopeStart { end, .. } | Instruction::Group { end } => {
                    self.address = end + 1;
                }
                Instruction::Close(group) => {
                    self.close(group);
                    self.address += 1;
                    if target == Some(group) {
                        self.return_call(false)?;
                        return Ok(Progress::Continue);
                    }
                }
                Instruction::ScopeEnd => {
                    self.address += 1;
                    if !self.unwind(true)? {
                        return Ok(Progress::Unwind(true));
                    }
                }
                Instruction::Match => return self.finish(),
                _ => self.address += 1,
            }
        }
    }

    fn unwind(&mut self, mut success: bool) -> Result<bool, RegexError> {
        let mut cut = false;
        let mut skip_choice = false;
        while let Some(frame) = self.frames.pop() {
            self.search.step(self.position)?;
            match frame {
                Frame::Capture { group, previous } => {
                    if success {
                        self.history(group, previous)?;
                    } else {
                        self.registers.groups[group] = previous;
                        if group != 0 {
                            self.registers.last_closed = Some(group);
                        }
                    }
                }
                Frame::Counter { slot, previous } => {
                    if !success {
                        self.counters[slot] = previous;
                    }
                }
                Frame::Choice {
                    address,
                    position,
                    increment,
                } => {
                    if !success {
                        self.address = address;
                        self.position = position;
                        if let Some(slot) = increment
                            && let Some(counter) = &mut self.counters[slot]
                        {
                            counter.count += 1;
                        }
                        if !cut && !std::mem::take(&mut skip_choice) {
                            return Ok(true);
                        }
                    }
                }
                Frame::SingleRepeat {
                    repeat,
                    position,
                    count,
                    greedy,
                } => {
                    if !success
                        && self.unwind_single_repeat(repeat, position, count, greedy)?
                        && !cut
                        && !skip_choice
                    {
                        return Ok(true);
                    }
                }
                Frame::Scope {
                    scope,
                    return_to,
                    position,
                    independent,
                } => {
                    self.scopes -= 1;
                    self.independent = independent;
                    match scope {
                        Scope::Assertion { negative, .. } => {
                            self.position = position;
                            success = success != negative;
                            if success {
                                self.address = return_to;
                                if cut {
                                    self.push(Frame::Commit)?;
                                }
                                return Ok(true);
                            }
                        }
                        Scope::Condition {
                            negative, yes, no, ..
                        } => {
                            self.position = position;
                            self.address = if success != negative { yes } else { no };
                            return Ok(true);
                        }
                        Scope::Atomic if success => {
                            if self.search.options.contains(MatchOptions::EXTRA) {
                                let empty = self.memory.vector(
                                    self.registers.histories.len(),
                                    Vec::new(),
                                    self.position,
                                )?;
                                let histories =
                                    std::mem::replace(&mut self.registers.histories, empty);
                                self.push(Frame::AppendHistories(histories))?;
                            }
                            self.address = return_to;
                            return Ok(true);
                        }
                        Scope::Atomic => {}
                    }
                }
                Frame::CallEntry => {
                    if !success && let Some(caller) = self.calls.pop() {
                        self.memory.release(self.registers.heap_bytes());
                        self.memory
                            .release(self.counters.capacity() * size_of::<Option<Counter>>());
                        self.registers = caller.registers;
                        self.counters = caller.counters;
                        self.position = caller.position;
                    }
                }
                Frame::CallReturn(returned) => {
                    self.memory.release(size_of::<ReturnedCall>());
                    let ReturnedCall {
                        mut caller,
                        internal,
                        counters,
                    } = *returned;
                    if !success {
                        self.memory.release(self.registers.heap_bytes());
                        self.memory
                            .release(self.counters.capacity() * size_of::<Option<Counter>>());
                        self.registers = internal;
                        self.counters = counters;
                        caller.position = self.position;
                        self.memory.reserve(&mut self.calls, 1, self.position)?;
                        self.calls.push(caller);
                    } else {
                        self.memory
                            .release(caller.registers.heap_bytes() + internal.heap_bytes());
                        self.memory.release(
                            (caller.counters.capacity() + counters.capacity())
                                * size_of::<Option<Counter>>(),
                        );
                    }
                }
                Frame::AppendHistories(histories) => {
                    for (target, source) in self.registers.histories.iter_mut().zip(&histories) {
                        self.memory.reserve(target, source.len(), self.position)?;
                        target.extend_from_slice(source);
                    }
                    self.memory.release(history_bytes(&histories));
                }
                Frame::Commit => {
                    cut = true;
                }
                Frame::Then => {
                    if !success {
                        skip_choice = true;
                    }
                }
            }
        }
        if success && !self.search.options.contains(MatchOptions::POSIX) {
            self.best = Some(self.memory.copy_registers(&self.registers, self.position)?);
        }
        Ok(false)
    }

    fn anchor(&self, anchor: Anchor) -> bool {
        let position = self.position;
        let options = self.search.options;
        let at_begin = position == 0;
        let at_end = position == self.search.input.len();
        let previous = position
            .checked_sub(1)
            .and_then(|index| self.search.input.get(index))
            .copied();
        let next = self.search.input.get(position).copied();
        let previous_word = previous.is_some_and(is_word);
        let next_word = next.is_some_and(is_word);
        let word_start =
            !previous_word && next_word && !(at_begin && options.contains(MatchOptions::NOT_BOW));
        let word_end =
            previous_word && !next_word && !(at_end && options.contains(MatchOptions::NOT_EOW));
        match anchor {
            Anchor::BufferStart => at_begin && !options.contains(MatchOptions::NOT_BOB),
            Anchor::BufferEnd => at_end && !options.contains(MatchOptions::NOT_EOB),
            Anchor::Continue => position == self.search.begin,
            Anchor::LineStart(multiline) => {
                (at_begin
                    && !options.contains(MatchOptions::NOT_BOL)
                    && !options.contains(MatchOptions::PREV_AVAIL))
                    || (multiline
                        && !options.contains(MatchOptions::SINGLE_LINE)
                        && previous.is_some_and(is_separator)
                        && !(previous == Some(b'\r') && next == Some(b'\n')))
            }
            Anchor::LineEnd(multiline) => {
                (at_end && !options.contains(MatchOptions::NOT_EOL))
                    || (multiline
                        && !options.contains(MatchOptions::SINGLE_LINE)
                        && next.is_some_and(is_separator)
                        && !(previous == Some(b'\r') && next == Some(b'\n')))
            }
            Anchor::SoftEnd => {
                !options.contains(MatchOptions::NOT_EOB)
                    && self.search.input[position..]
                        .iter()
                        .all(|byte| is_separator(*byte))
            }
            Anchor::Word => word_start || word_end,
            Anchor::NotWord => !(word_start || word_end),
            Anchor::WordStart => word_start,
            Anchor::WordEnd => word_end,
        }
    }
}

fn is_word(byte: u8) -> bool {
    byte.is_ascii_alphanumeric() || byte == b'_'
}
// regex_traits_defaults.hpp specializes is_separator<char>; VT and NEL are
// vertical-space class members, but are not byte line separators.
fn is_separator(byte: u8) -> bool {
    matches!(byte, b'\n' | b'\r' | b'\x0c')
}
