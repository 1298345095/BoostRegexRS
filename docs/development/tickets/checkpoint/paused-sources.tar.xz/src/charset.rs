//! Classic-C byte traits and bracket-set compilation.
//!
//! Adapted from Boost.Regex 1.89.0 basic_regex_creator.hpp,
//! cpp_regex_traits.hpp, regex_traits_defaults.hpp and perl_matcher.hpp.
//! Copyright (c) 2002, 2004 John Maddock.
//! Copyright 2011 Garmin Ltd. or its subsidiaries.
//! Distributed under the Boost Software License, Version 1.0;
//! see LICENSE_1_0.txt and NOTICE.md.

use std::collections::BTreeSet;

#[derive(Clone, Copy, Debug)]
pub(crate) struct ByteSet([u64; 4]);

impl ByteSet {
    pub(crate) fn empty() -> Self {
        Self([0; 4])
    }
    pub(crate) fn contains(self, byte: u8) -> bool {
        self.0[usize::from(byte) / 64] & (1 << (byte % 64)) != 0
    }
    pub(crate) fn insert(&mut self, byte: u8) {
        self.0[usize::from(byte) / 64] |= 1 << (byte % 64);
    }
    pub(crate) fn union(&mut self, other: Self) {
        for (left, right) in self.0.iter_mut().zip(other.0) {
            *left |= right;
        }
    }
    pub(crate) fn negate(&mut self) {
        for part in &mut self.0 {
            *part = !*part;
        }
    }
    pub(crate) fn fold(&mut self) {
        for byte in b'A'..=b'Z' {
            if self.contains(byte) || self.contains(byte.to_ascii_lowercase()) {
                self.insert(byte);
                self.insert(byte.to_ascii_lowercase());
            }
        }
    }
    pub(crate) fn named(name: &[u8]) -> Option<Self> {
        let lowercase = name.to_ascii_lowercase();
        let mut set = Self::empty();
        for byte in 0u8..=255 {
            let yes = match lowercase.as_slice() {
                b"alnum" => byte.is_ascii_alphanumeric(),
                b"alpha" => byte.is_ascii_alphabetic(),
                b"blank" => matches!(byte, b' ' | b'\t' | 11),
                b"h" => matches!(byte, b' ' | b'\t'),
                b"cntrl" => byte.is_ascii_control(),
                b"digit" | b"d" => byte.is_ascii_digit(),
                b"graph" => byte.is_ascii_graphic(),
                b"lower" | b"l" => byte.is_ascii_lowercase(),
                b"print" => byte.is_ascii_graphic() || byte == b' ',
                b"punct" => byte.is_ascii_punctuation(),
                b"space" | b"s" => matches!(byte, b' ' | b'\t' | b'\n' | b'\r' | 11 | 12),
                b"upper" | b"u" => byte.is_ascii_uppercase(),
                b"word" | b"w" => byte.is_ascii_alphanumeric() || byte == b'_',
                b"xdigit" | b"x" => byte.is_ascii_hexdigit(),
                b"unicode" => false,
                b"v" => matches!(byte, b'\n' | b'\r' | 11 | 12),
                _ => return None,
            };
            if yes {
                set.insert(byte);
            }
        }
        Some(set)
    }
}

/// A collating element contains one byte, or two non-NUL bytes. The zero
/// second byte follows Boost's digraph representation, including NUL itself.
pub(crate) type Element = [u8; 2];

#[derive(Clone, Debug)]
pub(crate) struct CollatingSet {
    singles: Vec<Element>,
    members: ByteSet,
    negative: bool,
    icase: bool,
}

impl CollatingSet {
    /// Singles retain the ordering of their original spellings. Translation
    /// happens afterwards, so a two-byte element can precede a folded single.
    /// A failed element never advances the caller's position.
    pub(crate) fn consume(&self, input: &[u8]) -> Option<usize> {
        let first = translate(*input.first()?, self.icase);
        for element in &self.singles {
            if first == element[0]
                && (element[1] == 0
                    || input
                        .get(1)
                        .is_some_and(|byte| translate(*byte, self.icase) == element[1]))
            {
                return (!self.negative).then_some(if element[1] == 0 { 1 } else { 2 });
            }
        }
        (self.members.contains(first) != self.negative).then_some(1)
    }
}

pub(crate) enum SetEncoding {
    Bytes(ByteSet),
    Collating(CollatingSet),
}

pub(crate) struct BracketSet {
    singles: BTreeSet<Element>,
    ranges: Vec<(Element, Element)>,
    equivalents: BTreeSet<Element>,
    classes: ByteSet,
    negated_classes: Option<ByteSet>,
    negative: bool,
    empty: bool,
    digraphs: bool,
}

impl BracketSet {
    pub(crate) fn new(negative: bool) -> Self {
        Self {
            singles: BTreeSet::new(),
            ranges: Vec::new(),
            equivalents: BTreeSet::new(),
            classes: ByteSet::empty(),
            negated_classes: None,
            negative,
            empty: true,
            digraphs: false,
        }
    }
    pub(crate) fn is_empty(&self) -> bool {
        self.empty
    }
    pub(crate) fn single(&mut self, element: Element) {
        self.singles.insert(element);
        self.empty = false;
        self.digraphs |= element[1] != 0;
    }
    pub(crate) fn range(&mut self, lower: Element, upper: Element) {
        self.ranges.push((lower, upper));
        if lower[1] != 0 {
            self.single(lower);
        }
        if upper[1] != 0 {
            self.single(upper);
        }
        self.empty = false;
    }
    pub(crate) fn equivalent(&mut self, element: Element) {
        self.equivalents.insert(element);
        if element[1] != 0 {
            self.single(element);
        }
        self.empty = false;
    }
    pub(crate) fn class(&mut self, class: ByteSet, negative: bool) {
        if negative {
            self.negated_classes
                .get_or_insert(ByteSet::empty())
                .union(class);
        } else {
            self.classes.union(class);
        }
        self.empty = false;
    }
    pub(crate) fn compile(mut self, icase: bool, collate: bool) -> Result<SetEncoding, ()> {
        if icase {
            self.classes.fold();
            if let Some(classes) = &mut self.negated_classes {
                classes.fold();
            }
        }
        let mut members = self.classes;
        if let Some(mut classes) = self.negated_classes {
            // Boost combines negative class masks before complementing them.
            classes.negate();
            members.union(classes);
        }
        for element in &self.equivalents {
            if element[1] == 0 {
                let primary = element[0].to_ascii_lowercase();
                for byte in 0u8..=255 {
                    if byte.to_ascii_lowercase() == primary {
                        members.insert(byte);
                    }
                }
            }
        }
        for (lower, upper) in self.ranges {
            let lower = lower.map(|byte| translate(byte, icase));
            let upper = upper.map(|byte| translate(byte, icase));
            let lower = key(lower, collate);
            let upper = key(upper, collate);
            if lower > upper {
                return Err(());
            }
            for byte in 0u8..=255 {
                let value = key([byte, 0], collate);
                if lower <= value && value <= upper {
                    members.insert(byte);
                }
            }
        }
        if self.digraphs {
            let singles = self
                .singles
                .into_iter()
                .map(|element| element.map(|byte| translate(byte, icase)))
                .collect();
            Ok(SetEncoding::Collating(CollatingSet {
                singles,
                members,
                negative: self.negative,
                icase,
            }))
        } else {
            for single in self.singles {
                for byte in 0u8..=255 {
                    if translate(byte, icase) == translate(single[0], icase) {
                        members.insert(byte);
                    }
                }
            }
            if self.negative {
                members.negate();
            }
            // The matcher indexes the compiled map with the translated byte.
            let mut translated = ByteSet::empty();
            for byte in 0u8..=255 {
                if members.contains(translate(byte, icase)) {
                    translated.insert(byte);
                }
            }
            Ok(SetEncoding::Bytes(translated))
        }
    }
}

fn translate(byte: u8, icase: bool) -> u8 {
    if icase {
        byte.to_ascii_lowercase()
    } else {
        byte
    }
}

/// In the classic C locale, cpp_regex_traits::transform strips trailing NULs
/// then uses a monotone two-byte encoding. Comparing the unencoded non-NUL
/// bytes has the same ordering, including the empty key for NUL.
fn key(element: Element, collate: bool) -> Vec<u8> {
    if element[1] != 0 {
        element.to_vec()
    } else if element[0] == 0 && collate {
        Vec::new()
    } else {
        vec![element[0]]
    }
}

pub(crate) fn collating_element(name: &[u8]) -> Option<Element> {
    const NAMES: [&[u8]; 128] = [
        b"NUL",
        b"SOH",
        b"STX",
        b"ETX",
        b"EOT",
        b"ENQ",
        b"ACK",
        b"alert",
        b"backspace",
        b"tab",
        b"newline",
        b"vertical-tab",
        b"form-feed",
        b"carriage-return",
        b"SO",
        b"SI",
        b"DLE",
        b"DC1",
        b"DC2",
        b"DC3",
        b"DC4",
        b"NAK",
        b"SYN",
        b"ETB",
        b"CAN",
        b"EM",
        b"SUB",
        b"ESC",
        b"IS4",
        b"IS3",
        b"IS2",
        b"IS1",
        b"space",
        b"exclamation-mark",
        b"quotation-mark",
        b"number-sign",
        b"dollar-sign",
        b"percent-sign",
        b"ampersand",
        b"apostrophe",
        b"left-parenthesis",
        b"right-parenthesis",
        b"asterisk",
        b"plus-sign",
        b"comma",
        b"hyphen",
        b"period",
        b"slash",
        b"zero",
        b"one",
        b"two",
        b"three",
        b"four",
        b"five",
        b"six",
        b"seven",
        b"eight",
        b"nine",
        b"colon",
        b"semicolon",
        b"less-than-sign",
        b"equals-sign",
        b"greater-than-sign",
        b"question-mark",
        b"commercial-at",
        b"A",
        b"B",
        b"C",
        b"D",
        b"E",
        b"F",
        b"G",
        b"H",
        b"I",
        b"J",
        b"K",
        b"L",
        b"M",
        b"N",
        b"O",
        b"P",
        b"Q",
        b"R",
        b"S",
        b"T",
        b"U",
        b"V",
        b"W",
        b"X",
        b"Y",
        b"Z",
        b"left-square-bracket",
        b"backslash",
        b"right-square-bracket",
        b"circumflex",
        b"underscore",
        b"grave-accent",
        b"a",
        b"b",
        b"c",
        b"d",
        b"e",
        b"f",
        b"g",
        b"h",
        b"i",
        b"j",
        b"k",
        b"l",
        b"m",
        b"n",
        b"o",
        b"p",
        b"q",
        b"r",
        b"s",
        b"t",
        b"u",
        b"v",
        b"w",
        b"x",
        b"y",
        b"z",
        b"left-curly-bracket",
        b"vertical-line",
        b"right-curly-bracket",
        b"tilde",
        b"DEL",
    ];
    if let Some(index) = NAMES.iter().position(|candidate| *candidate == name) {
        return Some([index as u8, 0]);
    }
    if name.len() == 1 {
        return Some([name[0], 0]);
    }
    const MULTI: [&[u8]; 21] = [
        b"ae", b"Ae", b"AE", b"ch", b"Ch", b"CH", b"ll", b"Ll", b"LL", b"ss", b"Ss", b"SS", b"nj",
        b"Nj", b"NJ", b"dz", b"Dz", b"DZ", b"lj", b"Lj", b"LJ",
    ];
    MULTI.contains(&name).then(|| [name[0], name[1]])
}
