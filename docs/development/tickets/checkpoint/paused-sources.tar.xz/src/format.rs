//! Byte replacement formats: Perl, sed and Boost's conditional extensions.

use crate::{Captures, ErrorKind, Limits, MatchOptions, RegexError, Resource};
use std::collections::BTreeMap;
use std::ops::Range;

pub(crate) fn format(
    names: &BTreeMap<Vec<u8>, Vec<usize>>,
    input: &[u8],
    captures: &Captures,
    pattern: &[u8],
    options: MatchOptions,
    limits: Limits,
) -> Result<Vec<u8>, RegexError> {
    if captures.suffix().end > input.len() {
        return Err(RegexError::new(
            ErrorKind::Range,
            input.len(),
            "Capture ranges are outside the formatting input",
        ));
    }
    if options.contains(MatchOptions::FORMAT_LITERAL) {
        return Ok(pattern.to_vec());
    }
    let mut formatter = Formatter {
        names,
        input,
        captures,
        pattern,
        options,
        limits,
        position: 0,
        output: vec![],
        case: Case::None,
        next_case: Case::None,
    };
    formatter.sequence(true, false, 0)?;
    Ok(formatter.output)
}

#[derive(Clone, Copy)]
enum Case {
    None,
    Lower,
    Upper,
}

struct Formatter<'a> {
    names: &'a BTreeMap<Vec<u8>, Vec<usize>>,
    input: &'a [u8],
    captures: &'a Captures,
    pattern: &'a [u8],
    options: MatchOptions,
    limits: Limits,
    position: usize,
    output: Vec<u8>,
    case: Case,
    next_case: Case,
}

impl Formatter<'_> {
    fn peek(&self) -> Option<u8> {
        self.pattern.get(self.position).copied()
    }
    fn take(&mut self) -> Option<u8> {
        let result = self.peek();
        if result.is_some() {
            self.position += 1;
        }
        result
    }
    fn append(&mut self, byte: u8, active: bool) {
        if !active {
            return;
        }
        let mode = match self.next_case {
            Case::None => self.case,
            mode => mode,
        };
        self.output.push(match mode {
            Case::None => byte,
            Case::Lower => byte.to_ascii_lowercase(),
            Case::Upper => byte.to_ascii_uppercase(),
        });
        self.next_case = Case::None;
    }
    fn append_range(&mut self, range: Option<Range<usize>>, active: bool) {
        if let Some(range) = range {
            for index in range {
                self.append(self.input[index], active);
            }
        }
    }
    fn group(&self, name: &[u8]) -> Option<usize> {
        if !name.is_empty() && name.iter().all(u8::is_ascii_digit) {
            name.iter().try_fold(0usize, |value, byte| {
                value.checked_mul(10)?.checked_add(usize::from(byte - b'0'))
            })
        } else {
            self.names
                .get(name)?
                .iter()
                .find(|group| self.captures.group(**group).is_some())
                .copied()
        }
    }
    fn braced(&mut self) -> Option<Vec<u8>> {
        if self.peek() != Some(b'{') {
            return None;
        }
        let start = self.position + 1;
        let length = self.pattern[start..]
            .iter()
            .position(|byte| *byte == b'}')?;
        self.position = start + length + 1;
        Some(self.pattern[start..start + length].to_vec())
    }
    fn sequence(
        &mut self,
        active: bool,
        conditional: bool,
        depth: usize,
    ) -> Result<(), RegexError> {
        if depth >= self.limits.nesting {
            return Err(RegexError::limit(Resource::Nesting, self.position));
        }
        let extended = self.options.contains(MatchOptions::FORMAT_ALL);
        let sed = self.options.contains(MatchOptions::FORMAT_SED);
        while let Some(byte) = self.peek() {
            if extended && ((depth != 0 && byte == b')') || (conditional && byte == b':')) {
                return Ok(());
            }
            self.position += 1;
            match byte {
                b'(' if extended => {
                    self.sequence(active, false, depth + 1)?;
                    if self.peek() == Some(b')') {
                        self.position += 1;
                    }
                }
                b'?' if extended => {
                    let name = if self.peek() == Some(b'{') {
                        self.braced()
                    } else if self.peek().is_some_and(|byte| byte.is_ascii_digit()) {
                        Some(vec![self.take().unwrap()])
                    } else {
                        None
                    };
                    let Some(name) = name else {
                        self.append(b'?', active);
                        continue;
                    };
                    let matched = self
                        .group(&name)
                        .is_some_and(|group| self.captures.group(group).is_some());
                    self.sequence(active && matched, true, depth + 1)?;
                    if self.peek() == Some(b':') {
                        self.position += 1;
                        self.sequence(active && !matched, false, depth + 1)?;
                    }
                }
                b'$' if !sed => self.dollar(active),
                b'&' if sed => self.append_range(self.captures.group(0), active),
                b'\\' => self.escape(active, sed),
                _ => self.append(byte, active),
            }
        }
        Ok(())
    }

    fn dollar(&mut self, active: bool) {
        let start = self.position;
        let Some(byte) = self.take() else {
            self.append(b'$', active);
            return;
        };
        match byte {
            b'$' => self.append(b'$', active),
            b'&' => self.append_range(self.captures.group(0), active),
            b'`' => self.append_range(Some(self.captures.prefix()), active),
            b'\'' => self.append_range(Some(self.captures.suffix()), active),
            b'+' => {
                let range = if let Some(name) = self.braced() {
                    self.group(&name)
                        .and_then(|index| self.captures.group(index))
                } else {
                    self.captures
                        .group(self.captures.groups().len().saturating_sub(1))
                };
                self.append_range(range, active);
            }
            b'0'..=b'9' => {
                while self.peek().is_some_and(|byte| byte.is_ascii_digit()) {
                    self.position += 1;
                }
                let range = self
                    .group(&self.pattern[start..self.position])
                    .and_then(|index| self.captures.group(index));
                self.append_range(range, active);
            }
            b'{' => {
                self.position -= 1;
                let name = self.braced();
                if let Some(name) = name {
                    if self.special(&name, active) {
                        return;
                    }
                    if name.iter().all(u8::is_ascii_digit) {
                        self.append_range(
                            self.group(&name)
                                .and_then(|group| self.captures.group(group)),
                            active,
                        );
                        return;
                    }
                }
                self.position = start;
                self.append(b'$', active);
            }
            _ => {
                self.position = start;
                for name in [
                    b"LAST_SUBMATCH_RESULT".as_slice(),
                    b"LAST_PAREN_MATCH",
                    b"POSTMATCH",
                    b"PREMATCH",
                    b"MATCH",
                    b"^N",
                ] {
                    if self.pattern[start..].starts_with(name) {
                        self.position += name.len();
                        self.special(name, active);
                        return;
                    }
                }
                self.append(b'$', active);
            }
        }
    }
    fn special(&mut self, name: &[u8], active: bool) -> bool {
        let range = match name {
            b"MATCH" | b"^MATCH" => self.captures.group(0),
            b"PREMATCH" | b"^PREMATCH" => Some(self.captures.prefix()),
            b"POSTMATCH" | b"^POSTMATCH" => Some(self.captures.suffix()),
            b"LAST_PAREN_MATCH" => self
                .captures
                .group(self.captures.groups().len().saturating_sub(1)),
            b"LAST_SUBMATCH_RESULT" | b"^N" => self
                .captures
                .last_closed_group()
                .and_then(|index| self.captures.group(index)),
            _ => return false,
        };
        self.append_range(range, active);
        true
    }
    fn escape(&mut self, active: bool, sed: bool) {
        let Some(byte) = self.take() else {
            self.append(b'\\', active);
            return;
        };
        let literal = match byte {
            b'a' => 7,
            b'e' => 27,
            b'f' => 12,
            b'n' => 10,
            b'r' => 13,
            b't' => 9,
            b'v' => 11,
            b'1'..=b'9' => {
                self.append_range(self.captures.group(usize::from(byte - b'0')), active);
                return;
            }
            b'l' | b'u' | b'L' | b'U' | b'E' if !sed => {
                if active {
                    match byte {
                        b'l' => self.next_case = Case::Lower,
                        b'u' => self.next_case = Case::Upper,
                        b'L' => self.case = Case::Lower,
                        b'U' => self.case = Case::Upper,
                        _ => {
                            self.case = Case::None;
                            self.next_case = Case::None;
                        }
                    }
                }
                return;
            }
            b'c' => self.take().unwrap_or(b'c') % 32,
            b'x' => {
                let braced = self.peek() == Some(b'{');
                if braced {
                    self.position += 1;
                }
                let start = self.position;
                let mut value = 0u32;
                while self.peek().is_some_and(|byte| byte.is_ascii_hexdigit())
                    && (braced || self.position - start < 2)
                {
                    value = value
                        .wrapping_mul(16)
                        .wrapping_add((self.take().unwrap() as char).to_digit(16).unwrap());
                }
                if braced && self.peek() == Some(b'}') {
                    self.position += 1;
                }
                if self.position == start {
                    b'x'
                } else {
                    value as u8
                }
            }
            _ => byte,
        };
        self.append(literal, active);
    }
}
