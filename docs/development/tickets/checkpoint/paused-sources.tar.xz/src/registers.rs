//! Capture registers retain unmatched positions for backtracking and POSIX order.
//!
//! Adapted from Boost.Regex 1.89.0 match_results.hpp.
//! Copyright (c) 1998-2009 John Maddock. Distributed under the Boost Software
//! License, Version 1.0; see LICENSE_1_0.txt and NOTICE.md.

use crate::Captures;
use std::mem::size_of;
use std::ops::Range;

#[derive(Clone, Copy, Debug)]
pub(crate) struct Register {
    pub start: usize,
    pub end: usize,
    pub matched: bool,
}

impl Register {
    pub fn unmatched(end: usize) -> Self {
        Self {
            start: end,
            end,
            matched: false,
        }
    }
    pub fn range(self) -> Range<usize> {
        self.start..self.end
    }
}

#[derive(Clone, Debug)]
pub(crate) struct Registers {
    pub groups: Vec<Register>,
    pub histories: Vec<Vec<Register>>,
    pub last_closed: Option<usize>,
}

impl Registers {
    pub fn heap_bytes(&self) -> usize {
        self.groups.capacity() * size_of::<Register>() + history_bytes(&self.histories)
    }

    /// `match_results::maybe_assign`: start precedes length for every register.
    pub fn better_than(&self, previous: &Self, input_end: usize) -> bool {
        for (candidate, prior) in self.groups.iter().zip(&previous.groups) {
            if prior.start == input_end {
                if candidate.start != input_end {
                    return true;
                }
                if prior.matched != candidate.matched {
                    return candidate.matched;
                }
                continue;
            }
            if candidate.start == input_end {
                return false;
            }
            if candidate.start != prior.start {
                return candidate.start < prior.start;
            }
            let prior_length = prior.end.saturating_sub(prior.start);
            let candidate_length = candidate.end.saturating_sub(candidate.start);
            if prior_length != candidate_length || (!prior.matched && candidate.matched) {
                return candidate_length > prior_length || (!prior.matched && candidate.matched);
            }
            if prior.matched && !candidate.matched {
                return false;
            }
        }
        false
    }

    pub fn into_captures(self, input_len: usize, prefix_start: usize, extra: bool) -> Captures {
        let range = self.groups[0].range();
        let partial = !self.groups[0].matched;
        let groups = self
            .groups
            .into_iter()
            .map(|group| group.matched.then(|| group.range()))
            .collect();
        let histories = self
            .histories
            .into_iter()
            .map(|history| {
                if extra {
                    history.into_iter().rev().map(Register::range).collect()
                } else {
                    Vec::new()
                }
            })
            .collect();
        Captures {
            groups,
            histories,
            partial,
            input_len,
            prefix_start,
            range,
            last_closed: self.last_closed,
        }
    }
}

pub(crate) fn history_bytes(histories: &Vec<Vec<Register>>) -> usize {
    histories.capacity() * size_of::<Vec<Register>>()
        + histories
            .iter()
            .map(|history| history.capacity() * size_of::<Register>())
            .sum::<usize>()
}
