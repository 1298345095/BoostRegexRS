#!/usr/bin/env python3
"""Record a native ICU77 forward/backward/forward FCD cursor diagnostic."""

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shutil
import sys

from diagnose_locale import capture
from run import PRIMARY, REPO, command_log
from run_locales import identity, save

sys.path.insert(0, str(PRIMARY / "export"))
from generate import SOURCE_FILES, verify_source  # noqa: E402


def run(args):
    cache = args.cache.resolve()
    output = (args.output or REPO / "docs/research/assets/icu77-locales/diagnostics" /
              dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H%M%S.%fZ")).resolve()
    output.mkdir(parents=True, exist_ok=False)
    prefix = cache / "install/icu"
    environment = dict(os.environ)
    environment.pop("ICU_DATA", None)
    environment["LD_LIBRARY_PATH"] = str(prefix / "lib")
    source, source_files = verify_source(cache, SOURCE_FILES + ("source/i18n/ucol_imp.h", "source/i18n/ucol_res.cpp", "source/i18n/collationfcd.h"))
    executable = cache / "build/locale-trace/trace-fcd"
    executable.parent.mkdir(parents=True, exist_ok=True)
    command_log(["c++", "-std=c++17", "-O2", "-Wall", "-Wextra", "-Werror", "-DU_STATIC_IMPLEMENTATION",
                 "-I", prefix / "include", "-I", cache / "deps/icu/source/common", "-I", cache / "deps/icu/source/i18n",
                 PRIMARY / "export/trace-fcd.cpp", *[prefix / "lib" / name for name in ("libicui18n.a", "libicuuc.a", "libicudata.a")],
                 "-lpthread", "-ldl", "-lm", "-o", executable], output / "build.log", environment)
    inputs = output / "input-u16.tsv"
    shutil.copyfile(args.input_u16, inputs)
    process = capture([executable, args.locale], inputs, output / "native-fcd.tsv", environment)
    values = capture([executable, args.locale, "--fcd-values"], inputs, output / "native-fcd-values.tsv", environment)
    result = {"schema": "boostregexrs.icu77-fcd-cursor-diagnostic.v1", "locale": args.locale,
              "completed_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "process": process, "fcd_values_process": values,
              "scope": "Actual locale owner/FCD settings; one iterator traverses forward, backward, then forward without CE lookups",
              "identity": {"native": identity(executable), "original_input": identity(args.input_u16.resolve())},
              "source": source, "source_files": source_files,
              "generators": [identity(Path(__file__)), identity(PRIMARY / "export/trace-fcd.cpp")]}
    save(output / "summary.json", result)
    print(json.dumps({"output": str(output), "exit_code": process["exit_code"]}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--locale", required=True)
    parser.add_argument("--input-u16", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--cache", type=Path, default=REPO / "target/research/icu77-cloud")
    run(parser.parse_args())


if __name__ == "__main__":
    main()
