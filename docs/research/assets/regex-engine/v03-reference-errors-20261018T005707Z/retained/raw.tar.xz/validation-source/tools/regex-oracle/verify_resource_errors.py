#!/usr/bin/env python3
"""Verify the retained native resource-error counterexample before and after repair."""

import argparse
import json
from pathlib import Path

from protocol import read_cases, read_results
from resource_cases import cases, stack_cases
from source_identity import sha256


def verify(cases_path, before_path, after_path, *, stack_only=False):
    inputs = read_cases(cases_path)
    if inputs != list(stack_cases() if stack_only else cases()):
        raise ValueError("Resource regression inputs differ from the source-defined probes")
    before_rows, before_values = read_results(before_path, inputs)
    after_rows, after_values = read_results(after_path, inputs)
    phases = ({"match-stack-limit": ("match", 19, 0)} if stack_only else
              {"compile-nesting-limit": ("compile", 18, 400), "search-state-limit": ("search", 18, 0),
               "match-state-limit": ("match", 18, 0), "iterate-state-limit": ("iterate", 18, 0),
               "format-state-limit": ("search", 18, 0), "replace-state-limit": ("replace", 18, 0)})
    repaired = []
    unchanged = []
    for case, old, new, old_value, new_value in zip(inputs, before_rows, after_rows, before_values, after_values, strict=True):
        name = case[0]
        if name not in phases:
            if old[1] != new[1] or old_value != new_value:
                raise ValueError(f"Unrelated normal/no_except/error behavior changed: {name}")
            unchanged.append(name)
            continue
        phase, code, position = phases[name]
        if old[1] != "compile_error" or old_value != {"code": code, "position": position}:
            raise ValueError(f"Original source-defined counterexample was not reproduced: {name}")
        expected = {"schema": "boostregexrs.reference-failure.v1", "phase": phase,
                    "kind": "regex_resource", "code": code, "position": position}
        if (new[1] != "reference_failure" or
                any(new_value[key] != value for key, value in expected.items()) or not new_value["message_hex"]):
            raise ValueError(f"Native resource classification still wrong: {name}")
        repaired.append({"case_id": name, **expected})
    if len(repaired) != len(phases) or len(unchanged) != len(inputs) - len(phases):
        raise ValueError("Resource regression totals do not reconcile")
    return {"schema": "boostregexrs.native-resource-regression.v1", "status": "passed",
            "records": len(inputs), "repaired": repaired, "unchanged": unchanged,
            "execution_complexity_cases": 0 if stack_only else 5, "compile_complexity_cases": 0 if stack_only else 1,
            "execution_stack_cases": int(stack_only),
            "not_executed": ["allocator exhaustion", "catalog failure"] + ([] if stack_only else ["stack block exhaustion"]),
            "scope": "Native reference classification; not Rust resource-threshold equivalence",
            "files": {key: {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": sha256(path)}
                      for key, path in (("cases", cases_path), ("before", before_path), ("after", after_path))}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("cases", "before", "after", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--stack-only", action="store_true")
    args = parser.parse_args()
    result = verify(args.cases, args.before, args.after, stack_only=args.stack_only)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        raise ValueError("Do not overwrite retained native regression evidence")
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
