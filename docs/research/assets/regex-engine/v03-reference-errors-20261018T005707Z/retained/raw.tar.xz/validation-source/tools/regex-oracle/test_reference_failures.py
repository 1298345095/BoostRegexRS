"""Phase/code regressions for Boost's actual exception hierarchy."""

import copy
import csv
import json
from pathlib import Path
import tempfile
import unittest

from compare import compare
from protocol import HEADER, OUTPUT_HEADER, result_value


FAILURE = {"schema": "boostregexrs.reference-failure.v1", "phase": "search",
           "kind": "regex_resource", "code": 18, "position": 0, "message_hex": "426f6f7374"}


class ReferenceFailures(unittest.TestCase):
    def result(self, value, operation="search"):
        return result_value(("case", "reference_failure", json.dumps(value)), operation)

    def compare_failure(self, value, operation="search", reference_status="reference_failure"):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sources = [("cases.tsv", HEADER, [("case", operation, "0", "0", "61", "61", "")]),
                       ("reference.tsv", OUTPUT_HEADER, [("case", reference_status, json.dumps(value))]),
                       ("candidate.tsv", OUTPUT_HEADER, [("case", "candidate_resource_error", '{"code":18,"position":0}')])]
            for name, header, rows in sources:
                with (root / name).open("w", encoding="utf-8", newline="") as stream:
                    writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
                    writer.writerow(header)
                    writer.writerows(rows)
            return compare(root / "cases.tsv", root / "reference.tsv", root / "candidate.tsv")

    def test_compile_and_matcher_resources_never_pass_as_expected_rejections(self):
        for operation, phase, position in (("compile", "compile", 400), ("search", "search", 0),
                                           ("format", "search", 0), ("replace", "replace", 0)):
            with self.subTest(operation=operation):
                value = {**FAILURE, "phase": phase, "position": position}
                summary, differences = self.compare_failure(value, operation)
                self.assertEqual(summary["counts"], {"reference_resource_error": 1})
                self.assertEqual(differences[0]["reference"], value)
                self.assertEqual(summary["status"], "differences_or_unverified")

    def test_phase_code_position_and_message_survive_validation(self):
        for code in (12, 15, 18, 19):
            value = {**FAILURE, "code": code}
            with self.subTest(code=code):
                self.assertEqual(self.result(value), value)
        for kind in ("allocation", "capacity", "runtime"):
            value = {**FAILURE, "kind": kind, "code": None, "position": None}
            with self.subTest(kind=kind):
                self.assertEqual(self.result(value), value)
        value = {**FAILURE, "kind": "regex", "code": 21}
        self.assertEqual(self.result(value), value)

    def test_plain_runtime_error_is_not_automatically_resource_exhaustion(self):
        value = {**FAILURE, "kind": "runtime", "code": None, "position": None}
        summary, differences = self.compare_failure(value)
        self.assertEqual(summary["counts"], {"reference_error": 1})
        self.assertEqual(differences[0]["reference"], value)

    def test_incomplete_wrongly_typed_or_misclassified_failure_is_rejected(self):
        invalid = []
        for key in FAILURE:
            value = copy.deepcopy(FAILURE)
            del value[key]
            invalid.append(value)
        invalid.extend([{**FAILURE, "schema": "future"}, {**FAILURE, "phase": "replace"},
                        {**FAILURE, "kind": "unknown"}, {**FAILURE, "code": True},
                        {**FAILURE, "position": None}, {**FAILURE, "code": 8},
                        {**FAILURE, "kind": "regex"}, {**FAILURE, "message_hex": "odd"},
                        {**FAILURE, "kind": "runtime"}, {**FAILURE, "extra": 0}])
        for value in invalid:
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.result(value)

    def test_ordinary_compile_error_cannot_be_hidden_as_reference_failure(self):
        value = {**FAILURE, "phase": "compile", "kind": "regex", "code": 8, "position": 1}
        with self.assertRaisesRegex(ValueError, "compile_error"):
            self.result(value, "compile")

    def test_serialization_resource_failure_remains_an_oracle_failure(self):
        value = {**FAILURE, "phase": "serialize", "kind": "allocation", "code": None, "position": None}
        summary, _ = self.compare_failure(value)
        self.assertEqual(summary["counts"], {"reference_resource_error": 1})

    def test_no_except_resource_status_is_preserved_without_counting_as_pass(self):
        value = {"mark_count": 18446744073709551615, "compile_status": 18}
        summary, differences = self.compare_failure(value, "compile", "ok")
        self.assertEqual(summary["counts"], {"reference_resource_error": 1})
        self.assertEqual(differences[0]["reference"], value)

    def test_historical_resource_code_mislabeled_compile_error_cannot_pass(self):
        value = {"code": 18, "position": 0}
        summary, _ = self.compare_failure(value, "search", "compile_error")
        self.assertEqual(summary["counts"], {"reference_resource_error": 1})


if __name__ == "__main__":
    unittest.main()
