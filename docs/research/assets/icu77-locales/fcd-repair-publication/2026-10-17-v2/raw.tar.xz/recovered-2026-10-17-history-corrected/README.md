# Recovered U01 historical cursor prerequisite

This is a new recovery execution from 2026-10-17. Workspace maintenance removed
the original checkout, unpublished generated fixtures and executable caches.
The recovered checkpoint retained the six historical UTF-16 inputs, their native
cursor traces and the native FCD fast-flag bitmap. This directory does not claim
to restore the lost generation's bytes or execution logs.

## Verified here

- The six input rows preserve their archived UTF-16 order exactly. The two
  supplementary non-FCD reductions are `00e9,d834,dd65,0323` and
  `00e9,d834,dd65,0327`; the archived decomposed controls remain separate inputs.
- The restored Rust cursor passes all 120 archived forward/backward/forward
  trace rows, including original UTF-16 offsets and terminal positions.
- The Rust FCD fast flags match all 65,536 native UTF-16-unit flag bytes.
- All three checked reordering-data regressions pass. Missing required split
  ranges are rejected before sorting, range boundaries and table suffixes must
  agree, and legitimate unused zero table slots remain accepted.
- The five library unit tests pass with Rust stable 1.99.1. This is the working
  generic library, including settings support. A separately staged source
  prerequisite must be verified separately on its exact staged contents.

`cargo-test-lib.merged.log` is the actual exec tool's combined stdout/stderr,
concatenated from the original running process and completion responses. No
separate stdout/stderr streams were retained for that invocation. Its process
record gives the exact command, exit status and source/fixture identities.

The settings validation source was restored byte for byte to SHA-256
`2223f302370611345dbffa39dc8f1a5172e4b380f301aec32dbd1e446df99bfc`.
The runtime FCD cursor and contraction code came from the recovered checkpoint;
focused test code and the fixture harness were reconstructed independently.

## Reproduction

From the repository root, choose a fresh output directory:

```sh
timeout --signal=TERM --kill-after=5s 20s python3 -B tools/icu-probe/primary/rust/tests/refresh_fcd_fixtures.py --historical-only --update-fixtures --output docs/research/assets/icu77-locales/fcd-repair/<fresh-directory>
```

The extractor uses Python's standard library and the existing
`primary/export/data_format.py` and `primary/export/generate.py` modules. This
mode does not read a native installation or require a C++ compiler. Its five
archived input/trace/flag sources and their digests are in `provenance.json`.
The Rust tests require only the three extracted fixture files and fixed root
collation/NFD data; settings tests additionally use the checked-in script table
and three generated setting profiles.

The first recovery attempt, in `../recovered-2026-10-17-history/`, reconstructed
two NFD input orders incorrectly. An offline comparison found the problem before
Rust execution. Its `failure.json` records both values, and the failed directory
is retained. The generator now reads the original input files directly.

## Remaining validation

Full-key reference fixtures are not part of this historical prerequisite. The
reconstructed generation revision 2 retains the source-defined coverage classes
and seed `0x0042494355464344`: 381 supplementary boundary points, 128 Tibetan
fast-mask cases, 24 context combinations, 512 generated rows, and six historical
inputs plus empty/NUL/merge controls. These produce 1,436 rows, of which 1,409
have distinct UTF-16 input sequences. Static checks establish determinism, not
compatibility.

Fresh native reference generation and complete-key/CE comparison across root
and Faroese search with FCD OFF/ON are still required. The new generation will
have its own identity; no equality with the lost revision-1 generated rows is
claimed. Six-target, regex-engine and performance acceptance remain outside
this prerequisite's coverage.
