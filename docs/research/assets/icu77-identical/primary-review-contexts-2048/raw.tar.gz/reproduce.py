#!/usr/bin/env python3
"""Persist the exact 2048-case Spec-review diagnostic as a separate new run.

This replays the earlier in-memory experiment; it does not recover its old raw
files or add records to the main PRIMARY/CE acceptance counts. It deliberately
requires the original recorded executable identities, without rebuilding them.
"""

import argparse
import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys


ORIGINAL_COMMIT = "d1a507f1fd101a19b92e79134b1a4f4105ae8225"
SEED = 0x5350454352455631
COUNT = 2048
MARKS = (0x300, 0x301, 0x315, 0x323, 0x327, 0x345, 0x5B0, 0xF71, 0xF72, 0x3099)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(path):
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[5])
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    cache = repo / "target/research/icu77-cloud"
    primary = repo / "tools/icu-probe/primary"
    started = dt.datetime.now(dt.timezone.utc).isoformat()

    def original_json(name):
        return json.loads(subprocess.check_output(
            ["git", "show", ORIGINAL_COMMIT + ":docs/research/assets/icu77-cloud/primary/" + name],
            cwd=repo, text=True))

    original = original_json("summary.json")
    original_ce = original_json("ce-audit-final-contexts/summary.json")
    original_generation = original_json("data-generation-manifest.json")
    candidate = cache / "build/primary/release/icu77-root-primary"
    oracle = cache / "build/primary/oracle"
    reference_ce = cache / "build/primary-export/trace-root"
    data = primary / "data/root-icu77.bin"
    required = [
        (candidate, original["identity"]["candidate_sha256"]),
        (oracle, original["identity"]["oracle_sha256"]),
        (reference_ce, original_ce["reference_executable"]["sha256"]),
        (data, original["identity"]["data_sha256"]),
    ]
    sources = [primary / name for name in ("generate_cases.py", "compare.py", "export/data_format.py")]
    required += [(path, original["identity"]["source_sha256"][str(path.relative_to(repo))]) for path in sources]
    libraries = [cache / "install/icu" / item["path"] for item in original_generation["installed_libraries"]]
    required += [(path, item["sha256"]) for path, item in zip(libraries, original_generation["installed_libraries"])]
    for path, expected in required:
        if sha256(path) != expected:
            raise RuntimeError(f"Original recorded identity changed: {path}")

    sys.path.insert(0, str(primary))
    from compare import compare
    from generate_cases import Random, contexts

    context_source = cache / "build/root-contexts.json"
    shutil.copyfile(context_source, output / "contexts-source.json")
    base = [value for label, value in contexts(context_source) if label.startswith("context/")]
    rng = Random(SEED)
    marks = [chr(cp) for cp in MARKS]
    values = []
    # Keep this random-call order identical to the original in-memory review.
    for i in range(COUNT):
        value = rng.choose(base)
        if i % 2:
            at = rng.next() % (len(value) + 1)
            value = value[:at] + "".join(rng.choose(marks) for _ in range(1 + rng.next() % 5)) + value[at:]
        else:
            value = value + rng.choose(base) + rng.choose(marks) + rng.choose(base)
        values.append(value)
    payload = "case_id\tutf8_hex\n" + "".join(
        f"spec-{i}\t{value.encode('utf-8').hex()}\n" for i, value in enumerate(values))
    cases = output / "inputs-utf8.tsv"
    cases.write_text(payload, encoding="utf-8", newline="")
    u16 = "case_id\tu16_hex\n"
    for i, value in enumerate(values):
        units = value.encode("utf-16-le")
        u16 += f"spec-{i}\t" + ",".join(
            f"{int.from_bytes(units[j:j + 2], 'little'):04x}" for j in range(0, len(units), 2)) + "\n"
    (output / "inputs-u16.tsv").write_text(u16, encoding="utf-8", newline="")

    native = dict(os.environ)
    native.pop("ICU_DATA", None)
    native["LD_LIBRARY_PATH"] = str(cache / "install/icu/lib")
    rust = dict(os.environ)
    rust.pop("LD_LIBRARY_PATH", None)
    rust["ICU_DATA"] = "/nonexistent/icu-data"
    commands = []

    def run(command, source, stdout, stderr, environment):
        with source.open("rb") as stdin, stdout.open("wb") as out, stderr.open("wb") as err:
            result = subprocess.run(command, stdin=stdin, stdout=out, stderr=err, env=environment, cwd=repo)
        commands.append({"command": command, "stdin": str(source), "stdout": str(stdout),
                         "stderr": str(stderr), "exit": result.returncode,
                         "environment": {name: environment.get(name) for name in ("LD_LIBRARY_PATH", "ICU_DATA")}})
        if result.returncode:
            raise RuntimeError(f"Diagnostic command failed: {command}")

    run([str(oracle)], cases, output / "oracle-keys.tsv", output / "oracle-stderr.log", native)
    run([str(candidate), "--trace"], cases, output / "candidate-keys.tsv", output / "candidate-traces.jsonl", rust)
    run([str(reference_ce), "--batch-utf16"], output / "inputs-u16.tsv",
        output / "reference-ces.tsv", output / "reference-ce-stderr.log", native)
    key_result = compare(cases, output / "oracle-keys.tsv", output / "candidate-keys.tsv")
    with (output / "reference-ces.tsv").open(encoding="utf-8", newline="") as stream:
        reference_rows = list(csv.DictReader(stream, delimiter="\t"))
    with (output / "candidate-traces.jsonl").open(encoding="utf-8") as stream:
        traces = [json.loads(line) for line in stream]
    if len(reference_rows) != COUNT or len(traces) != COUNT:
        raise RuntimeError("CE trace record count changed")
    differences = []
    for i, (expected, actual) in enumerate(zip(reference_rows, traces)):
        if expected["case_id"] != f"spec-{i}" or actual["case_id"] != f"spec-{i}":
            raise RuntimeError("CE trace input identity changed")
        if expected["ces64_hex"].split(",") != actual.get("ces"):
            differences.append({"case_id": f"spec-{i}", "reference": expected, "candidate": actual})

    script = Path(__file__).resolve()
    if script.parent != output:
        shutil.copyfile(script, output / "reproduce.py")
    summary = {
        "schema": "boostregexrs.spec-review-contexts-2048.v1",
        "scope": "Independent finite root PRIMARY full-key and CE64 review diagnostic",
        "evidence_kind": "new replay to persist the previously reported in-memory diagnostic; not recovered original raw evidence",
        "included_in_main_primary_1160181_or_ce_28108_counts": False,
        "started_utc": started, "completed_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "original_reviewed_commit": ORIGINAL_COMMIT,
        "working_head_at_replay": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip(),
        "binary_identity": "All three executables match the original immutable recorded manifests; binaries were not rebuilt",
        "generation": {"algorithm": "SplitMix64", "seed": f"0x{SEED:016x}", "count": COUNT,
                       "base_context_sequence_count": len(base), "marks_in_order": [f"{cp:04x}" for cp in MARKS],
                       "host_unicode_database_used": False, "source_context": record(context_source)},
        "sources": [record(path) for path in sources], "data": record(data),
        "executables": [record(path) for path in (oracle, candidate, reference_ce)],
        "native_libraries": [record(path) for path in libraries],
        "runtime": {"python": sys.version, "platform": platform.platform()},
        "commands": commands,
        "reproduce_command": [sys.executable, "-B", str(output / "reproduce.py"), "--repo", str(repo), "--output", str(output)],
        "key_comparison": key_result,
        "ce_comparison": {"total": COUNT, "passed": COUNT - len(differences), "differences": len(differences), "examples": differences},
        "status": "passed_for_recorded_inputs" if key_result["status"] == "passed_for_recorded_inputs" and not differences else "differences_or_incomplete",
        "evidence": [record(path) for path in sorted(output.iterdir()) if path.is_file() and path.name != "summary.json"],
    }
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "status": summary["status"], "key_totals": key_result["totals"], "ce_comparison": summary["ce_comparison"]}))
    return int(summary["status"] != "passed_for_recorded_inputs")


if __name__ == "__main__":
    raise SystemExit(main())
